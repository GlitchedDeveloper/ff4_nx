/**
 * Document manager — keeps a cached parse of each open .bsym document.
 * Re-parses on every change; for large files this is O(file size) which is fine
 * for the typical .bsym size (<100KB).
 */

import * as vscode from "vscode";
import { parse } from "./parser";
import { Program } from "./ast";
import { TypeRegistry } from "./codegen";

export interface BsymParseResult {
    program: Program;
    registry: TypeRegistry;
    version: number;
    uri: vscode.Uri;
}

export class BsymDocuments {
    private cache = new Map<string, BsymParseResult>();

    /** Get a cached parse, or parse on demand from the open document text. */
    get(document: vscode.TextDocument): BsymParseResult {
        const key = document.uri.toString();
        const cached = this.cache.get(key);
        if (cached && cached.version === document.version) {
            return cached;
        }
        const text = document.getText();
        const program = parse(text);
        const registry = new TypeRegistry(program.items);
        const result: BsymParseResult = {
            program,
            registry,
            version: document.version,
            uri: document.uri,
        };
        this.cache.set(key, result);
        return result;
    }

    invalidate(uri: vscode.Uri) {
        this.cache.delete(uri.toString());
    }

    clear() {
        this.cache.clear();
    }
}
