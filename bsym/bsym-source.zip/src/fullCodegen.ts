/**
 * Full codegen — port of the Codegen class in babilsym.py.
 * Generates babil.h and babil.cpp from a parsed .bsym AST.
 *
 * This is the self-contained TS port so the VSCode extension can generate
 * code without needing babilsym.py on the user's machine.
 */

import {
    Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, StructDecl, ScopeDecl,
    TypeAlias, ITypeDecl, IncludeDecl, RawBlock, AnonStructDecl,
    TypeRef, ParamDecl, EnumEntry, BitEntry, BitConstant,
    PRIMITIVES, PRIMITIVE_SIZES,
} from "./ast";

interface ScopeEntry {
    qpath: string[];
    scope: ScopeDecl;
}

interface NamedTypeEntry {
    kind: "struct" | "union" | "enum" | "bit";
    qpath: string[];
    decl: StructDecl | EnumDecl | BitDecl;
}

function cleanupBlankLines(lines: string[]): string[] {
    while (lines.length > 0 && lines[0].trim() === "") lines.shift();
    while (lines.length > 0 && lines[lines.length - 1].trim() === "") lines.pop();
    const result: string[] = [];
    let prevBlank = false;
    for (const line of lines) {
        const isBlank = line.trim() === "";
        if (isBlank && prevBlank) continue;
        result.push(line);
        prevBlank = isBlank;
    }
    const final: string[] = [];
    for (let i = 0; i < result.length; i++) {
        if (result[i].trim() === "" && i + 1 < result.length && result[i + 1].trim().startsWith("}")) {
            continue;
        }
        final.push(result[i]);
    }
    return final;
}

export class FullCodegen {
    items: Decl[];
    includes: string[] = [];
    itypes = new Map<string, string>();
    aliases = new Map<string, TypeRef>();
    scopes: ScopeEntry[] = [];
    namedTypes: NamedTypeEntry[] = [];
    functions: { path: string[]; fn: FuncDecl }[] = [];
    variables: { path: string[]; v: VarDecl }[] = [];
    rawBlocks = new Map<string, string>();
    usedScopeNames = new Set<string>();

    constructor(items: Decl[]) {
        this.items = items;
        this._collect(items, []);
        this._collectSymbols(items, []);
        for (const it of items) {
            if (it.kind === "raw-block") {
                const existing = this.rawBlocks.get(it.filename) ?? "";
                this.rawBlocks.set(it.filename, existing + it.content + "\n");
            }
        }
        this._collectUsedScopeNames(items, []);
    }

    private _collect(items: Decl[], path: string[]) {
        for (const it of items) {
            switch (it.kind) {
                case "include":
                    if (path.length === 0) this.includes.push(it.filename);
                    break;
                case "itype":
                    if (path.length === 0) this.itypes.set(it.name, it.actual);
                    break;
                case "type-alias":
                    if (path.length === 0) this.aliases.set(it.name, it.target);
                    break;
                case "scope": {
                    const qpath = [...path, it.name];
                    this.scopes.push({ qpath, scope: it });
                    this._collect(it.items, qpath);
                    break;
                }
                case "struct": {
                    const qpath = [...path, it.name];
                    this.namedTypes.push({ kind: it.isUnion ? "union" : "struct", qpath, decl: it });
                    break;
                }
                case "enum": {
                    const qpath = [...path, it.name];
                    this.namedTypes.push({ kind: "enum", qpath, decl: it });
                    break;
                }
                case "bit": {
                    const qpath = [...path, it.name];
                    this.namedTypes.push({ kind: "bit", qpath, decl: it });
                    break;
                }
            }
        }
    }

    private _collectSymbols(items: Decl[], path: string[]) {
        for (const it of items) {
            if (it.kind === "scope") {
                this._collectSymbols(it.items, [...path, it.name]);
            } else if (it.kind === "function") {
                this.functions.push({ path, fn: it });
            } else if (it.kind === "variable") {
                this.variables.push({ path, v: it });
            }
        }
    }

    private _collectUsedScopeNames(items: Decl[], currentPath: string[]) {
        for (const it of items) {
            if (it.kind === "scope") {
                this._collectUsedScopeNames(it.items, [...currentPath, it.name]);
            } else if (it.kind === "field") {
                this._markTypeUsed(it.type, currentPath);
            } else if (it.kind === "function") {
                this._markTypeUsed(it.returnType, currentPath);
                for (const p of it.params) this._markTypeUsed(p.type, currentPath);
            } else if (it.kind === "variable") {
                this._markTypeUsed(it.type, currentPath);
            }
        }
    }

    private _markTypeUsed(t: TypeRef, _currentPath: string[]) {
        if (!t) return;
        const base = t.base;
        if (base === "this") return;
        const parts = base.split("::");
        for (const { qpath } of this.scopes) {
            if (qpath.length >= parts.length) {
                let match = true;
                for (let i = 0; i < parts.length; i++) {
                    if (qpath[qpath.length - parts.length + i] !== parts[i]) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    this.usedScopeNames.add(qpath.join("::"));
                    break;
                }
            }
        }
    }

    private _scopeHasCls(qpath: string[], scope: ScopeDecl): boolean {
        const fields = scope.items.filter(it => it.kind === "field") as FieldDecl[];
        if (fields.length > 0) return true;
        if (scope.size !== null) return true;
        if (this.usedScopeNames.has(qpath.join("::"))) return true;
        for (const it of scope.items) {
            // Functions with `this` parameter need cls.
            if (it.kind === "function" && it.hasThis) return true;
            // Variables of type `this` need cls (codegen emits `extern cls* name;`).
            if (it.kind === "variable" && it.type.base === "this") return true;
        }
        return false;
    }

    // ==================== Unified topological sort ====================
    //
    // Every "definition unit" is a node: top-level named types, nested named types
    // (enums/structs/bits inside scopes), and every scope's cls.
    // Each gets its own `namespace a::b::c { ... }` block in the output.
    // Value-type field dependencies create edges. We sort ALL nodes together.

    /** A single definition unit — one type or one scope cls, with its namespace path. */
    private _collectAllDefUnits(): { id: string; path: string[]; name: string; fields: FieldDecl[]; render: () => string[] }[] {
        const units: { id: string; path: string[]; name: string; fields: FieldDecl[]; render: () => string[] }[] = [];

        // Top-level named types (structs, enums, bits, unions).
        for (const it of this.items) {
            if (it.kind === "struct" || it.kind === "enum" || it.kind === "bit") {
                const fields = it.kind === "struct" ? it.fields : [];
                units.push({
                    id: it.name,
                    path: [],
                    name: it.name,
                    fields,
                    render: () => this.renderTopDecl(it, 0),
                });
            }
        }

        // Recursively visit scopes: add the scope's cls as a unit, and also add
        // any nested named types (enums/structs/bits) as their own units.
        const visitScope = (scope: ScopeDecl, parentPath: string[]) => {
            const path = [...parentPath, scope.name];

            // Scope cls unit.
            const fields = scope.items.filter(it => it.kind === "field") as FieldDecl[];
            // Include anon-structs in the items for rendering.
            const scopeItems = scope.items.filter(it => it.kind === "field" || it.kind === "anon-struct") as Decl[];
            const isUsedAsType = this.usedScopeNames.has(path.join("::"));
            const hasThisFuncs = scope.items.some(it => it.kind === "function" && it.hasThis);
            const hasThisVars = scope.items.some(it => it.kind === "variable" && it.type.base === "this");
            if (scopeItems.length > 0 || scope.size !== null || isUsedAsType || hasThisFuncs || hasThisVars) {
                units.push({
                    id: path.join("::"),
                    path,
                    name: scope.name,
                    fields,
                    render: () => {
                        const body: string[] = ["    struct __attribute__((packed)) cls {"];
                        body.push(...this._renderFieldsBlock(scopeItems, scope.size, "    ", "cls"));
                        return this._emitNamespaceBlock(path, body);
                    },
                });
            }

            // Nested named types (enums/structs/bits) inside this scope.
            for (const it of scope.items) {
                if (it.kind === "enum" || it.kind === "struct" || it.kind === "bit") {
                    const ntFields = it.kind === "struct" ? it.fields : [];
                    units.push({
                        id: path.join("::") + "::" + it.name,
                        path,
                        name: it.name,
                        fields: ntFields,
                        render: () => {
                            const body = this.renderTopDecl(it, 1);
                            return this._emitNamespaceBlock(path, body);
                        },
                    });
                }
            }

            // Recurse into nested scopes.
            const nestedScopes = scope.items.filter(it => it.kind === "scope") as ScopeDecl[];
            for (const ns of nestedScopes) {
                visitScope(ns, path);
            }
        };
        for (const it of this.items) {
            if (it.kind === "scope") visitScope(it, []);
        }

        return units;
    }

    /** Build two maps for dependency resolution:
     *  1. Full scoped name → unit ID (e.g. "common::ABILITY_ID" → "common::ABILITY_ID")
     *  2. Last part only → unit ID (e.g. "ABILITY_ID" → first unit found with that name)
     *  The full-name map is tried first when resolving scoped references. */
    private _buildNameToUnitId(units: { id: string; path: string[]; name: string }[]): { fullName: Map<string, string>; lastName: Map<string, string> } {
        const fullName = new Map<string, string>();
        const lastName = new Map<string, string>();
        for (const u of units) {
            // Full qualified name: path::name (e.g. "common::ABILITY_ID")
            const full = u.path.length > 0 ? [...u.path, u.name].join("::") : u.name;
            fullName.set(full, u.id);
            // Last part only (for unqualified references)
            if (!lastName.has(u.name)) {
                lastName.set(u.name, u.id);
            }
        }
        return { fullName, lastName };
    }

    /**
     * Unified topological sort of ALL definition units.
     * Returns units in dependency order. Detects recursive value-type dependencies
     * (which are impossible in C++) and reports them as errors.
     */
    private _topoSortAllUnits(): { units: { id: string; path: string[]; name: string; fields: FieldDecl[]; render: () => string[] }[]; error?: string } {
        const units = this._collectAllDefUnits();
        const { fullName: fullNameToId, lastName: lastNameToId } = this._buildNameToUnitId(units);
        const unitById = new Map(units.map(u => [u.id, u]));

        // Build dependency graph: for each unit, find which other units it depends on
        // (value-type fields only, not pointer/reference).
        const deps = new Map<string, Set<string>>();
        for (const u of units) {
            const depSet = new Set<string>();
            for (const f of u.fields) {
                if (f.type.pointerCount === 0 && !f.type.isReference) {
                    const base = f.type.base;
                    if (base === "this") continue;
                    // Try full scoped name first (e.g. "common::ABILITY_ID").
                    // This ensures that when two types share the same name in
                    // different namespaces, the correct one is resolved.
                    let depId = fullNameToId.get(base);
                    if (!depId) {
                        // Fall back to last-part lookup.
                        const lookupName = base.includes("::") ? base.split("::").pop()! : base;
                        depId = lastNameToId.get(lookupName);
                    }
                    if (depId && depId !== u.id) {
                        depSet.add(depId);
                    }
                }
            }
            deps.set(u.id, depSet);
        }

        // DFS topological sort with cycle detection.
        const result: typeof units = [];
        const visited = new Set<string>();
        const visiting = new Set<string>();

        const visit = (id: string): string | null => {
            if (visited.has(id)) return null;
            if (visiting.has(id)) {
                // Cycle detected — report the recursive dependency.
                const u = unitById.get(id);
                return u ? u.name : id;
            }
            visiting.add(id);
            for (const dep of deps.get(id) || []) {
                const cycle = visit(dep);
                if (cycle) return cycle;
            }
            visiting.delete(id);
            visited.add(id);
            const u = unitById.get(id);
            if (u) result.push(u);
            return null;
        };

        for (const u of units) {
            const cycle = visit(u.id);
            if (cycle) {
                return { units: [], error: `Recursive value-type dependency detected involving '${cycle}'. This is impossible in C++ — use a pointer instead.` };
            }
        }

        return { units: result };
    }

    /**
     * Collect only the forward declarations that are actually needed.
     * A forward decl is needed if the type is used as a pointer or reference
     * in a cls/struct FIELD (not in functions/variables — those don't need
     * forward decls because the full definition comes before the functions section).
     */
    private _collectForwardDecls(): { path: string[]; decls: string[] }[] {
        const neededScopeCls = new Set<string>();  // qualified paths
        const neededNamedTypes = new Set<string>();  // qualified paths

        // Only collect from fields (cls/struct fields), not from functions/variables.
        const visitFields = (items: Decl[]) => {
            for (const it of items) {
                if (it.kind === "scope") {
                    visitFields(it.items);
                    continue;
                }
                if (it.kind === "field") {
                    const t = it.type;
                    if (t.pointerCount > 0 || t.isReference) {
                        const base = t.base;
                        if (base === "this") continue;
                        const lookupName = base.includes("::") ? base.split("::").pop()! : base;
                        for (const { qpath, scope } of this.scopes) {
                            if (qpath[qpath.length - 1] === lookupName) {
                                neededScopeCls.add(qpath.join("::"));
                            }
                        }
                        // Only forward-declare TOP-LEVEL named types (qpath.length === 1).
                        // Types nested inside scopes are defined inside their parent scope's
                        // namespace block — forward-declaring them separately causes redefinition errors.
                        for (const { qpath, decl } of this.namedTypes) {
                            if (decl.name === lookupName && qpath.length === 1) {
                                neededNamedTypes.add(qpath.join("::"));
                            }
                        }
                    }
                }
            }
        };
        visitFields(this.items);

        // Group decls by their parent namespace path.
        const groups = new Map<string, string[]>();

        for (const { qpath, scope } of this.scopes) {
            const qpathStr = qpath.join("::");
            if (neededScopeCls.has(qpathStr) && this._scopeHasCls(qpath, scope)) {
                const key = qpathStr;
                if (!groups.has(key)) groups.set(key, []);
                groups.get(key)!.push("struct cls;");
            }
        }

        for (const { kind, qpath, decl } of this.namedTypes) {
            const qpathStr = qpath.join("::");
            if (!neededNamedTypes.has(qpathStr)) continue;
            let declStr: string;
            if (kind === "enum") {
                const e = decl as EnumDecl;
                if (e.underlying) {
                    declStr = `enum class ${e.name} : ${this.renderType(e.underlying)};`;
                } else {
                    declStr = `enum class ${e.name};`;
                }
            } else {
                const s = decl as StructDecl;
                declStr = s.isUnion ? `union ${s.name};` : `struct ${s.name};`;
            }
            const parentPath = qpath.slice(0, -1);
            const key = parentPath.join("::");
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key)!.push(declStr);
        }

        // Convert to array of { path, decls }, with empty-path entries first.
        const result: { path: string[]; decls: string[] }[] = [];
        for (const [key, decls] of groups) {
            const path = key ? key.split("::") : [];
            result.push({ path, decls });
        }
        // Sort: empty path first, then alphabetical.
        result.sort((a, b) => {
            if (a.path.length === 0 && b.path.length > 0) return -1;
            if (a.path.length > 0 && b.path.length === 0) return 1;
            return a.path.join("::").localeCompare(b.path.join("::"));
        });
        return result;
    }

    /** Emit a `namespace a::b::c { ... }` block with the given body lines.
     *  Body lines are expected to already be indented for the namespace's interior. */
    private _emitNamespaceBlock(path: string[], bodyLines: string[]): string[] {
        if (path.length === 0) return bodyLines;
        const ns = path.join("::");
        const out: string[] = [`namespace ${ns} {`];
        out.push(...bodyLines);
        out.push("}");
        return out;
    }

    // ------------------- Type rendering -------------------

    renderType(t: TypeRef): string {
        let s = "";
        if (t.isConst) s += "const ";
        const base = t.base;
        if (base === "this") {
            s += "cls";
        } else if (this._isScopeName(base)) {
            s += base + "::cls";
        } else {
            s += base;
        }
        s += "*".repeat(t.pointerCount);
        if (t.isReference) s += "&";
        return s;
    }

    private _isScopeName(base: string): boolean {
        const parts = base.split("::");
        for (const { qpath } of this.scopes) {
            if (qpath.length >= parts.length) {
                let match = true;
                for (let i = 0; i < parts.length; i++) {
                    if (qpath[qpath.length - parts.length + i] !== parts[i]) {
                        match = false;
                        break;
                    }
                }
                if (match) return true;
            }
        }
        return false;
    }

    /**
     * Render a function return type. `this` as a return type becomes `cls`
     * (value, not pointer). Other types are rendered normally.
     */
    private renderReturnType(t: TypeRef): string {
        return this.renderType(t);
    }

    // ------------------- Size calculation -------------------

    private _baseSize(baseName: string, depth = 0): number {
        if (depth > 16) return 0;
        if (PRIMITIVE_SIZES[baseName] !== undefined) return PRIMITIVE_SIZES[baseName];
        if (baseName === "this") return 0;
        // For scoped names (e.g. "sys2d::Sprite"), extract the last part for lookup.
        const lookupName = baseName.includes("::") ? baseName.split("::").pop()! : baseName;
        if (this.itypes.has(lookupName)) {
            const actual = this.itypes.get(lookupName)!;
            for (const prim in PRIMITIVE_SIZES) {
                if (actual === prim) return PRIMITIVE_SIZES[prim];
            }
            const words = actual.split(/\s+/);
            for (let i = words.length - 1; i >= 0; i--) {
                if (PRIMITIVE_SIZES[words[i]] !== undefined) return PRIMITIVE_SIZES[words[i]];
            }
            return 0;
        }
        if (this.aliases.has(lookupName)) {
            return this._typeSizeNoArray(this.aliases.get(lookupName)!, depth + 1);
        }
        // Look up scopes by name — match the last part of the qpath so nested
        // scopes (e.g. world::WorldCamera, sys2d::Sprite) are found whether
        // referenced by bare name or scoped name.
        for (const { qpath, scope } of this.scopes) {
            if (qpath[qpath.length - 1] === lookupName) {
                if (scope.size !== null) return scope.size;
                return this._calcScopeSize(scope);
            }
        }
        for (const { qpath, decl } of this.namedTypes) {
            if (decl.name === lookupName) {
                if (decl.kind === "struct") {
                    const s = decl as StructDecl;
                    if (s.size !== null) return s.size;
                    return this._calcStructSize(s);
                }
                if (decl.kind === "enum") {
                    const e = decl as EnumDecl;
                    if (e.underlying) return this._baseSize(e.underlying.base, depth + 1);
                    return 4;
                }
                if (decl.kind === "bit") {
                    const b = decl as BitDecl;
                    return this._baseSize(b.underlying.base, depth + 1);
                }
            }
        }
        return 0;
    }

    private _typeSizeNoArray(t: TypeRef, depth = 0): number {
        if (depth > 16) return 0;
        if (t.pointerCount > 0 || t.isReference) return 8;
        return this._baseSize(t.base, depth + 1);
    }

    private _typeSize(t: TypeRef, arraySize: number | null): number {
        let base: number;
        if (t.pointerCount > 0 || t.isReference) base = 8;
        else base = this._baseSize(t.base);
        if (arraySize !== null) base = base * arraySize;
        return base;
    }

    /** Compute total size accounting for multi-level arrays (e.g. u8[3][1000] = base * 3 * 1000). */
    private _typeSizeMulti(t: TypeRef, arraySizes: number[]): number {
        let base: number;
        if (t.pointerCount > 0 || t.isReference) base = 8;
        else base = this._baseSize(t.base);
        for (const dim of arraySizes) base = base * dim;
        return base;
    }

    private _calcStructSize(decl: StructDecl): number {
        if (decl.fields.length === 0) return 1;
        if (decl.isUnion) {
            // Union size = max of all member sizes (all at offset 0).
            let maxSize = 1;
            for (const f of decl.fields) {
                const sz = this._typeSizeMulti(f.type, f.arraySizes);
                if (sz > maxSize) maxSize = sz;
            }
            return maxSize;
        }
        const last = decl.fields[decl.fields.length - 1];
        return last.offset + this._typeSizeMulti(last.type, last.arraySizes);
    }

    private _calcScopeSize(scope: ScopeDecl): number {
        const fields = scope.items.filter(it => it.kind === "field") as FieldDecl[];
        if (fields.length === 0) return 1;
        const last = fields[fields.length - 1];
        return last.offset + this._typeSizeMulti(last.type, last.arraySizes);
    }

    // ------------------- Field name handling -------------------

    private _fieldName(name: string, offset: number): string {
        if (name === "unk") return `m_0x${offset.toString(16)}`;
        // `\` prefix means "don't add m_" — strip it and use the name as-is.
        if (name.startsWith("\\")) return name.slice(1);
        return `m_${name}`;
    }

    private static _padName(idx: number): string {
        return `_pad${idx}`;
    }

    private _bitFieldName(name: string, loBit: number = 0): string {
        if (name === "unk") return `m_${loBit}`;
        // `\` prefix means "don't add m_" — strip it and use the name as-is.
        if (name.startsWith("\\")) return name.slice(1);
        return `m_${name}`;
    }

    // ------------------- Enum value formatting -------------------

    private static _formatEnumValue(value: number): string {
        if (value === 0) return "0";
        if (value < 10) return String(value);
        return `0x${value.toString(16)}`;
    }

    private _formatEnumEntry(entry: EnumEntry): string {
        if (entry.rawText) return entry.rawText;
        return FullCodegen._formatEnumValue(entry.value);
    }

    private _formatBitConstant(c: BitConstant): string {
        if (c.rawText) return c.rawText;
        return FullCodegen._formatEnumValue(c.value);
    }

    // ------------------- Comment emission -------------------

    private _emitComment(comment: string | null, indentStr: string): string[] {
        const out: string[] = [];
        if (comment) {
            for (const c of comment.split("\n")) {
                out.push(`${indentStr}// ${c}`);
            }
        }
        return out;
    }

    // ------------------- Header generation -------------------

    genHeader(): string {
        const lines: string[] = [];
        lines.push("#pragma once");
        lines.push("");
        lines.push('#include "so_util.h"');
        lines.push('#include "types.h"');
        for (const inc of this.includes) {
            if (inc.startsWith("<") && inc.endsWith(">")) {
                lines.push(`#include ${inc}`);
            } else {
                lines.push(`#include "${inc}"`);
            }
        }
        lines.push("");
        lines.push("#define HOOK_FUNCTION_BASE(name, dest) so::hook((uintptr_t)name, (uintptr_t)dest)");
        lines.push("#define HOOK_FUNCTION_T_BASE(name, dest, trampoline) so::hook((uintptr_t)name, (uintptr_t)dest, (uintptr_t*)&trampoline)");
        lines.push("#define HOOK_FUNCTION(name) HOOK_FUNCTION_BASE(babil::name, name)");
        lines.push("#define HOOK_FUNCTION_T(name) \\");
        lines.push('    debugPrintf("HOOK_FUNCTION_T(" #name ")\\n"); \\');
        lines.push("    HOOK_FUNCTION_T_BASE(babil::name, name, name##_t)");
        lines.push("#define DECLARE_TRAMPOLINE(name, trampoline) static decltype(name) trampoline = nullptr");
        lines.push("");
        lines.push("namespace babil {");
        lines.push("");

        // Type aliases
        let hasAliases = false;
        for (const it of this.items) {
            if (it.kind === "type-alias") {
                hasAliases = true;
                if (it.comment) {
                    for (const c of it.comment.split("\n")) {
                        lines.push(`// ${c}`);
                    }
                }
                lines.push(`using ${it.name} = ${this.renderType(it.target)};`);
            }
        }
        if (hasAliases) lines.push("");

        // ===== Section 1: Forward declarations =====
        const forwardGroups = this._collectForwardDecls();
        for (const group of forwardGroups) {
            lines.push(...this._emitNamespaceBlock(group.path, group.decls));
            lines.push("");
        }

        // ===== Section 2: All type/cls definitions =====
        // Every definition unit (top-level types, nested types, scope cls) is
        // emitted as its own namespace block, topologically sorted by value-type
        // dependencies. Recursive dependencies are detected and reported.
        const sortResult = this._topoSortAllUnits();
        if (sortResult.error) {
            // Report the error but continue generating (the output may be partially valid).
            lines.push(`// ERROR: ${sortResult.error}`);
            lines.push("");
        }
        for (const unit of sortResult.units) {
            lines.push(...unit.render());
            lines.push("");
        }

        // ===== Section 3: Functions / variables =====
        // Top-level free functions and variables (grouped together).
        const topFuncs = this.items.filter(it => it.kind === "function") as FuncDecl[];
        const topVars = this.items.filter(it => it.kind === "variable") as VarDecl[];
        if (topFuncs.length > 0 || topVars.length > 0) {
            for (const fn of topFuncs) {
                if (fn.comment) lines.push(...this._emitComment(fn.comment, ""));
                const ret = this.renderReturnType(fn.returnType);
                const params: string[] = [];
                if (fn.hasThis) {
                    params.push(fn.isConstThis ? "const cls* self" : "cls* self");
                }
                for (const p of fn.params) {
                    let s = this.renderType(p.type);
                    if (p.name) s += " " + p.name;
                    params.push(s);
                }
                if (fn.isVariadic) params.push("...");
                const paramsStr = params.length > 0 ? params.join(", ") : "void";
                lines.push(`extern ${ret} (*${fn.name})(${paramsStr});`);
            }
            for (const v of topVars) {
                if (v.comment) lines.push(...this._emitComment(v.comment, ""));
                const tstr = this.renderType(v.type) + "*";
                lines.push(`extern ${tstr} ${v.name};`);
            }
            lines.push("");
        }
        // Scope functions and variables (grouped by top-level namespace).
        const scopeFv = this.renderAllScopeFuncsVars();
        if (scopeFv.length > 0) {
            lines.push(...scopeFv);
            lines.push("");
        }

        // init() declaration
        lines.push("void init();");
        lines.push("");

        // Raw blocks
        if (this.rawBlocks.has("babil.h")) {
            lines.push(this.rawBlocks.get("babil.h")!.trimEnd());
            lines.push("");
        }

        lines.push("} // namespace babil");
        const cleaned = cleanupBlankLines(lines);
        return cleaned.join("\n") + "\n";
    }

    private renderTopDecl(decl: StructDecl | EnumDecl | BitDecl, indentLevel: number): string[] {
        if (decl.kind === "enum") return this.renderEnum(decl, indentLevel);
        if (decl.kind === "bit") return this.renderBit(decl, indentLevel);
        // struct
        if (decl.isUnion) return this.renderUnion(decl, indentLevel);
        return this.renderStruct(decl, indentLevel);
    }

    private renderEnum(decl: EnumDecl, indentLevel: number): string[] {
        const indent = "    ".repeat(indentLevel);
        const out: string[] = [];
        if (decl.comment) out.push(...this._emitComment(decl.comment, indent));
        if (decl.underlying) {
            out.push(`${indent}enum class ${decl.name} : ${this.renderType(decl.underlying)} {`);
        } else {
            out.push(`${indent}enum class ${decl.name} {`);
        }
        if (decl.entries.length === 0) {
            out.push(`${indent}};`);
            return out;
        }
        for (const e of decl.entries) {
            out.push(`${indent}    ${e.name} = ${this._formatEnumEntry(e)},`);
        }
        out.push(`${indent}};`);
        return out;
    }

    private renderBit(decl: BitDecl, indentLevel: number): string[] {
        const indent = "    ".repeat(indentLevel);
        const u = decl.underlying.base;
        const totalMap: Record<string, number> = {
            "u8": 8, "u16": 16, "u32": 32, "u64": 64,
            "s8": 8, "s16": 16, "s32": 32, "s64": 64,
        };
        const total = totalMap[u] ?? 32;
        const sortedEntries = [...decl.entries].sort((a, b) => a.range.lo - b.range.lo);
        const out: string[] = [];
        if (decl.comment) out.push(...this._emitComment(decl.comment, indent));

        // Struct
        out.push(`${indent}struct __attribute__((packed)) ${decl.name} {`);
        let cursor = 0;
        let padIdx = 0;
        for (const e of sortedEntries) {
            if (e.range.lo > cursor) {
                const padWidth = e.range.lo - cursor;
                out.push(`${indent}    ${u} ${FullCodegen._padName(padIdx)} : ${padWidth};`);
                padIdx++;
                cursor = e.range.lo;
            }
            const fieldType = e.fieldType ? this.renderType(e.fieldType) : u;
            const width = e.range.hi - e.range.lo + 1;
            out.push(`${indent}    ${fieldType} ${this._bitFieldName(e.name, e.range.lo)} : ${width};`);
            cursor = e.range.hi + 1;
        }
        if (cursor < total) {
            const padWidth = total - cursor;
            out.push(`${indent}    ${u} ${FullCodegen._padName(padIdx)} : ${padWidth};`);
            padIdx++;
        }
        out.push(`${indent}};`);

        // Mask enum
        out.push(`${indent}enum class ${decl.name}Mask : ${u} {`);
        for (const c of decl.constants) {
            out.push(`${indent}    ${c.name} = ${this._formatBitConstant(c)},`);
        }
        for (const e of sortedEntries) {
            const width = e.range.hi - e.range.lo + 1;
            if (width === 1) {
                out.push(`${indent}    ${e.name} = BIT(${e.range.lo}),`);
            } else {
                const mask = ((1 << width) - 1) << e.range.lo;
                out.push(`${indent}    ${e.name} = ${FullCodegen._formatEnumValue(mask)},`);
            }
        }
        out.push(`${indent}};`);
        return out;
    }

    private _renderFieldsBlock(items: Decl[], declSize: number | null, indent: string, typeName: string): string[] {
        const out: string[] = [];
        let cursor = 0;
        let padIdx = 0;
        const fields = items.filter(it => it.kind === "field") as FieldDecl[];
        for (const item of items) {
            if (item.kind === "field") {
                const f = item;
                if (f.offset > cursor) {
                    const padWidth = f.offset - cursor;
                    out.push(`${indent}    u8 ${FullCodegen._padName(padIdx)}[${padWidth}]; // 0x${cursor.toString(16)}`);
                    padIdx++;
                    cursor = f.offset;
                }
                if (f.comment) out.push(...this._emitComment(f.comment, indent + "    "));
                const tstr = this.renderType(f.type);
                const arrStr = f.arraySizes.map(s => `[${s}]`).join("");
                const fname = this._fieldName(f.name, f.offset);
                out.push(`${indent}    ${tstr} ${fname}${arrStr}; // 0x${f.offset.toString(16)}`);
                cursor = f.offset + this._typeSizeMulti(f.type, f.arraySizes);
            } else if (item.kind === "anon-struct") {
                const anon = item as AnonStructDecl;
                if (anon.offset > cursor) {
                    const padWidth = anon.offset - cursor;
                    out.push(`${indent}    u8 ${FullCodegen._padName(padIdx)}[${padWidth}]; // 0x${cursor.toString(16)}`);
                    padIdx++;
                    cursor = anon.offset;
                }
                if (anon.comment) out.push(...this._emitComment(anon.comment, indent + "    "));
                const kw = anon.isUnion ? "union" : "struct";
                out.push(`${indent}    ${kw} {`);
                // Render anon members (offsets are relative to the anon block's start).
                let anonCursor = 0;
                let anonPadIdx = 0;
                for (const af of anon.fields) {
                    if (af.offset > anonCursor) {
                        const padWidth = af.offset - anonCursor;
                        out.push(`${indent}        u8 ${FullCodegen._padName(anonPadIdx)}[${padWidth}]; // 0x${anonCursor.toString(16)}`);
                        anonPadIdx++;
                        anonCursor = af.offset;
                    }
                    if (af.comment) out.push(...this._emitComment(af.comment, indent + "        "));
                    const tstr = this.renderType(af.type);
                    const arrStr = af.arraySizes.map(s => `[${s}]`).join("");
                    const fname = this._fieldName(af.name, af.offset);
                    out.push(`${indent}        ${tstr} ${fname}${arrStr};`);
                    anonCursor = af.offset + this._typeSizeMulti(af.type, af.arraySizes);
                }
                out.push(`${indent}    }; // 0x${anon.offset.toString(16)}`);
                // Calculate anon block size.
                if (anon.isUnion) {
                    let maxSize = 1;
                    for (const af of anon.fields) {
                        const sz = this._typeSizeMulti(af.type, af.arraySizes);
                        if (sz > maxSize) maxSize = sz;
                    }
                    cursor = anon.offset + maxSize;
                } else {
                    if (anon.fields.length > 0) {
                        const last = anon.fields[anon.fields.length - 1];
                        cursor = anon.offset + last.offset + this._typeSizeMulti(last.type, last.arraySizes);
                    } else {
                        cursor = anon.offset + 1;
                    }
                }
            }
        }
        let calcSize: number;
        if (declSize === null) {
            if (fields.length > 0) {
                const last = fields[fields.length - 1];
                calcSize = last.offset + this._typeSizeMulti(last.type, last.arraySizes);
            } else {
                calcSize = 1;
            }
        } else {
            calcSize = declSize;
        }
        if (declSize !== null && cursor < declSize) {
            const padWidth = declSize - cursor;
            out.push(`${indent}    u8 ${FullCodegen._padName(padIdx)}[${padWidth}]; // 0x${cursor.toString(16)}`);
            padIdx++;
            cursor = declSize;
        }
        out.push(`${indent}};`);
        // Only emit sizeof static_assert if an explicit size was given.
        if (declSize !== null) {
            out.push(`${indent}static_assert(sizeof(${typeName}) == 0x${calcSize.toString(16)});`);
        }
        for (const f of fields) {
            const fname = this._fieldName(f.name, f.offset);
            out.push(`${indent}static_assert(offsetof(${typeName}, ${fname}) == 0x${f.offset.toString(16)});`);
        }
        return out;
    }

    private renderStruct(decl: StructDecl, indentLevel: number): string[] {
        const indent = "    ".repeat(indentLevel);
        const out: string[] = [];
        if (decl.comment) out.push(...this._emitComment(decl.comment, indent));
        out.push(`${indent}struct __attribute__((packed)) ${decl.name} {`);
        // Use items (includes anon-structs) if available, otherwise just fields.
        const items = decl.items || decl.fields;
        out.push(...this._renderFieldsBlock(items, decl.size, indent, decl.name));
        return out;
    }

    private renderUnion(decl: StructDecl, indentLevel: number): string[] {
        const indent = "    ".repeat(indentLevel);
        const out: string[] = [];
        if (decl.comment) out.push(...this._emitComment(decl.comment, indent));
        out.push(`${indent}union __attribute__((packed)) ${decl.name} {`);
        for (const f of decl.fields) {
            if (f.comment) out.push(...this._emitComment(f.comment, indent + "    "));
            const tstr = this.renderType(f.type);
            const arrStr = f.arraySize !== null ? `[${f.arraySize}]` : "";
            out.push(`${indent}    ${tstr} ${f.name}${arrStr};`);
        }
        out.push(`${indent}};`);
        if (decl.size !== null) {
            out.push(`${indent}static_assert(sizeof(${decl.name}) == 0x${decl.size.toString(16)});`);
        }
        return out;
    }

    /**
     * Render a scope's cls definition (and nested types) as a
     * `namespace a::b::c { ... }` block. Does NOT emit functions/variables.
     * Recursively emits nested scopes' cls definitions as separate namespace blocks.
     */
    private renderScopeCls(decl: ScopeDecl, parentPath: string[]): string[] {
        const path = [...parentPath, decl.name];
        const out: string[] = [];

        // Collect nested scopes and topo-sort them.
        const nestedScopes = decl.items.filter(it => it.kind === "scope") as ScopeDecl[];
        // Build sibling map for dep resolution.
        const siblingMap = new Map<string, ScopeDecl>();
        for (const ns of nestedScopes) siblingMap.set(ns.name, ns);

        // Check which nested scopes the parent's cls fields depend on (value types).
        const fields = decl.items.filter(it => it.kind === "field") as FieldDecl[];
        const neededBeforeCls = new Set<ScopeDecl>();
        for (const f of fields) {
            if (f.type.pointerCount === 0 && !f.type.isReference) {
                const base = f.type.base;
                if (base === "this") continue;
                const lookupName = base.includes("::") ? base.split("::").pop()! : base;
                const dep = siblingMap.get(lookupName);
                if (dep) neededBeforeCls.add(dep);
            }
        }

        // Topo-sort all nested scopes (siblings), considering both sibling deps
        // and which ones need to come before the parent's cls.
        const siblingDeps = new Map<ScopeDecl, Set<ScopeDecl>>();
        for (const ns of nestedScopes) {
            const depSet = new Set<ScopeDecl>();
            for (const it of ns.items) {
                if (it.kind === "field" && it.type.pointerCount === 0 && !it.type.isReference) {
                    const base = it.type.base;
                    if (base === "this") continue;
                    const lookupName = base.includes("::") ? base.split("::").pop()! : base;
                    const dep = siblingMap.get(lookupName);
                    if (dep && dep !== ns) depSet.add(dep);
                }
            }
            // Also check nested-nested scopes for sibling deps.
            const deepNested = ns.items.filter(it => it.kind === "scope") as ScopeDecl[];
            for (const dn of deepNested) {
                for (const it of dn.items) {
                    if (it.kind === "field" && it.type.pointerCount === 0 && !it.type.isReference) {
                        const base = it.type.base;
                        if (base === "this") continue;
                        const lookupName = base.includes("::") ? base.split("::").pop()! : base;
                        const dep = siblingMap.get(lookupName);
                        if (dep && dep !== ns) depSet.add(dep);
                    }
                }
            }
            siblingDeps.set(ns, depSet);
        }

        // DFS topo sort for siblings.
        const sortedNested: ScopeDecl[] = [];
        const siblingVisited = new Set<ScopeDecl>();
        const siblingVisiting = new Set<ScopeDecl>();
        const visitSibling = (s: ScopeDecl) => {
            if (siblingVisited.has(s)) return;
            if (siblingVisiting.has(s)) return;
            siblingVisiting.add(s);
            for (const dep of siblingDeps.get(s) || []) visitSibling(dep);
            siblingVisiting.delete(s);
            siblingVisited.add(s);
            sortedNested.push(s);
        };
        for (const ns of nestedScopes) visitSibling(ns);

        // Partition: scopes needed before cls, and scopes that can come after.
        const beforeCls: ScopeDecl[] = [];
        const afterCls: ScopeDecl[] = [];
        for (const ns of sortedNested) {
            if (neededBeforeCls.has(ns)) {
                beforeCls.push(ns);
            } else {
                afterCls.push(ns);
            }
        }

        // Emit "before cls" nested scopes first (as separate namespace blocks).
        for (const ns of beforeCls) {
            const nsLines = this.renderScopeCls(ns, path);
            if (nsLines.length > 0) {
                if (out.length > 0) out.push("");
                out.push(...nsLines);
            }
        }

        // Emit this scope's cls + nested types.
        const body: string[] = [];
        const nestedTypes = decl.items.filter(it => it.kind === "struct" || it.kind === "enum" || it.kind === "bit") as (StructDecl | EnumDecl | BitDecl)[];
        const aliases = decl.items.filter(it => it.kind === "type-alias") as TypeAlias[];
        // Include anon-structs in the items for rendering.
        const scopeItems = decl.items.filter(it => it.kind === "field" || it.kind === "anon-struct") as Decl[];

        for (const a of aliases) {
            if (a.comment) body.push(...this._emitComment(a.comment, "    "));
            body.push(`    using ${a.name} = ${this.renderType(a.target)};`);
        }
        for (const nt of nestedTypes) {
            body.push(...this.renderTopDecl(nt, 1));
        }
        const isUsedAsType = this.usedScopeNames.has(path.join("::"));
        const hasThisFuncs = decl.items.some(it => it.kind === "function" && it.hasThis);
        const hasThisVars = decl.items.some(it => it.kind === "variable" && it.type.base === "this");
        if (scopeItems.length > 0 || decl.size !== null || isUsedAsType || hasThisFuncs || hasThisVars) {
            body.push("    struct __attribute__((packed)) cls {");
            body.push(...this._renderFieldsBlock(scopeItems, decl.size, "    ", "cls"));
        }
        if (body.length > 0) {
            if (out.length > 0) out.push("");
            out.push(...this._emitNamespaceBlock(path, body));
        }

        // Emit "after cls" nested scopes.
        for (const ns of afterCls) {
            const nsLines = this.renderScopeCls(ns, path);
            if (nsLines.length > 0) {
                if (out.length > 0) out.push("");
                out.push(...nsLines);
            }
        }

        return out;
    }

    /**
     * Render all scope functions/variables, grouped by top-level namespace.
     * Uses nested `namespace a { namespace b { ... } }` syntax so that all
     * scopes within the same top-level namespace are grouped together.
     */
    private renderAllScopeFuncsVars(): string[] {
        const sortedScopes = this.items.filter(it => it.kind === "scope") as ScopeDecl[];
        const out: string[] = [];

        // Group scopes by their top-level namespace name.
        const byTopLevel = new Map<string, ScopeDecl[]>();
        for (const scope of sortedScopes) {
            const topName = scope.name;
            if (!byTopLevel.has(topName)) byTopLevel.set(topName, []);
            byTopLevel.get(topName)!.push(scope);
        }

        for (const [topName, scopes] of byTopLevel) {
            // Collect all nested namespace blocks for this top-level scope.
            const innerBlocks: string[] = [];
            for (const scope of scopes) {
                // The top-level scope itself may have direct functions/variables.
                // Emit them at depth 1 (inside the top-level namespace block).
                const directFunctions = scope.items.filter(it => it.kind === "function") as FuncDecl[];
                const directVariables = scope.items.filter(it => it.kind === "variable") as VarDecl[];
                if (directFunctions.length > 0 || directVariables.length > 0) {
                    for (const fn of directFunctions) {
                        if (fn.comment) innerBlocks.push(...this._emitComment(fn.comment, "    "));
                        const ret = this.renderReturnType(fn.returnType);
                        const params: string[] = [];
                        if (fn.hasThis) params.push(fn.isConstThis ? "const cls* self" : "cls* self");
                        for (const p of fn.params) {
                            let s = this.renderType(p.type);
                            if (p.name) s += " " + p.name;
                            params.push(s);
                        }
                        if (fn.isVariadic) params.push("...");
                        const paramsStr = params.length > 0 ? params.join(", ") : "void";
                        innerBlocks.push(`    extern ${ret} (*${fn.name})(${paramsStr});`);
                    }
                    for (const v of directVariables) {
                        if (v.comment) innerBlocks.push(...this._emitComment(v.comment, "    "));
                        const tstr = this.renderType(v.type) + "*";
                        innerBlocks.push(`    extern ${tstr} ${v.name};`);
                    }
                }
                // Emit nested scopes' functions/variables.
                const nestedScopes = scope.items.filter(it => it.kind === "scope") as ScopeDecl[];
                for (const ns of nestedScopes) {
                    const nestedLines = this.renderScopeFuncsVarsNested(ns, 1);
                    if (nestedLines.length > 0) {
                        if (innerBlocks.length > 0) innerBlocks.push("");
                        innerBlocks.push(...nestedLines);
                    }
                }
            }
            if (innerBlocks.length > 0) {
                if (out.length > 0) out.push("");
                out.push(`namespace ${topName} {`);
                out.push(...innerBlocks);
                out.push("}");
            }
        }
        return out;
    }

    /**
     * Render a scope's functions/variables using nested namespace syntax
     * (e.g. `namespace ChildName { ... }` without the top-level prefix).
     */
    private renderScopeFuncsVarsNested(decl: ScopeDecl, depth: number): string[] {
        const indent = "    ".repeat(depth);
        const out: string[] = [];

        const functions = decl.items.filter(it => it.kind === "function") as FuncDecl[];
        const variables = decl.items.filter(it => it.kind === "variable") as VarDecl[];

        const body: string[] = [];
        for (const fn of functions) {
            if (fn.comment) body.push(...this._emitComment(fn.comment, indent + "    "));
            const ret = this.renderReturnType(fn.returnType);
            const params: string[] = [];
            if (fn.hasThis) {
                params.push(fn.isConstThis ? "const cls* self" : "cls* self");
            }
            for (const p of fn.params) {
                let s = this.renderType(p.type);
                if (p.name) s += " " + p.name;
                params.push(s);
            }
            if (fn.isVariadic) params.push("...");
            const paramsStr = params.length > 0 ? params.join(", ") : "void";
            body.push(`${indent}    extern ${ret} (*${fn.name})(${paramsStr});`);
        }
        for (const v of variables) {
            if (v.comment) body.push(...this._emitComment(v.comment, indent + "    "));
            const tstr = this.renderType(v.type) + "*";
            body.push(`${indent}    extern ${tstr} ${v.name};`);
        }

        // Recursively collect nested scopes' functions/variables — these go
        // INSIDE the current namespace block, before the closing brace.
        const nestedScopes = decl.items.filter(it => it.kind === "scope") as ScopeDecl[];
        const nestedBlocks: string[] = [];
        for (const ns of nestedScopes) {
            const nestedLines = this.renderScopeFuncsVarsNested(ns, depth + 1);
            if (nestedLines.length > 0) {
                if (nestedBlocks.length > 0) nestedBlocks.push("");
                nestedBlocks.push(...nestedLines);
            }
        }

        // Only emit the namespace block if there's something inside (body or nested scopes).
        if (body.length > 0 || nestedBlocks.length > 0) {
            out.push(`${indent}namespace ${decl.name} {`);
            out.push(...body);
            if (body.length > 0 && nestedBlocks.length > 0) out.push("");
            out.push(...nestedBlocks);
            out.push(`${indent}}`);
        }

        return out;
    }

    private renderScopeFuncsVars(decl: ScopeDecl, parentPath: string[]): string[] {
        const path = [...parentPath, decl.name];
        const out: string[] = [];

        const body: string[] = [];
        const functions = decl.items.filter(it => it.kind === "function") as FuncDecl[];
        const variables = decl.items.filter(it => it.kind === "variable") as VarDecl[];

        for (const fn of functions) {
            if (fn.comment) body.push(...this._emitComment(fn.comment, "    "));
            const ret = this.renderReturnType(fn.returnType);
            const params: string[] = [];
            if (fn.hasThis) {
                params.push(fn.isConstThis ? "const cls* self" : "cls* self");
            }
            for (const p of fn.params) {
                let s = this.renderType(p.type);
                if (p.name) s += " " + p.name;
                params.push(s);
            }
            if (fn.isVariadic) params.push("...");
            const paramsStr = params.length > 0 ? params.join(", ") : "void";
            body.push(`    extern ${ret} (*${fn.name})(${paramsStr});`);
        }

        for (const v of variables) {
            if (v.comment) body.push(...this._emitComment(v.comment, "    "));
            const tstr = this.renderType(v.type) + "*";
            body.push(`    extern ${tstr} ${v.name};`);
        }

        if (body.length > 0) {
            out.push(...this._emitNamespaceBlock(path, body));
        }

        // Recursively emit nested scopes' functions/variables.
        const nestedScopes = decl.items.filter(it => it.kind === "scope") as ScopeDecl[];
        for (const ns of nestedScopes) {
            out.push(...this.renderScopeFuncsVars(ns, path));
        }

        return out;
    }

    // ------------------- Source generation -------------------

    genSource(): string {
        const lines: string[] = [];
        lines.push('#include "babil.h"');
        lines.push("");
        lines.push('#include "so_util.h"');
        lines.push("");
        lines.push("namespace babil {");
        lines.push("");
        lines.push("#define DECLARE(name) decltype(name) name = nullptr");

        const declLines: string[] = [];
        for (const { path, fn } of this.functions) {
            const qname = path.length > 0 ? [...path, fn.name].join("::") : fn.name;
            declLines.push(`DECLARE(${qname});`);
        }
        for (const { path, v } of this.variables) {
            const qname = path.length > 0 ? [...path, v.name].join("::") : v.name;
            declLines.push(`DECLARE(${qname});`);
        }
        if (declLines.length > 0) lines.push(...declLines);

        lines.push("#undef DECLARE");
        lines.push("");
        lines.push("#define GET_SYMBOL(name, symbol) name = reinterpret_cast<decltype(name)>(so::findAddr_rx(symbol))");
        lines.push("void init() {");
        for (const { path, fn } of this.functions) {
            const qname = path.length > 0 ? [...path, fn.name].join("::") : fn.name;
            lines.push(`    GET_SYMBOL(${qname}, "${fn.symbol}");`);
        }
        for (const { path, v } of this.variables) {
            const qname = path.length > 0 ? [...path, v.name].join("::") : v.name;
            lines.push(`    GET_SYMBOL(${qname}, "${v.symbol}");`);
        }
        lines.push("}");
        lines.push("#undef GET_SYMBOL");

        if (this.rawBlocks.has("babil.cpp")) {
            lines.push("");
            lines.push(this.rawBlocks.get("babil.cpp")!.trimEnd());
        }

        lines.push("");
        lines.push("} // namespace babil");
        const cleaned = cleanupBlankLines(lines);
        return cleaned.join("\n") + "\n";
    }
}

/** Generate babil.h and babil.cpp from a parsed .bsym AST. */
export function generateCode(items: Decl[]): { header: string; source: string; stats: { functions: number; variables: number; scopes: number; namedTypes: number; includes: number } } {
    const cg = new FullCodegen(items);
    return {
        header: cg.genHeader(),
        source: cg.genSource(),
        stats: {
            functions: cg.functions.length,
            variables: cg.variables.length,
            scopes: cg.scopes.length,
            namedTypes: cg.namedTypes.length,
            includes: cg.includes.length,
        },
    };
}
