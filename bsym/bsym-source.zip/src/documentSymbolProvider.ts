/**
 * Document symbol provider — produces the outline view (Ctrl+Shift+O) for .bsym files.
 * Top-level decls become top-level symbols; scope decls become containers with
 * their nested items as children.
 */

import * as vscode from "vscode";
import { BsymDocuments } from "./bsymDocument";
import { Decl, ScopeDecl } from "./ast";

function rangeOf(decl: Decl): vscode.Range {
    if (!decl.range) return new vscode.Range(0, 0, 0, 0);
    return new vscode.Range(
        new vscode.Position(decl.range.start.line, decl.range.start.column),
        new vscode.Position(decl.range.end.line, decl.range.end.column),
    );
}

function nameOf(decl: Decl): string {
    switch (decl.kind) {
        case "field":
            return decl.name === "unk"
                ? `unk @0x${decl.offset.toString(16)}`
                : `${decl.name} @0x${decl.offset.toString(16)}`;
        case "function":
            return `${decl.name}(${decl.params.map(p => p.name ?? "_").join(", ")})`;
        case "variable":
            return decl.name;
        case "enum":
        case "bit":
        case "struct":
        case "scope":
        case "type-alias":
        case "itype":
            return decl.name;
        case "include":
            return `include ${decl.filename}`;
        case "raw-block":
            return `:start ${decl.filename}`;
        case "anon-struct":
            return `${decl.isUnion ? "union" : "struct"} @0x${decl.offset.toString(16)}`;
    }
}

function symbolKindOf(decl: Decl): vscode.SymbolKind {
    switch (decl.kind) {
        case "field":       return vscode.SymbolKind.Field;
        case "function":    return vscode.SymbolKind.Function;
        case "variable":    return vscode.SymbolKind.Variable;
        case "enum":        return vscode.SymbolKind.Enum;
        case "bit":         return vscode.SymbolKind.Struct;
        case "struct":      return vscode.SymbolKind.Struct;
        case "scope":       return vscode.SymbolKind.Namespace;
        case "type-alias":  return vscode.SymbolKind.TypeParameter;
        case "itype":       return vscode.SymbolKind.TypeParameter;
        case "include":     return vscode.SymbolKind.Module;
        case "raw-block":   return vscode.SymbolKind.String;
        case "anon-struct": return vscode.SymbolKind.Struct;
    }
}

export class BsymDocumentSymbolProvider implements vscode.DocumentSymbolProvider {
    constructor(private docs: BsymDocuments) {}

    provideDocumentSymbols(document: vscode.TextDocument, _token: vscode.CancellationToken): vscode.ProviderResult<vscode.DocumentSymbol[]> {
        const { program } = this.docs.get(document);
        return this.collect(program.items);
    }

    private collect(items: Decl[]): vscode.DocumentSymbol[] {
        const symbols: vscode.DocumentSymbol[] = [];
        for (const it of items) {
            const sym = new vscode.DocumentSymbol(
                nameOf(it),
                detailOf(it),
                symbolKindOf(it),
                rangeOf(it),
                it.kind === "scope" || it.kind === "struct" || it.kind === "enum" || it.kind === "bit"
                    ? (it as any).nameRange
                        ? new vscode.Range(
                            new vscode.Position((it as any).nameRange.start.line, (it as any).nameRange.start.column),
                            new vscode.Position((it as any).nameRange.end.line, (it as any).nameRange.end.column),
                        )
                        : rangeOf(it)
                    : rangeOf(it),
            );
            if (it.kind === "scope") {
                sym.children = this.collect(it.items);
            }
            symbols.push(sym);
        }
        return symbols;
    }
}

function detailOf(decl: Decl): string {
    switch (decl.kind) {
        case "field":      return `0x${decl.offset.toString(16)}`;
        case "function":   return decl.symbol;
        case "variable":   return decl.symbol;
        case "enum":       return decl.underlying ? `enum : ${decl.underlying.base}` : "enum";
        case "bit":        return `bit ${decl.underlying.base}`;
        case "struct":     return decl.isUnion ? "union" : (decl.size !== null ? `struct [0x${decl.size.toString(16)}]` : "struct");
        case "scope":      return decl.size !== null ? `[0x${decl.size.toString(16)}]` : "scope";
        case "type-alias": return `= ${decl.target.base}`;
        case "itype":      return `= ${decl.actual}`;
        case "include":    return "";
        case "raw-block":  return "";
        case "anon-struct": return decl.isUnion ? "anon union" : "anon struct";
    }
}
