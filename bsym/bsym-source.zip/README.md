# BSYM Language Support

VSCode extension providing language intelligence for `.bsym` files — the declarative C++ symbol-description format used by reverse-engineering / modding projects (see `babilsym.py` and the accompanying `spec.md`).

## Features

- **Syntax highlighting** — a TextMate grammar with C++-baseline coloring plus bsym-specific extensions:
  - `include` / `type` / `itype` are highlighted as **declaration directives** (preprocessor purple).
  - `bit` / `NULL` / `this` / `enum` / `struct` / `union` / `const` are highlighted as **C++ keywords** (blue).
  - Primitive types (`u8`, `u16`, `u32`, `u64`, `s8`–`s64`, `float`, `double`, `size_t`, `sptr`, `uptr`) are highlighted as **storage types** (cyan, same as C++ `int`).
  - The mangled/C symbol after `->` is highlighted as a **string** (orange).
  - The `.n` BIT(n) shorthand and struct field offsets/bit ranges are highlighted as **numbers** (green).
  - `:start` / `:end` raw-block markers are highlighted as **preprocessor directives** (purple).
  - The `unk` field name gets a special italic-styled token.
  - **Raw block content** (between `:start babil.h` / `:end babil.h`) gets full embedded C++ syntax highlighting.

- **Hover info** — hover over any declaration to see:
  - For **functions**: the C++ signature codegen would emit, the resolved symbol, and the demangled form (for mangled symbols).
  - For **variables**: the C++ declaration with the extra pointer level codegen adds.
  - For **fields**: the offset, the type, and the codegen field name (e.g. `unk` → `m_0x0`).
  - For **enums / bitfields / structs**: a full codegen preview of the C++ definition.
  - For **scopes**: contained-item counts and cls-generation rules.
  - For **primitives** (`u8`, `s32`, …): the underlying C++ type and size.
  - For **keywords** (`include`, `type`, …): a short description of what they do.

- **Symbol demangling** — built-in Itanium C++ ABI demangler decodes mangled symbols like `_ZN3sys13GameParameter9setSaveNoEh` into `sys::GameParameter::setSaveNo(unsigned char)`. Handles nested names, CV-qualifiers, pointer/reference/const qualifiers, builtin types, variadic `z`, and substitution references (`S_`, `S0_`, …).

- **Diagnostics** — real-time syntax error reporting with line/column precision:
  - Lexer errors (unknown characters, unterminated raw blocks).
  - Parser errors (missing `;`, unbalanced braces, unexpected tokens, missing `->` symbol, etc.).
  - Semantic warnings: overlapping field offsets, duplicate names, unknown types, bit ranges where `lo > hi`.

- **Outline view** — `Ctrl+Shift+O` opens a structured outline of all top-level and scope-nested decls.

- **Semantic tokens** — theme-independent coloring that works on any VSCode theme (Dark+, Light+, One Dark Pro, etc.) by emitting standard semantic token classifications.

- **Code generation** — a **"Generate babil.h / babil.cpp"** button appears in the editor title bar (top-right, next to the split-view button) when a `.bsym` file is open. Click it to generate `babil.h` and `babil.cpp` in the same directory as the `.bsym` file (or a configurable output directory). The codegen is a self-contained TypeScript port of `babilsym.py` — no external Python dependency required. The output is **byte-for-byte identical** to the Python reference implementation.

## Installation

### From source (development)

```bash
cd bsym-vscode
npm install
npm run compile
```

Then in VSCode, press `F5` to launch an Extension Development Host with the extension loaded. Open any `.bsym` file to see it in action.

### From a packaged .vsix

```bash
code --install-extension bsym-0.1.0.vsix
```

Or via the VSCode UI: Extensions panel → `…` menu → "Install from VSIX…" → select `bsym-0.1.0.vsix`.

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `bsym.diagnostics.enabled` | `true` | Enable real-time syntax error diagnostics. |
| `bsym.diagnostics.maxProblems` | `200` | Maximum number of diagnostic problems reported per file. |
| `bsym.hover.showDemangledSymbol` | `true` | Show the demangled C++ name when hovering over a mangled symbol. |
| `bsym.hover.showCodegen` | `true` | Show the codegen preview when hovering over a declaration. |
| `bsym.semanticTokens.enabled` | `true` | Enable semantic token provider for theme-independent coloring. |
| `bsym.codegen.outputDirectory` | `""` | Directory to write `babil.h` and `babil.cpp`. Empty = same directory as the `.bsym` file. Relative paths are resolved against the workspace root. |
| `bsym.codegen.openAfterGenerate` | `true` | Automatically open the generated `babil.h` in a new editor tab after generation. |

## Project Structure

```
bsym-vscode/
├── package.json                  # Extension manifest (contributes languages, grammars, config)
├── language-configuration.json  # Bracket matching, comment toggles, folding rules
├── syntaxes/
│   └── bsym.tmLanguage.json      # TextMate grammar (syntax highlighting)
├── src/
│   ├── extension.ts              # Activation point — registers all providers
│   ├── lexer.ts                  # Tokenizer (port of lex() in babilsym.py)
│   ├── ast.ts                    # AST type definitions
│   ├── parser.ts                 # Recursive-descent parser (port of Parser class)
│   ├── codegen.ts                # C++ codegen helpers (for hover previews)
│   ├── fullCodegen.ts            # Full babil.h/babil.cpp codegen (port of babilsym.py)
│   ├── demangle.ts               # Itanium C++ ABI demangler
│   ├── bsymDocument.ts           # Document manager with parse cache
│   ├── hoverProvider.ts          # Hover info provider
│   ├── diagnosticsProvider.ts    # Syntax + semantic diagnostics
│   ├── documentSymbolProvider.ts # Outline view
│   └── semanticTokensProvider.ts # Theme-independent token classification
└── tsconfig.json
```

## References

- `.bsym` Format Specification (v0.3) — see `spec.md` for the full grammar and codegen rules.
- `babilsym.py` — the reference lexer/parser/codegen implementation.
- Itanium C++ ABI mangling spec: https://itanium-cxx-abi.github.io/cxx-abi/abi.html#mangling

## License

MIT
