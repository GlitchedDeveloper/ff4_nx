/**
 * Diagnostics provider — runs the parser on every change and reports syntax
 * errors as VSCode diagnostics (red squiggles in the Problems panel and inline).
 *
 * Also performs a few lightweight semantic checks beyond pure syntax:
 *   - Struct field offsets that go backwards.
 *   - Bit ranges where lo > hi (already caught by parser).
 *   - Duplicate top-level decl names.
 *   - Undefined scope references in field types (best-effort).
 */

import * as vscode from "vscode";
import { BsymDocuments } from "./bsymDocument";
import { Decl, FieldDecl, ScopeDecl, StructDecl, FuncDecl, VarDecl, TypeRef, BitDecl } from "./ast";
import { TypeRegistry, typeSize } from "./codegen";

export class BsymDiagnosticsProvider {
    constructor(private docs: BsymDocuments) {}

    /** Compute diagnostics for one document. */
    compute(document: vscode.TextDocument): vscode.Diagnostic[] {
        const cfg = vscode.workspace.getConfiguration("bsym");
        if (!cfg.get<boolean>("diagnostics.enabled", true)) return [];
        const max = cfg.get<number>("diagnostics.maxProblems", 200);

        const { program, registry } = this.docs.get(document);
        const diags: vscode.Diagnostic[] = [];

        // 1. Lexer/parser errors (already accumulated).
        for (const e of program.errors) {
            const range = new vscode.Range(
                new vscode.Position(e.range.start.line, e.range.start.column),
                new vscode.Position(e.range.end.line, e.range.end.column),
            );
            diags.push(new vscode.Diagnostic(
                range,
                e.message,
                e.severity === "warning" ? vscode.DiagnosticSeverity.Warning : vscode.DiagnosticSeverity.Error,
            ));
            if (diags.length >= max) return diags;
        }

        // 2. Semantic checks.
        this.checkStructOffsets(program.items, diags, document, registry);
        if (diags.length >= max) return diags;

        this.checkDuplicateNames(program.items, diags, document, []);
        if (diags.length >= max) return diags;

        this.checkUnknownTypes(program.items, registry, diags, document);
        if (diags.length >= max) return diags;

        return diags;
    }

    /** Check offset validity for all offset-based decls: structs, scopes, and bits.
     *  Detects:
     *    - Field/bit-range overlaps
     *    - Fields extending past the declared size
     *    - Calculated size exceeding the declared size
     *    - Bit ranges exceeding the underlying type's bit width
     */
    private checkStructOffsets(items: Decl[], diags: vscode.Diagnostic[], doc: vscode.TextDocument, registry: TypeRegistry) {
        for (const it of items) {
            if (it.kind === "scope") {
                // Check the scope's cls fields (if any).
                const fields = it.items.filter(sub => sub.kind === "field") as FieldDecl[];
                if (fields.length > 0) {
                    this.checkFields(fields, it.size, diags, registry);
                }
                // Recurse into nested items.
                this.checkStructOffsets(it.items, diags, doc, registry);
                continue;
            }
            if (it.kind === "struct" && !it.isUnion) {
                this.checkFields(it.fields, it.size, diags, registry);
            }
            if (it.kind === "bit") {
                this.checkBitFields(it, diags);
            }
        }
    }

    /** Check a list of fields for overlap and size-overflow errors. */
    private checkFields(fields: FieldDecl[], declaredSize: number | null, diags: vscode.Diagnostic[], registry: TypeRegistry) {
        let prevEnd = 0;
        let prevName = "<start>";
        let prevSize = 0;
        for (const f of fields) {
            if (f.offset < prevEnd) {
                const r = f.range;
                if (r) {
                    const range = new vscode.Range(
                        new vscode.Position(r.start.line, r.start.column),
                        new vscode.Position(r.end.line, r.end.column),
                    );
                    diags.push(new vscode.Diagnostic(
                        range,
                        `Field '${f.name}' at offset 0x${f.offset.toString(16)} overlaps previous field '${prevName}' (ends at 0x${prevEnd.toString(16)})`,
                        vscode.DiagnosticSeverity.Error,
                    ));
                }
            }
            if (f.range) {
                const fieldSize = typeSize(f.type, f.arraySizes, registry);
                prevEnd = f.offset + fieldSize;
                prevName = f.name;
                prevSize = fieldSize;
            }
        }
        // Check: does the last field exceed the declared size?
        if (declaredSize !== null && prevEnd > declaredSize) {
            const lastField = fields[fields.length - 1];
            if (lastField && lastField.range) {
                const r = lastField.range;
                const range = new vscode.Range(
                    new vscode.Position(r.start.line, r.start.column),
                    new vscode.Position(r.end.line, r.end.column),
                );
                diags.push(new vscode.Diagnostic(
                    range,
                    `Field '${lastField.name}' (offset 0x${lastField.offset.toString(16)}, size ${prevSize}) exceeds declared size 0x${declaredSize.toString(16)}`,
                    vscode.DiagnosticSeverity.Error,
                ));
            }
        }
        // Check: calculated size (last field end) exceeds declared size.
        // This is similar to the check above but reported as a size mismatch
        // rather than a field-overflow, for clarity.
        if (declaredSize !== null && fields.length > 0 && prevEnd > declaredSize) {
            // Already reported above as field-overflow; don't double-report.
        }
    }

    /** Check bitfield entries for overlap and type-width overflow. */
    private checkBitFields(decl: BitDecl, diags: vscode.Diagnostic[]) {
        const u = decl.underlying.base;
        const totalMap: Record<string, number> = {
            "u8": 8, "u16": 16, "u32": 32, "u64": 64,
            "s8": 8, "s16": 16, "s32": 32, "s64": 64,
        };
        const totalBits = totalMap[u] ?? 32;

        // Sort entries by lo bit for overlap detection.
        const sorted = [...decl.entries].sort((a, b) => a.range.lo - b.range.lo);
        let prevHi = -1;  // last used bit (inclusive)
        let prevName = "<start>";
        for (const e of sorted) {
            // Overlap check: current lo <= previous hi means overlap.
            if (e.range.lo <= prevHi) {
                const r = e.nameRange || e.rangeRange;
                if (r) {
                    const range = new vscode.Range(
                        new vscode.Position(r.start.line, r.start.column),
                        new vscode.Position(r.end.line, r.end.column),
                    );
                    diags.push(new vscode.Diagnostic(
                        range,
                        `Bit field '${e.name}' (bits ${e.range.lo}-${e.range.hi}) overlaps previous field '${prevName}' (ends at bit ${prevHi})`,
                        vscode.DiagnosticSeverity.Error,
                    ));
                }
            }
            // Exceeds type width check.
            if (e.range.hi >= totalBits) {
                const r = e.nameRange || e.rangeRange;
                if (r) {
                    const range = new vscode.Range(
                        new vscode.Position(r.start.line, r.start.column),
                        new vscode.Position(r.end.line, r.end.column),
                    );
                    diags.push(new vscode.Diagnostic(
                        range,
                        `Bit field '${e.name}' (bit ${e.range.hi}) exceeds underlying type '${u}' width (${totalBits} bits)`,
                        vscode.DiagnosticSeverity.Error,
                    ));
                }
            }
            prevHi = e.range.hi;
            prevName = e.name;
        }
    }

    /** Check for duplicate top-level / scope-level names.
     *  Fields and functions/variables are tracked separately — a field can
     *  share a name with a function/variable without conflict. */
    private checkDuplicateNames(items: Decl[], diags: vscode.Diagnostic[], doc: vscode.TextDocument, path: string[]) {
        const seenFields = new Map<string, Decl>();
        const seenFuncsVars = new Map<string, Decl>();
        const seenTypes = new Map<string, Decl>();
        for (const it of items) {
            const name = (it as any).name as string | undefined;
            if (!name) continue;
            // 'unk' is a special field name that translates to m_0xOFFSET at codegen.
            if (name === "unk") continue;

            // Pick the right bucket: fields vs functions/variables vs types/scopes.
            let bucket: Map<string, Decl>;
            if (it.kind === "field") {
                bucket = seenFields;
            } else if (it.kind === "function" || it.kind === "variable") {
                bucket = seenFuncsVars;
            } else {
                bucket = seenTypes;
            }

            const prev = bucket.get(name);
            if (prev) {
                const r = (it as any).nameRange || (it as any).range;
                if (r) {
                    const range = new vscode.Range(
                        new vscode.Position(r.start.line, r.start.column),
                        new vscode.Position(r.end.line, r.end.column),
                    );
                    diags.push(new vscode.Diagnostic(
                        range,
                        `Duplicate name '${name}' in this scope`,
                        vscode.DiagnosticSeverity.Warning,
                    ));
                }
            } else {
                bucket.set(name, it);
            }
            if (it.kind === "scope") {
                this.checkDuplicateNames(it.items, diags, doc, [...path, it.name]);
            }
        }
    }

    /** Check for type references that don't resolve to a known primitive, scope, named type, itype, or alias. */
    private checkUnknownTypes(items: Decl[], registry: TypeRegistry, diags: vscode.Diagnostic[], doc: vscode.TextDocument) {
        const visit = (decls: Decl[]) => {
            for (const it of decls) {
                if (it.kind === "scope") {
                    visit(it.items);
                    continue;
                }
                if (it.kind === "field" && it.type.range) {
                    this.checkTypeRef(it.type, registry, diags);
                }
                if (it.kind === "function") {
                    if (it.returnType.range) this.checkTypeRef(it.returnType, registry, diags);
                    for (const p of it.params) {
                        if (p.type.range) this.checkTypeRef(p.type, registry, diags);
                    }
                }
                if (it.kind === "variable" && it.type.range) {
                    this.checkTypeRef(it.type, registry, diags);
                }
            }
        };
        visit(items);
    }

    private checkTypeRef(t: TypeRef, registry: TypeRegistry, diags: vscode.Diagnostic[]) {
        if (!t.range) return;
        if (registry.isKnownType(t.base)) return;

        // Don't warn for scoped names whose first part isn't a known scope —
        // the type is likely defined in an included header.
        if (t.base.includes("::")) {
            const firstPart = t.base.split("::")[0];
            if (!registry.scopeNames.has(firstPart) && !registry.namedTypes.has(firstPart)) {
                return;
            }
        }

        const r = t.range;
        const range = new vscode.Range(
            new vscode.Position(r.start.line, r.start.column),
            new vscode.Position(r.end.line, r.end.column),
        );
        diags.push(new vscode.Diagnostic(
            range,
            `Unknown type '${t.base}'`,
            vscode.DiagnosticSeverity.Warning,
        ));
    }
}
