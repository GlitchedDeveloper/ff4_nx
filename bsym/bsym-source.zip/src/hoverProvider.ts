/**
 * Hover provider — shows contextual info for .bsym tokens:
 *   • Declarations (struct/enum/bit/scope/type/itype/include): a codegen preview.
 *   • Functions: the C++ signature + mangled symbol + demangled form.
 *   • Variables: the C++ declaration + symbol.
 *   • Fields: the codegen field name (m_<name>, m_0xOFFSET for unk).
 *   • Symbol after `->`: the mangled name + demangled interpretation.
 *   • Type references: hover over any type to see its C++ form + size.
 *   • Primitives (u8, s32, ...): the underlying C++ type + size.
 *   • Keywords (include/type/itype): what they do.
 *
 * Hover specificity: the provider checks sub-ranges (symbolRange, nameRange,
 * type.range) before the decl's full range, so hovering over different parts
 * of a declaration shows different info.
 */

import * as vscode from "vscode";
import { BsymDocuments } from "./bsymDocument";
import {
    Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, StructDecl, ScopeDecl,
    TypeAlias, ITypeDecl, IncludeDecl, RawBlock, TypeRef,
    PRIMITIVES, PRIMITIVE_SIZES,
} from "./ast";
import {
    TypeRegistry, renderType, renderFunctionSignature, renderVariableDeclaration,
    renderEnumPreview, renderStructPreview, renderBitPreview, fieldName, typeSize,
} from "./codegen";
import { demangle } from "./demangle";

const PRIMITIVE_DOCS: Record<string, { cpp: string; size: number }> = {
    "void":   { cpp: "void",        size: 0 },
    "bool":   { cpp: "bool",        size: 1 },
    "c8":     { cpp: "char",        size: 1 },
    "c16":    { cpp: "char16_t",    size: 2 },
    "c32":    { cpp: "char32_t",    size: 4 },
    "u8":     { cpp: "uint8_t",     size: 1 },
    "u16":    { cpp: "uint16_t",    size: 2 },
    "u32":    { cpp: "uint32_t",    size: 4 },
    "u64":    { cpp: "uint64_t",    size: 8 },
    "s8":     { cpp: "int8_t",      size: 1 },
    "s16":    { cpp: "int16_t",     size: 2 },
    "s32":    { cpp: "int32_t",     size: 4 },
    "s64":    { cpp: "int64_t",     size: 8 },
    "float":  { cpp: "float",       size: 4 },
    "double": { cpp: "double",      size: 8 },
    "size_t": { cpp: "size_t",      size: 8 },
    "sptr":   { cpp: "intptr_t",    size: 8 },
    "uptr":   { cpp: "uintptr_t",   size: 8 },
};

const KEYWORD_DOCS: Record<string, string> = {
    "include": "Declares a header to be `#include`d by the generated babil.h. Two forms: `include <file>;` (system search) or `include file.h;` (user search).",
    "type":    "Declares a type alias. Codegen emits `using NAME = TYPE;`. Useful for naming primitives (e.g. `type fx32 = s32;`).",
    "itype":   "Declares an imported type — one defined in a header pulled in via `include`. Codegen uses the actual type for size math but does not emit a typedef.",
    "enum":    "Declares a scoped enum (`enum class`). Optional underlying type. Values can be INT, `.n` (BIT(n) shorthand), NULL (→ nullptr), or float literal.",
    "bit":     "Declares a packed bitfield struct + a companion `*Mask` enum. Ranges use `INT` or `INT-INT` (lo must be ≤ hi).",
    "struct":  "Declares a `struct __attribute__((packed))` with explicit field offsets. Size is optional; if omitted, it's calculated from the last field.",
    "union":   "Declares a `union __attribute__((packed))`. Members overlay at offset 0. Size is required if the union is used as a value.",
    "const":   "Qualifier on a type or `this`. Modifies the pointee (e.g. `const s8*` is a pointer to const s8). `const this` makes a member function const.",
    "this":    "Inside a scope, `this` is the implicit `cls*` first argument of a member function. As a type, it refers to the current scope's `cls`.",
    "NULL":    "Value literal that expands to `nullptr` at codegen. Allowed in enum values and bit constants.",
};

export class BsymHoverProvider implements vscode.HoverProvider {
    constructor(private docs: BsymDocuments) {}

    provideHover(document: vscode.TextDocument, position: vscode.Position, _token: vscode.CancellationToken): vscode.ProviderResult<vscode.Hover> {
        const { program, registry } = this.docs.get(document);
        const cfg = vscode.workspace.getConfiguration("bsym");
        const showDemangled = cfg.get<boolean>("hover.showDemangledSymbol", true);
        const showCodegen = cfg.get<boolean>("hover.showCodegen", true);

        // 0a. Check if hovering over a .n BIT shorthand — show BIT(n) info
        const bitShortRange = document.getWordRangeAtPosition(position, /\.\d+/);
        if (bitShortRange) {
            const text = document.getText(bitShortRange);
            const n = parseInt(text.slice(1), 10);
            const md = new vscode.MarkdownString();
            md.isTrusted = false;
            md.supportThemeIcons = true;
            md.appendMarkdown(`**BIT shorthand** — \`${text}\`\n\n`);
            md.appendMarkdown(`Expands to \`BIT(${n})\` at codegen.\n\n`);
            md.appendMarkdown(`Value: \`0x${(1 << n).toString(16)}\` (${1 << n})\n\n`);
            return new vscode.Hover(md, bitShortRange);
        }

        // 0b. Don't show hover for plain numeric literals (0x0, 1, 0b1, floats, etc.)
        const numRange = document.getWordRangeAtPosition(position, /0x[0-9a-fA-F]+|0b[01]+|\d+\.?\d*[fF]?|\d+/);
        if (numRange) {
            return null;
        }

        // 1. Check if hovering over a symbol (after ->)
        const symResult = this.findAtPosition(program.items, position, "symbolRange");
        if (symResult) {
            const md = this.renderSymbolHover(symResult.decl, registry, showDemangled);
            if (md) return new vscode.Hover(md, this.toRange(symResult.range));
        }

        // 2. Check if hovering over a type reference
        const typeResult = this.findTypeAtPosition(program.items, position);
        if (typeResult) {
            const md = this.renderTypeRefHover(typeResult.type, registry);
            if (md) return new vscode.Hover(md, this.toRange(typeResult.type.range!));
        }

        // 3. Check if hovering over a decl name (functions, variables, types)
        const nameResult = this.findAtPosition(program.items, position, "nameRange");
        if (nameResult) {
            const md = this.renderDeclHover(nameResult.decl, registry, [], showDemangled, showCodegen);
            if (md) return new vscode.Hover(md, this.toRange(nameResult.range));
        }

        // 3b. Check if hovering over a struct/union field name
        const fieldResult = this.findFieldAtPosition(program.items, position);
        if (fieldResult) {
            const md = this.renderFieldHover(fieldResult.field, registry);
            if (md) return new vscode.Hover(md, this.toRange(fieldResult.range));
        }

        // 4. Check if hovering over an enum entry / bit constant name
        const entryResult = this.findEnumEntryAtPosition(program.items, position);
        if (entryResult) {
            const md = entryResult.hover;
            if (md) return new vscode.Hover(md, this.toRange(entryResult.range));
        }

        // 5. Fall back: find any decl whose full range contains the position
        const decl = this.findDeclAtPosition(program.items, position, []);
        if (decl) {
            const md = this.renderDeclHover(decl, registry, [], showDemangled, showCodegen);
            if (md) return new vscode.Hover(md);
        }

        // 6. Token-level lookup (primitives, keywords)
        const wordRange = document.getWordRangeAtPosition(position, /[A-Za-z_][A-Za-z0-9_]*/);
        if (wordRange) {
            const word = document.getText(wordRange);
            if (PRIMITIVE_DOCS[word]) {
                const info = PRIMITIVE_DOCS[word];
                const md = new vscode.MarkdownString();
                md.isTrusted = false;
                md.supportThemeIcons = true;
                md.appendMarkdown(`**\`${word}\`** — primitive type\n\n`);
                md.appendMarkdown(`C++ type: \`${info.cpp}\`\n\n`);
                md.appendMarkdown(`Size: \`${info.size}\` byte${info.size === 1 ? "" : "s"}\n\n`);
                md.appendMarkdown(`Defined in \`types.h\`.`);
                return new vscode.Hover(md, wordRange);
            }
            if (KEYWORD_DOCS[word]) {
                const md = new vscode.MarkdownString();
                md.isTrusted = false;
                md.supportThemeIcons = true;
                md.appendMarkdown(`**\`${word}\`** — keyword\n\n`);
                md.appendMarkdown(KEYWORD_DOCS[word]);
                return new vscode.Hover(md, wordRange);
            }
        }

        return null;
    }

    private toRange(r: any): vscode.Range {
        return new vscode.Range(
            new vscode.Position(r.start.line, r.start.column),
            new vscode.Position(r.end.line, r.end.column),
        );
    }

    /** Find a decl whose specific sub-range (symbolRange or nameRange) contains the position. */
    private findAtPosition(items: Decl[], position: vscode.Position, rangeKey: string): { decl: Decl; range: any } | null {
        for (const it of items) {
            const r = (it as any)[rangeKey];
            if (r) {
                const range = new vscode.Range(
                    new vscode.Position(r.start.line, r.start.column),
                    new vscode.Position(r.end.line, r.end.column),
                );
                if (range.contains(position)) {
                    return { decl: it, range: r };
                }
            }
            if (it.kind === "scope") {
                const nested = this.findAtPosition(it.items, position, rangeKey);
                if (nested) return nested;
            }
        }
        return null;
    }

    /** Find a type reference (in a field, function, or variable) whose range contains the position. */
    private findTypeAtPosition(items: Decl[], position: vscode.Position): { type: TypeRef; decl: Decl } | null {
        for (const it of items) {
            if (it.kind === "scope") {
                const nested = this.findTypeAtPosition(it.items, position);
                if (nested) return nested;
                continue;
            }
            if (it.kind === "field" && it.type.range) {
                if (this.rangeContains(it.type.range, position)) return { type: it.type, decl: it };
            }
            if (it.kind === "function") {
                if (it.returnType.range && this.rangeContains(it.returnType.range, position)) {
                    return { type: it.returnType, decl: it };
                }
                for (const p of it.params) {
                    if (p.type.range && this.rangeContains(p.type.range, position)) {
                        return { type: p.type, decl: it };
                    }
                }
            }
            if (it.kind === "variable" && it.type.range) {
                if (this.rangeContains(it.type.range, position)) return { type: it.type, decl: it };
            }
        }
        return null;
    }

    private rangeContains(r: any, position: vscode.Position): boolean {
        const range = new vscode.Range(
            new vscode.Position(r.start.line, r.start.column),
            new vscode.Position(r.end.line, r.end.column),
        );
        return range.contains(position);
    }

    /** Find a struct/union field (or scope field) whose nameRange contains the position. */
    private findFieldAtPosition(items: Decl[], position: vscode.Position): { field: FieldDecl; range: any } | null {
        for (const it of items) {
            if (it.kind === "scope") {
                // Check fields directly inside the scope first
                for (const sub of it.items) {
                    if (sub.kind === "field" && sub.nameRange && this.rangeContains(sub.nameRange, position)) {
                        return { field: sub, range: sub.nameRange };
                    }
                }
                // Recurse into nested scopes/structs
                const nested = this.findFieldAtPosition(it.items, position);
                if (nested) return nested;
                continue;
            }
            if (it.kind === "struct") {
                for (const f of it.fields) {
                    if (f.nameRange && this.rangeContains(f.nameRange, position)) {
                        return { field: f, range: f.nameRange };
                    }
                }
            }
        }
        return null;
    }

    /** Render hover for a single struct/union field. */
    private renderFieldHover(f: FieldDecl, registry: TypeRegistry): vscode.MarkdownString {
        const md = new vscode.MarkdownString();
        md.isTrusted = false;
        md.supportThemeIcons = true;
        const cgName = fieldName(f.name, f.offset);
        md.appendMarkdown(`**Field** — \`${f.name}\`\n\n`);
        if (f.comment) {
            md.appendMarkdown(`${escapeMarkdown(f.comment)}\n\n`);
        }
        md.appendMarkdown(`- Offset: \`0x${f.offset.toString(16)}\`\n`);
        md.appendMarkdown(`- Type: \`${renderType(f.type, registry)}\`\n`);
        if (f.arraySize !== null) {
            md.appendMarkdown(`- Array size: \`${f.arraySize}\``);
        }
        if (cgName !== f.name) {
            md.appendMarkdown(`- Codegen name: \`${cgName}\``);
        }
        const sz = typeSize(f.type, f.arraySizes, registry);
        if (sz > 0) {
            md.appendMarkdown(`- Total size: \`${sz}\` bytes\n`);
        }
        md.appendMarkdown("\n");
        return md;
    }

    /** Find an enum entry or bit constant whose nameRange contains the position. */
    private findEnumEntryAtPosition(items: Decl[], position: vscode.Position): { hover: vscode.MarkdownString; range: any } | null {
        for (const it of items) {
            if (it.kind === "scope") {
                const nested = this.findEnumEntryAtPosition(it.items, position);
                if (nested) return nested;
                continue;
            }
            if (it.kind === "enum") {
                for (const e of it.entries) {
                    if (e.nameRange && this.rangeContains(e.nameRange, position)) {
                        const md = new vscode.MarkdownString();
                        md.isTrusted = false;
                        md.supportThemeIcons = true;
                        md.appendMarkdown(`**Enum constant** — \`${it.name}::${e.name}\`\n\n`);
                        md.appendMarkdown(`Value: \`${e.rawText || e.value}\`\n\n`);
                        if (e.isBitShorthand) {
                            md.appendMarkdown(`Expands to \`BIT(${e.bitN})\` = \`0x${(1 << e.bitN).toString(16)}\` at codegen.\n\n`);
                        }
                        if (e.isNull) {
                            md.appendMarkdown(`Expands to \`nullptr\` at codegen.\n\n`);
                        }
                        md.appendMarkdown(`Referenced as \`${it.name}::${e.name}\` in C++.\n\n`);
                        return { hover: md, range: e.nameRange };
                    }
                }
            }
            if (it.kind === "bit") {
                for (const e of it.entries) {
                    if (e.nameRange && this.rangeContains(e.nameRange, position)) {
                        const md = new vscode.MarkdownString();
                        md.isTrusted = false;
                        md.supportThemeIcons = true;
                        md.appendMarkdown(`**Bit field** — \`${e.name}\`\n\n`);
                        const width = e.range.hi - e.range.lo + 1;
                        if (e.range.lo === e.range.hi) {
                            md.appendMarkdown(`Bit \`${e.range.lo}\` (1 bit wide)\n\n`);
                        } else {
                            md.appendMarkdown(`Bits \`${e.range.lo}-${e.range.hi}\` (${width} bits wide)\n\n`);
                        }
                        if (e.fieldType) {
                            md.appendMarkdown(`Field type: \`${renderType(e.fieldType, new TypeRegistry([]))}\`\n\n`);
                        } else {
                            md.appendMarkdown(`Field type: \`${it.underlying.base}\` (bitfield's underlying type)\n\n`);
                        }
                        md.appendMarkdown(`Codegen struct field: \`m_${e.name} : ${width}\`\n\n`);
                        // Mask value
                        if (width === 1) {
                            md.appendMarkdown(`Mask enum entry: \`${e.name} = BIT(${e.range.lo})\` → \`0x${(1 << e.range.lo).toString(16)}\`\n\n`);
                        } else {
                            const mask = ((1 << width) - 1) << e.range.lo;
                            md.appendMarkdown(`Mask enum entry: \`${e.name} = 0x${mask.toString(16)}\`\n\n`);
                        }
                        md.appendMarkdown(`Appears in both the packed struct and the \`${it.name}Mask\` enum.\n\n`);
                        return { hover: md, range: e.nameRange };
                    }
                }
                for (const c of it.constants) {
                    if (c.nameRange && this.rangeContains(c.nameRange, position)) {
                        const md = new vscode.MarkdownString();
                        md.isTrusted = false;
                        md.supportThemeIcons = true;
                        md.appendMarkdown(`**Bit constant** — \`${c.name}\`\n\n`);
                        md.appendMarkdown(`Value: \`${c.rawText || c.value}\`\n\n`);
                        md.appendMarkdown(`Appears in the \`${it.name}Mask\` enum only (no struct field).\n\n`);
                        return { hover: md, range: c.nameRange };
                    }
                }
            }
        }
        return null;
    }

    /** Walk the decl tree to find a decl whose range contains `position`. */
    private findDeclAtPosition(items: Decl[], position: vscode.Position, path: string[]): Decl | null {
        for (const it of items) {
            if (!it.range) continue;
            const r = new vscode.Range(
                new vscode.Position(it.range.start.line, it.range.start.column),
                new vscode.Position(it.range.end.line, it.range.end.column),
            );
            if (!r.contains(position)) continue;

            if (it.kind === "scope") {
                const nested = this.findDeclAtPosition(it.items, position, [...path, it.name]);
                if (nested) return nested;
            }
            return it;
        }
        return null;
    }

    /** Render hover for a symbol reference (after `->`). */
    private renderSymbolHover(decl: Decl, registry: TypeRegistry, showDemangled: boolean): vscode.MarkdownString | null {
        const symbol = (decl as any).symbol as string | undefined;
        if (!symbol) return null;
        const md = new vscode.MarkdownString();
        md.isTrusted = false;
        md.supportThemeIcons = true;
        md.appendMarkdown(`**Symbol** — \`${symbol}\`\n\n`);
        if (showDemangled) {
            const d = demangle(symbol);
            if (d.mangled) {
                md.appendMarkdown(`**Demangled:** \`${d.text}\`\n\n`);
                if (d.isConstMethod) md.appendMarkdown(`Const member function.\n\n`);
                md.appendMarkdown(`Resolved at runtime via \`so::findAddr_rx("${symbol}")\`.\n\n`);
            } else {
                md.appendMarkdown(`C-style symbol (not mangled). Resolved at runtime via \`so::findAddr_rx("${symbol}")\`.\n\n`);
            }
        }
        return md;
    }

    /** Render hover for a type reference. */
    private renderTypeRefHover(t: TypeRef, registry: TypeRegistry): vscode.MarkdownString | null {
        const md = new vscode.MarkdownString();
        md.isTrusted = false;
        md.supportThemeIcons = true;
        md.appendMarkdown(`**Type** — \`${t.base}\`\n\n`);

        if (t.base === "this") {
            md.appendMarkdown(`Refers to the current scope's \`cls\` type. Used as a shorthand in member function return types and field types.\n\n`);
            return md;
        }

        if (PRIMITIVE_DOCS[t.base]) {
            const info = PRIMITIVE_DOCS[t.base];
            md.appendMarkdown(`Primitive type. C++: \`${info.cpp}\`, size: \`${info.size}\` bytes.\n\n`);
        } else if (registry.aliases.has(t.base)) {
            const target = registry.aliases.get(t.base)!;
            md.appendMarkdown(`Type alias. Target: \`${renderType(target, registry)}\`\n\n`);
            md.appendMarkdown(`Codegen emits: \`using ${t.base} = ${renderType(target, registry)};\`\n\n`);
        } else if (registry.itypes.has(t.base)) {
            const actual = registry.itypes.get(t.base)!;
            md.appendMarkdown(`Imported type. Actual: \`${actual}\`\n\n`);
            md.appendMarkdown(`Defined in an included header. Codegen uses \`${t.base}\` as-is (no typedef emitted).\n\n`);
        } else if (registry.isScopeName(t.base)) {
            md.appendMarkdown(`Scope reference. Codegen appends \`::cls\` → \`${t.base}::cls\`\n\n`);
        } else if (registry.namedTypes.has(t.base) || registry.namedTypePaths.has(t.base)) {
            md.appendMarkdown(`Named type (struct/enum/bit). Referenced by its bare name in C++.\n\n`);
        } else {
            md.appendMarkdown(`External type (defined in an included header or elsewhere).\n\n`);
        }

        const cppType = renderType(t, registry);
        md.appendMarkdown(`Rendered C++ type: \`${cppType}\`\n\n`);

        const sz = typeSize(t, null, registry);
        if (sz > 0) {
            md.appendMarkdown(`Size: \`${sz}\` byte${sz === 1 ? "" : "s"}\n\n`);
        }

        if (t.pointerCount > 0) {
            md.appendMarkdown(`Pointer levels: \`${t.pointerCount}\` (renders as ${"*".repeat(t.pointerCount)})\n\n`);
        }
        if (t.isConst) {
            md.appendMarkdown(`\`const\`-qualified pointee.\n\n`);
        }
        if (t.isReference) {
            md.appendMarkdown(`Reference (\`&\`).\n\n`);
        }
        return md;
    }

    /** Render hover markdown for a specific decl. */
    private renderDeclHover(
        decl: Decl,
        registry: TypeRegistry,
        path: string[],
        showDemangled: boolean,
        showCodegen: boolean,
    ): vscode.MarkdownString | null {
        const md = new vscode.MarkdownString();
        md.isTrusted = false;
        md.supportThemeIcons = true;

        switch (decl.kind) {
            case "function": {
                md.appendMarkdown(`**Function** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`\n${escapeMarkdown(decl.comment)}\n\n`);
                }
                if (showCodegen) {
                    const sig = renderFunctionSignature(decl, registry);
                    md.appendMarkdown("```cpp\n" + sig + "\n```\n\n");
                }
                if (decl.symbol) {
                    md.appendMarkdown(`**Symbol:** \`${decl.symbol}\`\n\n`);
                    if (showDemangled) {
                        const d = demangle(decl.symbol);
                        if (d.mangled) {
                            md.appendMarkdown(`**Demangled:** \`${d.text}\`\n\n`);
                            if (d.isConstMethod) md.appendMarkdown(`Const member function\n\n`);
                        } else if (decl.symbol.match(/^[A-Za-z_][A-Za-z0-9_]*$/)) {
                            md.appendMarkdown(`C-style symbol (not mangled). Resolved via \`so::findAddr_rx("${decl.symbol}")\`.\n\n`);
                        }
                    }
                }
                if (decl.params.length > 0) {
                    md.appendMarkdown("**Parameters:**\n\n");
                    for (const p of decl.params) {
                        const ts = renderType(p.type, registry);
                        md.appendMarkdown(`- \`${ts}\`${p.name ? ` — \`${p.name}\`` : ""}\n`);
                    }
                    md.appendMarkdown("\n");
                }
                if (decl.hasThis) {
                    md.appendMarkdown(`First argument: \`${decl.isConstThis ? "const cls* self" : "cls* self"}\`\n\n`);
                }
                if (decl.isVariadic) {
                    md.appendMarkdown(`Variadic — accepts additional arguments after the listed parameters.\n\n`);
                }
                return md;
            }

            case "variable": {
                md.appendMarkdown(`**Variable** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`\n${escapeMarkdown(decl.comment)}\n\n`);
                }
                if (showCodegen) {
                    const sig = renderVariableDeclaration(decl, registry);
                    md.appendMarkdown("```cpp\n" + sig + "\n```\n\n");
                    md.appendMarkdown(`Codegen adds one pointer level — the declared type is the pointee type, the actual C++ is a pointer to it.\n\n`);
                }
                if (decl.symbol) {
                    md.appendMarkdown(`**Symbol:** \`${decl.symbol}\`\n\n`);
                    if (showDemangled) {
                        const d = demangle(decl.symbol);
                        if (d.mangled) {
                            md.appendMarkdown(`**Demangled:** \`${d.text}\`\n\n`);
                        } else {
                            md.appendMarkdown(`C-style symbol (not mangled).\n\n`);
                        }
                    }
                }
                return md;
            }

            case "field": {
                const cgName = fieldName(decl.name, decl.offset);
                md.appendMarkdown(`**Field** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }
                md.appendMarkdown(`- Offset: \`0x${decl.offset.toString(16)}\`\n`);
                md.appendMarkdown(`- Type: \`${renderType(decl.type, registry)}\`\n`);
                if (decl.arraySize !== null) {
                    md.appendMarkdown(`- Array size: \`${decl.arraySize}\`\n`);
                }
                if (cgName !== decl.name) {
                    md.appendMarkdown(`- Codegen name: \`${cgName}\`\n`);
                }
                const sz = typeSize(decl.type, decl.arraySizes, registry);
                if (sz > 0) {
                    md.appendMarkdown(`- Total size: \`${sz}\` bytes\n`);
                }
                md.appendMarkdown("\n");
                return md;
            }

            case "enum": {
                md.appendMarkdown(`**Enum** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }
                md.appendMarkdown(`Emitted as \`enum class\` (scoped). Reference values as \`${decl.name}::Value\`.\n\n`);
                if (showCodegen) {
                    md.appendMarkdown("```cpp\n" + renderEnumPreview(decl, registry) + "\n```\n\n");
                }
                if (decl.entries.length > 0) {
                    md.appendMarkdown(`**Entries** (${decl.entries.length}):\n\n`);
                    for (const e of decl.entries.slice(0, 25)) {
                        md.appendMarkdown(`- \`${e.name}\` = \`${e.rawText || e.value}\`\n`);
                    }
                    if (decl.entries.length > 25) {
                        md.appendMarkdown(`- _…and ${decl.entries.length - 25} more_\n`);
                    }
                    md.appendMarkdown("\n");
                }
                return md;
            }

            case "bit": {
                md.appendMarkdown(`**Bitfield** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }
                md.appendMarkdown(`Underlying type: \`${renderType(decl.underlying, registry)}\`\n\n`);
                md.appendMarkdown(`Generates two C++ types: a packed struct and a companion \`${decl.name}Mask\` enum.\n\n`);
                if (showCodegen) {
                    md.appendMarkdown("```cpp\n" + renderBitPreview(decl, registry) + "\n```\n\n");
                }
                if (decl.entries.length > 0) {
                    md.appendMarkdown(`**Bit fields** (${decl.entries.length}):\n\n`);
                    for (const e of decl.entries) {
                        if (e.range.lo === e.range.hi) {
                            md.appendMarkdown(`- bit \`${e.range.lo}\`: \`${e.name}\`\n`);
                        } else {
                            md.appendMarkdown(`- bits \`${e.range.lo}-${e.range.hi}\` (${e.range.hi - e.range.lo + 1} bits): \`${e.name}\`\n`);
                        }
                    }
                    md.appendMarkdown("\n");
                }
                if (decl.constants.length > 0) {
                    md.appendMarkdown(`**Named constants** (${decl.constants.length}):\n\n`);
                    for (const c of decl.constants) {
                        md.appendMarkdown(`- \`${c.name}\` = \`${c.rawText || c.value}\`\n`);
                    }
                    md.appendMarkdown("\n");
                }
                return md;
            }

            case "struct": {
                const kw = decl.isUnion ? "Union" : "Struct";
                md.appendMarkdown(`**${kw}** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }
                if (decl.size !== null) {
                    md.appendMarkdown(`Size: \`0x${decl.size.toString(16)}\` (${decl.size} bytes)\n\n`);
                } else if (decl.fields.length > 0) {
                    const last = decl.fields[decl.fields.length - 1];
                    const calcSize = last.offset + typeSize(last.type, last.arraySizes, registry);
                    md.appendMarkdown(`Calculated size: \`0x${calcSize.toString(16)}\` (${calcSize} bytes)\n\n`);
                    md.appendMarkdown(`(No explicit size — calculated from last field offset + size.)\n\n`);
                }
                md.appendMarkdown(`Emitted with \`__attribute__((packed))\`.\n\n`);
                if (showCodegen) {
                    md.appendMarkdown("```cpp\n" + renderStructPreview(decl, registry) + "\n```\n\n");
                }
                if (decl.fields.length > 0) {
                    md.appendMarkdown(`**Fields** (${decl.fields.length}):\n\n`);
                    for (const f of decl.fields.slice(0, 30)) {
                        const cg = fieldName(f.name, f.offset);
                        md.appendMarkdown(`- \`0x${f.offset.toString(16)}\`: \`${renderType(f.type, registry)}\` \`${cg}\`${f.arraySize !== null ? ` [${f.arraySize}]` : ""}\n`);
                    }
                    if (decl.fields.length > 30) {
                        md.appendMarkdown(`- _…and ${decl.fields.length - 30} more_\n`);
                    }
                    md.appendMarkdown("\n");
                }
                return md;
            }

            case "scope": {
                md.appendMarkdown(`**Scope** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }

                const fields = decl.items.filter(it => it.kind === "field") as FieldDecl[];
                const hasCls = fields.length > 0 || decl.size !== null ||
                    decl.items.some(it => it.kind === "function" && (it as FuncDecl).hasThis);

                if (decl.size !== null) {
                    md.appendMarkdown(`cls size: \`0x${decl.size.toString(16)}\` (${decl.size} bytes)\n\n`);
                } else if (fields.length > 0) {
                    const last = fields[fields.length - 1];
                    const calcSize = last.offset + typeSize(last.type, last.arraySizes, registry);
                    md.appendMarkdown(`Calculated cls size: \`0x${calcSize.toString(16)}\` (${calcSize} bytes)\n\n`);
                }

                md.appendMarkdown(`Emitted as \`namespace ${decl.name} { ... }\`.\n\n`);

                if (hasCls) {
                    md.appendMarkdown(`A \`struct __attribute__((packed)) cls\` is generated inside this namespace because:\n`);
                    if (fields.length > 0) md.appendMarkdown(`- Has ${fields.length} field${fields.length === 1 ? "" : "s"}\n`);
                    if (decl.size !== null) md.appendMarkdown(`- Has an explicit size\n`);
                    if (decl.items.some(it => it.kind === "function" && (it as FuncDecl).hasThis)) {
                        md.appendMarkdown(`- Has member functions (using \`this\`)\n`);
                    }
                    md.appendMarkdown("\n");

                    if (showCodegen) {
                        md.appendMarkdown("```cpp\n");
                        md.appendMarkdown(`struct __attribute__((packed)) cls {\n`);
                        if (fields.length > 0 || decl.size !== null) {
                            let cursor = 0;
                            let padIdx = 0;
                            for (const f of fields) {
                                if (f.offset > cursor) {
                                    md.appendMarkdown(`    u8 _pad${padIdx}[${f.offset - cursor}]; // 0x${cursor.toString(16)}\n`);
                                    padIdx++;
                                    cursor = f.offset;
                                }
                                const tstr = renderType(f.type, registry);
                                const arrStr = f.arraySizes.map(s => `[${s}]`).join("");
                                const fname = fieldName(f.name, f.offset);
                                md.appendMarkdown(`    ${tstr} ${fname}${arrStr}; // 0x${f.offset.toString(16)}\n`);
                                cursor = f.offset + typeSize(f.type, f.arraySizes, registry);
                            }
                            if (decl.size !== null && cursor < decl.size) {
                                md.appendMarkdown(`    u8 _pad${padIdx}[${decl.size - cursor}]; // 0x${cursor.toString(16)}\n`);
                            }
                        }
                        md.appendMarkdown("};\n");
                        if (decl.size !== null) {
                            md.appendMarkdown(`static_assert(sizeof(cls) == 0x${decl.size.toString(16)});\n`);
                        }
                        for (const f of fields) {
                            const fname = fieldName(f.name, f.offset);
                            md.appendMarkdown(`static_assert(offsetof(cls, ${fname}) == 0x${f.offset.toString(16)});\n`);
                        }
                        md.appendMarkdown("```\n\n");
                    }
                }

                const counts = countScopeItems(decl);
                md.appendMarkdown(`Contains: ${counts.fields} field${counts.fields === 1 ? "" : "s"}, ${counts.functions} function${counts.functions === 1 ? "" : "s"}, ${counts.variables} variable${counts.variables === 1 ? "" : "s"}, ${counts.nested} nested item${counts.nested === 1 ? "" : "s"}.\n\n`);
                return md;
            }

            case "type-alias": {
                md.appendMarkdown(`**Type alias** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }
                md.appendMarkdown(`Target: \`${renderType(decl.target, registry)}\`\n\n`);
                md.appendMarkdown(`Codegen: \`using ${decl.name} = ${renderType(decl.target, registry)};\`\n\n`);
                return md;
            }

            case "itype": {
                md.appendMarkdown(`**Imported type** — \`${decl.name}\`\n\n`);
                if (decl.comment) {
                    md.appendMarkdown(`${escapeMarkdown(decl.comment)}\n\n`);
                }
                md.appendMarkdown(`Actual type: \`${decl.actual}\`\n\n`);
                md.appendMarkdown(`Defined in an included header. Codegen uses the actual type (\`${decl.actual}\`) for size calculations but does not emit a typedef.\n\n`);
                return md;
            }

            case "include": {
                md.appendMarkdown(`**Include** — \`${decl.filename}\`\n\n`);
                if (decl.filename.startsWith("<") && decl.filename.endsWith(">")) {
                    md.appendMarkdown(`Emitted as \`#include ${decl.filename}\` (system search path).\n\n`);
                } else {
                    md.appendMarkdown(`Emitted as \`#include "${decl.filename}"\` (user search path).\n\n`);
                }
                md.appendMarkdown(`Codegen always prepends \`#include "so_util.h"\` and \`#include "types.h"\` before user-specified includes.\n\n`);
                return md;
            }

            case "raw-block": {
                md.appendMarkdown(`**Raw block** — \`${decl.filename}\`\n\n`);
                md.appendMarkdown(`Content between \`:start ${decl.filename}\` and \`:end ${decl.filename}\` is appended verbatim to the named output file.\n\n`);
                md.appendMarkdown(`Supported filenames: \`babil.h\`, \`babil.cpp\`.\n\n`);
                return md;
            }
        }

        return null;
    }
}

function countScopeItems(scope: ScopeDecl): { fields: number; functions: number; variables: number; nested: number } {
    let fields = 0, functions = 0, variables = 0, nested = 0;
    for (const it of scope.items) {
        switch (it.kind) {
            case "field": fields++; break;
            case "function": functions++; break;
            case "variable": variables++; break;
            case "scope":
            case "struct":
            case "enum":
            case "bit":
                nested++; break;
        }
    }
    return { fields, functions, variables, nested };
}

function escapeMarkdown(s: string): string {
    return s.replace(/[*_`\\]/g, "\\$&");
}
