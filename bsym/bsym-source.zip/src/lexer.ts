/**
 * Lexer for .bsym — straight port of lex() in babilsym.py.
 * Tokenizes source text into a stream of typed tokens with line/col tracking.
 */

export type TokenKind =
    | "COMMENT"
    | "RAW_BLOCK"
    | "include" | "type" | "itype" | "enum" | "bit" | "struct" | "union"
    | "const" | "this" | "NULL"
    | "IDENT"
    | "INT"               // value: { value: number, raw: string }
    | "FLOAT"             // value: string (preserved raw)
    | "BIT_SHORTHAND"     // value: number (the n in BIT(n))
    | "..."
    | "->"
    | "::"
    | "{" | "}" | "(" | ")" | "[" | "]" | ";" | "," | ":" | "=" | "*" | "&" | "." | "<" | ">" | "/" | "-"
    | "EOF";

export interface Token {
    kind: TokenKind;
    value: any;
    line: number;        // 1-indexed (matches Python)
    col: number;         // 1-indexed
    startOffset: number; // absolute char offset in source
    endOffset: number;
}

const KEYWORDS: Record<string, TokenKind> = {
    "include": "include",
    "type": "type",
    "itype": "itype",
    "enum": "enum",
    "bit": "bit",
    "struct": "struct",
    "union": "union",
    "const": "const",
    "this": "this",
    "NULL": "NULL",
};

function isIdentStart(c: string): boolean {
    return /[A-Za-z_\\]/.test(c);
}
function isIdentCont(c: string): boolean {
    return /[A-Za-z0-9_]/.test(c);
}
function isDigit(c: string): boolean {
    return c >= "0" && c <= "9";
}
function isHexDigit(c: string): boolean {
    return isDigit(c) || (c >= "a" && c <= "f") || (c >= "A" && c <= "F");
}

export class LexError extends Error {
    range: { line: number; col: number; startOffset: number; endOffset: number };
    constructor(message: string, line: number, col: number, startOffset: number, endOffset: number) {
        super(message);
        this.name = "LexError";
        this.range = { line, col, startOffset, endOffset };
    }
}

/**
 * Tokenize .bsym source text. Throws LexError on malformed input (e.g. unknown char,
 * unterminated raw block).
 */
export function lex(text: string): Token[] {
    const tokens: Token[] = [];
    let i = 0;
    const n = text.length;
    let line = 1;
    let col = 1;
    let lineStart = 0; // offset of start of current line

    function pos(offset: number): { line: number; col: number } {
        // Compute line/col for an absolute offset.
        let l = 1;
        let ls = 0;
        for (let k = 0; k < offset; k++) {
            if (text[k] === "\n") {
                l++;
                ls = k + 1;
            }
        }
        return { line: l, col: offset - ls + 1 };
    }

    function emit(kind: TokenKind, value: any, startOff: number, endOff: number): void {
        const p1 = pos(startOff);
        const p2 = pos(endOff);
        tokens.push({
            kind,
            value,
            line: p1.line,
            col: p1.col,
            startOffset: startOff,
            endOffset: endOff,
        });
        // Suppress unused-variable warning for p2 in a no-op.
        void p2;
    }

    while (i < n) {
        const c = text[i];

        // Newline
        if (c === "\n") {
            i++;
            line++;
            col = 1;
            lineStart = i;
            continue;
        }
        if (c === " " || c === "\t" || c === "\r") {
            i++;
            col++;
            continue;
        }

        // Line comment
        if (c === "/" && i + 1 < n && text[i + 1] === "/") {
            const start = i;
            let j = i;
            while (j < n && text[j] !== "\n") j++;
            const commentText = text.slice(i + 2, j).trim();
            if (commentText) {
                emit("COMMENT", commentText, start, j);
            }
            i = j;
            continue;
        }

        // :start / :end raw blocks
        if (c === ":" && text.slice(i, i + 6) === ":start") {
            const startOff = i;
            let j = i + 6;
            while (j < n && (text[j] === " " || text[j] === "\t")) j++;
            const fnameStart = j;
            while (j < n && (isIdentCont(text[j]) || text[j] === "." || text[j] === "/")) j++;
            const filename = text.slice(fnameStart, j);
            while (j < n && text[j] !== "\n") j++;
            if (j < n) j++; // consume newline
            const endMarker = `:end ${filename}`;
            const contentStart = j;
            let searchPos = j;
            let found = false;
            let endPos = -1;
            let endNewline = -1;
            while (searchPos < n) {
                let nl = searchPos;
                while (nl < n && text[nl] !== "\n") nl++;
                const lineText = text.slice(searchPos, nl).trim();
                if (lineText === endMarker) {
                    let content = text.slice(contentStart, searchPos);
                    if (content.endsWith("\n")) content = content.slice(0, -1);
                    const endOffset = nl < n ? nl + 1 : nl;
                    emit("RAW_BLOCK", { filename, content }, startOff, endOffset);
                    i = endOffset;
                    found = true;
                    endPos = endOffset;
                    endNewline = nl;
                    break;
                }
                if (nl >= n) break;
                searchPos = nl + 1;
            }
            if (!found) {
                const p = pos(startOff);
                throw new LexError(
                    `Lexer: missing :end ${filename} for :start at line ${p.line}`,
                    p.line, p.col, startOff, startOff + 6,
                );
            }
            void endPos;
            void endNewline;
            continue;
        }

        // Identifier or keyword
        if (isIdentStart(c)) {
            const start = i;
            let j = i + 1;  // skip the first char (already validated by isIdentStart)
            while (j < n && isIdentCont(text[j])) j++;
            const ident = text.slice(i, j);
            const kw = KEYWORDS[ident];
            if (kw) {
                emit(kw, ident, start, j);
            } else {
                emit("IDENT", ident, start, j);
            }
            col += j - i;
            i = j;
            continue;
        }

        // Number
        if (isDigit(c)) {
            const start = i;
            let j = i;
            if (text[i] === "0" && i + 1 < n && (text[i + 1] === "x" || text[i + 1] === "X")) {
                j = i + 2;
                while (j < n && isHexDigit(text[j])) j++;
                const raw = text.slice(i, j);
                const value = parseInt(raw, 16);
                emit("INT", { value, raw }, start, j);
            } else if (text[i] === "0" && i + 1 < n && (text[i + 1] === "b" || text[i + 1] === "B")) {
                j = i + 2;
                while (j < n && (text[j] === "0" || text[j] === "1")) j++;
                const raw = text.slice(i, j);
                const value = parseInt(raw.slice(2), 2);
                emit("INT", { value, raw }, start, j);
            } else {
                while (j < n && isDigit(text[j])) j++;
                let isFloat = false;
                if (j < n && text[j] === "." && j + 1 < n && isDigit(text[j + 1])) {
                    isFloat = true;
                    j++;
                    while (j < n && isDigit(text[j])) j++;
                }
                if (j < n && text[j] === "f") {
                    isFloat = true;
                    j++;
                }
                if (isFloat) {
                    emit("FLOAT", text.slice(i, j), start, j);
                } else {
                    const raw = text.slice(i, j);
                    const value = parseInt(raw, 10);
                    emit("INT", { value, raw }, start, j);
                }
            }
            col += j - i;
            i = j;
            continue;
        }

        // .n shorthand — dot followed by digits, not preceded by digit
        if (c === "." && i + 1 < n && isDigit(text[i + 1])) {
            const start = i;
            let j = i + 1;
            while (j < n && isDigit(text[j])) j++;
            const nValue = parseInt(text.slice(i + 1, j), 10);
            emit("BIT_SHORTHAND", nValue, start, j);
            col += j - i;
            i = j;
            continue;
        }

        // Variadic ellipsis
        if (c === "." && text.slice(i, i + 3) === "...") {
            emit("...", "...", i, i + 3);
            i += 3;
            col += 3;
            continue;
        }

        // Multi-char punctuation
        if (text.slice(i, i + 2) === "->") {
            emit("->", "->", i, i + 2);
            i += 2;
            col += 2;
            continue;
        }
        if (text.slice(i, i + 2) === "::") {
            emit("::", "::", i, i + 2);
            i += 2;
            col += 2;
            continue;
        }

        // Single-char punctuation
        if ("{}()[];,:=*&.<>/-".includes(c)) {
            emit(c as TokenKind, c, i, i + 1);
            i++;
            col++;
            continue;
        }

        // Unknown char
        const p = pos(i);
        throw new LexError(
            `Lexer: unknown character ${JSON.stringify(c)} at line ${p.line}, col ${p.col}`,
            p.line, p.col, i, i + 1,
        );
    }

    emit("EOF", null, n, n);
    return tokens;
}
