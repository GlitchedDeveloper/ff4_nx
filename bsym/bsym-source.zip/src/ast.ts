/**
 * AST type definitions for the .bsym language.
 * Ported from babilsym.py (dataclass-based AST).
 */

export interface Position {
    line: number;   // 0-indexed
    column: number; // 0-indexed
    offset: number; // absolute char offset
}

export interface Range {
    start: Position;
    end: Position;
}

export interface TypeRef {
    base: string;            // primitive name, scoped name, or "this"
    isConst: boolean;
    pointerCount: number;
    isReference: boolean;
    range?: Range;           // span of the base type token (excludes */&)
}

export interface FieldDecl {
    kind: "field";
    offset: number;
    offsetRaw: string;       // original text of the offset (e.g. "0x4", "15", "95*8")
    type: TypeRef;
    name: string;
    arraySize: number | null;       // legacy: first array dimension (or null)
    arraySizeRaw: string | null;    // legacy: raw text of first array dimension
    arraySizes: number[];           // all array dimensions (e.g. [3, 1000] for u8[3][1000])
    arraySizesRaw: string[];        // raw text of all array dimensions
    comment: string | null;
    range?: Range;           // span of the field declaration
    nameRange?: Range;       // span of just the field name
}

export interface ParamDecl {
    type: TypeRef;
    name: string | null;
    isThis: boolean;
    isConstThis: boolean;
    isVariadic: boolean;
    range?: Range;
    nameRange?: Range;  // span of just the parameter name (if named)
}

export interface FuncDecl {
    kind: "function";
    returnType: TypeRef;
    name: string;
    params: ParamDecl[];
    hasThis: boolean;
    isConstThis: boolean;
    isVariadic: boolean;
    symbol: string;
    comment: string | null;
    range?: Range;
    nameRange?: Range;
    symbolRange?: Range;     // span of the mangled/C symbol after ->
}

export interface VarDecl {
    kind: "variable";
    type: TypeRef;
    name: string;
    arraySize: number | null;       // legacy: first array dimension (or null)
    arraySizeRaw: string | null;    // legacy: raw text of first array dimension
    arraySizes: number[];           // all array dimensions
    arraySizesRaw: string[];        // raw text of all array dimensions
    symbol: string;
    comment: string | null;
    range?: Range;
    nameRange?: Range;
    symbolRange?: Range;
}

export interface EnumEntry {
    name: string;
    value: number;
    rawText: string;
    isBitShorthand: boolean;
    bitN: number;
    isNull: boolean;
    isFloat: boolean;
    nameRange?: Range;
    valueRange?: Range;
}

export interface EnumDecl {
    kind: "enum";
    name: string;
    underlying: TypeRef | null;
    entries: EnumEntry[];
    comment: string | null;
    range?: Range;
    nameRange?: Range;
    bodyRange?: Range;
}

export interface BitRange {
    lo: number;
    hi: number;
}

export interface BitEntry {
    range: BitRange;
    name: string;
    fieldType: TypeRef | null;
    nameRange?: Range;
    rangeRange?: Range;
}

export interface BitConstant {
    name: string;
    value: number;
    rawText: string;
    isBitShorthand: boolean;
    bitN: number;
    isNull: boolean;
    isFloat: boolean;
    nameRange?: Range;
    valueRange?: Range;
}

export interface BitDecl {
    kind: "bit";
    name: string;
    underlying: TypeRef;
    entries: BitEntry[];
    constants: BitConstant[];
    comment: string | null;
    range?: Range;
    nameRange?: Range;
    bodyRange?: Range;
}

export interface StructDecl {
    kind: "struct";
    name: string;
    size: number | null;
    sizeRaw: string | null;   // original text of the size (e.g. "0x10", "16")
    fields: FieldDecl[];      // named fields only
    items?: Decl[];           // ALL items including anon-structs (fields + anon blocks in order)
    comment: string | null;
    isUnion: boolean;
    range?: Range;
    nameRange?: Range;
    bodyRange?: Range;
}

export interface ScopeDecl {
    kind: "scope";
    name: string;
    size: number | null;
    sizeRaw: string | null;   // original text of the size
    items: Decl[];
    comment: string | null;
    range?: Range;
    nameRange?: Range;
    bodyRange?: Range;
}

export interface TypeAlias {
    kind: "type-alias";
    name: string;
    target: TypeRef;
    comment: string | null;
    range?: Range;
    nameRange?: Range;
}

export interface ITypeDecl {
    kind: "itype";
    name: string;
    actual: string;
    comment: string | null;
    range?: Range;
    nameRange?: Range;
}

export interface IncludeDecl {
    kind: "include";
    filename: string;
    comment: string | null;
    range?: Range;
}

export interface RawBlock {
    kind: "raw-block";
    filename: string;
    content: string;
    range?: Range;        // span of the whole block (including markers)
    bodyRange?: Range;    // span of just the content between markers
}

/** Anonymous union or struct embedded in a parent struct/scope.
 *  Parsed as `offset : { members };` (anonymous union) or
 *  `offset : struct { members };` (anonymous struct). */
export interface AnonStructDecl {
    kind: "anon-struct";
    offset: number;
    offsetRaw: string;
    isUnion: boolean;       // true = anonymous union, false = anonymous struct
    fields: FieldDecl[];    // members (each has offset relative to the anon block's start)
    comment: string | null;
    range?: Range;
}

export type Decl =
    | FieldDecl
    | FuncDecl
    | VarDecl
    | EnumDecl
    | BitDecl
    | StructDecl
    | ScopeDecl
    | TypeAlias
    | ITypeDecl
    | IncludeDecl
    | RawBlock
    | AnonStructDecl;

export interface Program {
    items: Decl[];
    errors: ParseError[];
}

export interface ParseError {
    message: string;
    range: Range;
    severity: "error" | "warning";
}

/** Built-in primitive types (defined in types.h). */
export const PRIMITIVES = new Set<string>([
    "void", "bool",
    "u8", "u16", "u32", "u64",
    "s8", "s16", "s32", "s64",
    "c8", "c16", "c32",
    "float", "double",
    "size_t", "sptr", "uptr",
]);

/** Primitive sizes (bytes), used for layout / hover info. */
export const PRIMITIVE_SIZES: Record<string, number> = {
    "void": 0, "bool": 1,
    "u8": 1, "u16": 2, "u32": 4, "u64": 8,
    "s8": 1, "s16": 2, "s32": 4, "s64": 8,
    "c8": 1, "c16": 2, "c32": 4,
    "float": 4, "double": 8,
    "size_t": 8, "sptr": 8, "uptr": 8,
};
