/**
 * Semantic tokens provider — emits token type/modifier classifications that
 * VSCode maps to the active theme's colors. This makes the coloring work on
 * ANY theme (Dark+, Light+, One Dark Pro, etc.) by using standard semantic
 * token types rather than hard-coded scope names.
 *
 * Emits tokens for:
 *   - Decl names (function, variable, field, enum, struct, scope, etc.)
 *   - Symbols after `->` (as 'string' for orange)
 *   - Type references in fields, function returns, params, and variables (as 'type' for cyan)
 *   - Parameter names (as 'parameter' for light blue)
 *   - Enum/bit entry names (as 'type' for cyan)
 *   - `unk` field names (with 'deprecated' modifier for italic styling)
 */

import * as vscode from "vscode";
import { BsymDocuments } from "./bsymDocument";
import { Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, ScopeDecl, TypeRef, PRIMITIVES } from "./ast";

const TOKEN_TYPES = [
    "keyword",
    "macro",
    "type",
    "class",
    "function",
    "variable",
    "property",
    "string",
    "number",
    "comment",
    "operator",
    "namespace",
    "enumMember",
    "parameter",
];

const TOKEN_MODIFIERS = [
    "declaration",
    "definition",
    "readonly",
    "static",
    "deprecated",
    "modification",
    "documentation",
    "defaultLibrary",
];

export const LEGEND = new vscode.SemanticTokensLegend(TOKEN_TYPES, TOKEN_MODIFIERS);

export class BsymSemanticTokensProvider implements vscode.DocumentSemanticTokensProvider {
    constructor(private docs: BsymDocuments) {}

    provideDocumentSemanticTokens(document: vscode.TextDocument, _token: vscode.CancellationToken): vscode.ProviderResult<vscode.SemanticTokens> {
        const { program } = this.docs.get(document);
        const builder = new vscode.SemanticTokensBuilder(LEGEND);

        const visit = (items: Decl[]) => {
            for (const it of items) {
                this.emitDecl(builder, it);
                if (it.kind === "scope") {
                    visit(it.items);
                }
                // Also visit struct fields so they get enumMember tokens (teal).
                if (it.kind === "struct") {
                    for (const f of it.fields) {
                        this.emitDecl(builder, f);
                    }
                }
            }
        };
        visit(program.items);

        return builder.build();
    }

    private emitDecl(builder: vscode.SemanticTokensBuilder, decl: Decl) {
        // Emit the name as the appropriate semantic token type.
        const nameRange = (decl as any).nameRange;
        if (nameRange) {
            const typeIdx = this.nameTypeIndex(decl);
            const mods = this.nameModifierIndex(decl);
            builder.push(
                new vscode.Range(
                    new vscode.Position(nameRange.start.line, nameRange.start.column),
                    new vscode.Position(nameRange.end.line, nameRange.end.column),
                ),
                TOKEN_TYPES[typeIdx],
                mods,
            );
        }

        // Emit the symbol after -> as 'string' (orange).
        const symRange = (decl as any).symbolRange;
        if (symRange) {
            builder.push(
                new vscode.Range(
                    new vscode.Position(symRange.start.line, symRange.start.column),
                    new vscode.Position(symRange.end.line, symRange.end.column),
                ),
                "string",
                [],
            );
        }

        // Italicize `unk` field names — emit as variable with 'deprecated' modifier
        if (decl.kind === "field" && decl.name === "unk" && decl.nameRange) {
            builder.push(
                new vscode.Range(
                    new vscode.Position(decl.nameRange.start.line, decl.nameRange.start.column),
                    new vscode.Position(decl.nameRange.end.line, decl.nameRange.end.column),
                ),
                "variable",
                ["deprecated"],
            );
        }

        // Emit type-reference tokens for fields, functions, and variables.
        // This ensures type aliases like `fx32` get the cyan type color even
        // when the TextMate grammar classifies them as `variable.other`.
        if (decl.kind === "field") {
            this.emitTypeRef(builder, decl.type);
        }
        if (decl.kind === "function") {
            this.emitTypeRef(builder, decl.returnType);
            for (const p of decl.params) {
                this.emitTypeRef(builder, p.type);
            }
        }
        if (decl.kind === "variable") {
            this.emitTypeRef(builder, decl.type);
        }

        // Emit parameter-name tokens (light blue) for named function parameters.
        if (decl.kind === "function") {
            for (const p of decl.params) {
                if (p.nameRange) {
                    builder.push(
                        new vscode.Range(
                            new vscode.Position(p.nameRange.start.line, p.nameRange.start.column),
                            new vscode.Position(p.nameRange.end.line, p.nameRange.end.column),
                        ),
                        "parameter",
                        [],
                    );
                }
            }
        }

        // Emit enum entry names as 'enumMember' (cyan — distinct from type green).
        if (decl.kind === "enum") {
            for (const e of decl.entries) {
                if (e.nameRange) {
                    builder.push(
                        new vscode.Range(
                            new vscode.Position(e.nameRange.start.line, e.nameRange.start.column),
                            new vscode.Position(e.nameRange.end.line, e.nameRange.end.column),
                        ),
                        "enumMember",
                        [],
                    );
                }
            }
        }

        // Emit bit field names and constant names as 'enumMember' (cyan).
        if (decl.kind === "bit") {
            for (const e of decl.entries) {
                if (e.nameRange) {
                    builder.push(
                        new vscode.Range(
                            new vscode.Position(e.nameRange.start.line, e.nameRange.start.column),
                            new vscode.Position(e.nameRange.end.line, e.nameRange.end.column),
                        ),
                        "enumMember",
                        [],
                    );
                }
            }
            for (const c of decl.constants) {
                if (c.nameRange) {
                    builder.push(
                        new vscode.Range(
                            new vscode.Position(c.nameRange.start.line, c.nameRange.start.column),
                            new vscode.Position(c.nameRange.end.line, c.nameRange.end.column),
                        ),
                        "enumMember",
                        [],
                    );
                }
            }
        }
    }

    /** Emit a semantic token for a type reference (the base type name). */
    private emitTypeRef(builder: vscode.SemanticTokensBuilder, t: TypeRef) {
        if (!t.range) return;
        if (t.base === "this") return;
        // Primitives are handled by the grammar (storage.type) — no need to override.
        if (PRIMITIVES.has(t.base)) return;
        // Scoped names (e.g. sys::GameParameter) are handled by the grammar's
        // #scoped-name rule, which colors each name part as entity.name.type (green)
        // and each :: as keyword.other (blue). If we emit a semantic token here,
        // it would cover the whole scoped name and override the :: coloring.
        if (t.base.includes("::")) return;
        builder.push(
            new vscode.Range(
                new vscode.Position(t.range.start.line, t.range.start.column),
                new vscode.Position(t.range.end.line, t.range.end.column),
            ),
            "type",
            [],
        );
    }

    private nameTypeIndex(decl: Decl): number {
        switch (decl.kind) {
            case "function":    return TOKEN_TYPES.indexOf("function");
            case "variable":    return TOKEN_TYPES.indexOf("variable");
            case "field":       return TOKEN_TYPES.indexOf("variable");
            case "enum":        return TOKEN_TYPES.indexOf("type");
            case "bit":         return TOKEN_TYPES.indexOf("type");
            case "struct":      return TOKEN_TYPES.indexOf("type");
            case "scope":       return TOKEN_TYPES.indexOf("type");
            case "type-alias":  return TOKEN_TYPES.indexOf("type");
            case "itype":       return TOKEN_TYPES.indexOf("type");
            case "include":     return TOKEN_TYPES.indexOf("keyword");
            case "raw-block":   return TOKEN_TYPES.indexOf("macro");
            case "anon-struct": return TOKEN_TYPES.indexOf("type");
        }
    }

    private nameModifierIndex(decl: Decl): string[] {
        const mods: string[] = ["declaration"];
        if (decl.kind === "function" || decl.kind === "variable") {
            mods.push("definition");
        }
        return mods;
    }
}
