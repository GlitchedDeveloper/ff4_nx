/**
 * Standalone smoke-test for the parser, demangler, and codegen helpers.
 * Run with: node out/test-parser.js
 */

import * as fs from "fs";
import * as path from "path";
import { parse } from "./parser";
import { TypeRegistry, renderFunctionSignature, renderVariableDeclaration, renderStructPreview, renderBitPreview, renderEnumPreview, renderType } from "./codegen";
import { demangle } from "./demangle";
import { Decl, FuncDecl, VarDecl, StructDecl, BitDecl, EnumDecl, ScopeDecl } from "./ast";

function main() {
    const args = process.argv.slice(2);
    const bsymPath = args[0] || "/home/z/my-project/upload/babil.bsym";
    const text = fs.readFileSync(bsymPath, "utf8");

    console.log(`Parsing ${bsymPath} (${text.length} bytes)...`);
    const t0 = Date.now();
    const { items, errors } = parse(text);
    const t1 = Date.now();
    console.log(`  Parsed in ${t1 - t0}ms`);
    console.log(`  ${items.length} top-level items`);
    console.log(`  ${errors.length} errors`);

    // Count by kind.
    const counts: Record<string, number> = {};
    function visit(decls: Decl[]) {
        for (const d of decls) {
            counts[d.kind] = (counts[d.kind] || 0) + 1;
            if (d.kind === "scope") visit(d.items);
        }
    }
    visit(items);
    console.log("  Top-level + nested decl counts by kind:", counts);

    // Show first 10 errors.
    if (errors.length > 0) {
        console.log("\nFirst 10 errors:");
        for (const e of errors.slice(0, 10)) {
            console.log(`  L${e.range.start.line + 1}:C${e.range.start.column + 1}: ${e.message}`);
        }
    }

    // Test the registry + codegen.
    const registry = new TypeRegistry(items);
    console.log(`\nRegistry:`);
    console.log(`  ${registry.scopeNames.size} scopes`);
    console.log(`  ${registry.namedTypes.size} named types`);
    console.log(`  ${registry.aliases.size} aliases`);
    console.log(`  ${registry.itypes.size} itypes`);

    // Show some function signatures with demangling.
    let n = 0;
    function showFuncs(decls: Decl[], path: string[]) {
        for (const d of decls) {
            if (d.kind === "function" && n < 8) {
                n++;
                const qname = path.length ? [...path, d.name].join("::") : d.name;
                console.log(`\n  Function: ${qname}`);
                console.log(`    C++ sig: ${renderFunctionSignature(d, registry)}`);
                console.log(`    Symbol:  ${d.symbol}`);
                const dem = demangle(d.symbol);
                console.log(`    Demang:  ${dem.mangled ? dem.text : "(not mangled)"}`);
            }
            if (d.kind === "scope") {
                showFuncs(d.items, [...path, d.name]);
            }
        }
    }
    console.log("\nSample function declarations:");
    showFuncs(items, []);

    // Show some struct previews.
    n = 0;
    function showStructs(decls: Decl[]) {
        for (const d of decls) {
            if (d.kind === "struct" && n < 3 && d.fields.length > 0) {
                n++;
                console.log(`\n  Struct ${d.name}[${d.size !== null ? "0x" + d.size.toString(16) : "?"}]:`);
                const preview = renderStructPreview(d, registry);
                for (const line of preview.split("\n").slice(0, 6)) {
                    console.log(`    ${line}`);
                }
                if (preview.split("\n").length > 6) {
                    console.log(`    ... (${preview.split("\n").length - 6} more lines)`);
                }
            }
            if (d.kind === "scope") {
                showStructs(d.items);
            }
        }
    }
    console.log("\nSample struct previews:");
    showStructs(items);

    // Test the demangler with known cases.
    console.log("\nDemangler tests:");
    const cases = [
        "_ZN3sys13GameParameter9setSaveNoEh",
        "_ZNK3sys13GameParameter13fieldSymbolIDEv",
        "_Z9OS_PrintfPKcz",
        "_Z6FX_Divii",
        "_ZN2ui10CWidgetMng9addWidgetEiiiiiiiij",
        "_ZN2mr21MonsterRefDataManager4loadEv",
        "_Z27babilCommand_ClearCountJumpR12ScriptEngine",
        "fontScale",   // not mangled
        "_ZN3sys13GameParameter11gpInstance_E",  // variable
    ];
    for (const c of cases) {
        const d = demangle(c);
        console.log(`  ${c}`);
        console.log(`    → mangled=${d.mangled}  text="${d.text}"`);
    }

    console.log("\n✓ Smoke test complete");
}

main();
