/**
 * BSYM Language Support — extension entry point.
 *
 * Activates on .bsym files. Registers:
 *   • Hover info provider (decl info + symbol demangling + codegen preview)
 *   • Diagnostics provider (syntax + lightweight semantic checks)
 *   • Document symbol provider (outline view)
 *   • Semantic tokens provider (theme-independent coloring)
 *   • "Generate babil.h / babil.cpp" command (button in the editor title bar)
 *
 * The TextMate grammar in syntaxes/bsym.tmLanguage.json provides the
 * base syntax highlighting; this file augments it with language intelligence.
 */

import * as vscode from "vscode";
import * as path from "path";
import * as fs from "fs";
import { BsymDocuments } from "./bsymDocument";
import { BsymHoverProvider } from "./hoverProvider";
import { BsymDiagnosticsProvider } from "./diagnosticsProvider";
import { BsymDocumentSymbolProvider } from "./documentSymbolProvider";
import { BsymSemanticTokensProvider, LEGEND } from "./semanticTokensProvider";
import { generateCode } from "./fullCodegen";
import { formatProgram, DEFAULT_FORMAT_OPTIONS } from "./formatter";
import { reorganize } from "./reorganizer";

const BSYM_LANG = "bsym";

let documents: BsymDocuments;
let diagnosticsProvider: BsymDiagnosticsProvider;
let diagnosticCollection: vscode.DiagnosticCollection;

export function activate(context: vscode.ExtensionContext): void {
    console.log("[bsym] activating BSYM extension");

    documents = new BsymDocuments();
    diagnosticsProvider = new BsymDiagnosticsProvider(documents);
    diagnosticCollection = vscode.languages.createDiagnosticCollection("bsym");
    context.subscriptions.push(diagnosticCollection);

    // ---- Hover info ----
    context.subscriptions.push(
        vscode.languages.registerHoverProvider(
            BSYM_LANG,
            new BsymHoverProvider(documents),
        ),
    );

    // ---- Outline / document symbols ----
    context.subscriptions.push(
        vscode.languages.registerDocumentSymbolProvider(
            BSYM_LANG,
            new BsymDocumentSymbolProvider(documents),
        ),
    );

    // ---- Semantic tokens (theme-independent coloring) ----
    const cfg = vscode.workspace.getConfiguration("bsym");
    if (cfg.get<boolean>("semanticTokens.enabled", true)) {
        context.subscriptions.push(
            vscode.languages.registerDocumentSemanticTokensProvider(
                BSYM_LANG,
                new BsymSemanticTokensProvider(documents),
                LEGEND,
            ),
        );
    }

    // ---- Diagnostics: refresh on open, debounced on change ----
    const refreshDiagnostics = (doc: vscode.TextDocument) => {
        if (doc.languageId !== BSYM_LANG) return;
        const diags = diagnosticsProvider.compute(doc);
        diagnosticCollection.set(doc.uri, diags);
    };

    // Debounce timers per-document — wait 500ms after the last keystroke
    // before re-running diagnostics. This prevents lag on large files where
    // every keystroke would otherwise trigger a full re-parse.
    const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();
    const DEBOUNCE_MS = 500;

    const debouncedRefresh = (doc: vscode.TextDocument) => {
        if (doc.languageId !== BSYM_LANG) return;
        const key = doc.uri.toString();
        const existing = debounceTimers.get(key);
        if (existing) clearTimeout(existing);
        const timer = setTimeout(() => {
            debounceTimers.delete(key);
            // Re-fetch the document in case it was closed during the debounce window.
            const stillOpen = vscode.workspace.textDocuments.find(d => d.uri.toString() === key);
            if (stillOpen) refreshDiagnostics(stillOpen);
        }, DEBOUNCE_MS);
        debounceTimers.set(key, timer);
    };

    // Initial pass on all open .bsym documents.
    for (const doc of vscode.workspace.textDocuments) {
        refreshDiagnostics(doc);
    }

    context.subscriptions.push(
        vscode.workspace.onDidOpenTextDocument(refreshDiagnostics),
    );
    context.subscriptions.push(
        vscode.workspace.onDidChangeTextDocument((e) => {
            if (e.document.languageId !== BSYM_LANG) return;
            documents.invalidate(e.document.uri);
            debouncedRefresh(e.document);
        }),
    );
    context.subscriptions.push(
        vscode.workspace.onDidCloseTextDocument((doc) => {
            if (doc.languageId !== BSYM_LANG) return;
            // Cancel any pending debounced refresh for this document.
            const key = doc.uri.toString();
            const timer = debounceTimers.get(key);
            if (timer) {
                clearTimeout(timer);
                debounceTimers.delete(key);
            }
            documents.invalidate(doc.uri);
            diagnosticCollection.set(doc.uri, undefined);
        }),
    );

    // ---- Configuration change: re-run diagnostics if the user toggles them ----
    context.subscriptions.push(
        vscode.workspace.onDidChangeConfiguration((e) => {
            if (e.affectsConfiguration("bsym")) {
                for (const doc of vscode.workspace.textDocuments) {
                    if (doc.languageId === BSYM_LANG) {
                        documents.invalidate(doc.uri);
                        refreshDiagnostics(doc);
                    }
                }
            }
        }),
    );

    // ---- Generate babil.h / babil.cpp command ----
    context.subscriptions.push(
        vscode.commands.registerCommand("bsym.generateCode", async (uri?: vscode.Uri) => {
            // Resolve the target .bsym document. If invoked from the editor title bar,
            // `uri` is the file's URI. If invoked from the command palette, use the
            // active editor's document.
            let doc: vscode.TextDocument | undefined;
            if (uri) {
                try {
                    doc = await vscode.workspace.openTextDocument(uri);
                } catch {
                    doc = undefined;
                }
            }
            if (!doc) {
                const active = vscode.window.activeTextEditor;
                if (active && active.document.languageId === BSYM_LANG) {
                    doc = active.document;
                }
            }
            if (!doc || doc.languageId !== BSYM_LANG) {
                vscode.window.showWarningMessage("BSYM: No .bsym file is currently open.");
                return;
            }

            // Parse the document.
            const { program } = documents.get(doc);

            // Check for parse errors — abort if there are any.
            if (program.errors.length > 0) {
                const yes = "Generate Anyway";
                const no = "Cancel";
                const choice = await vscode.window.showWarningMessage(
                    `BSYM: ${program.errors.length} parse error(s) in this file. Generate code anyway?`,
                    yes,
                    no,
                );
                if (choice !== yes) return;
            }

            // Generate.
            let result;
            try {
                result = generateCode(program.items);
            } catch (e: any) {
                vscode.window.showErrorMessage(`BSYM codegen failed: ${e?.message ?? String(e)}`);
                return;
            }

            // Determine output directory.
            const config = vscode.workspace.getConfiguration("bsym");
            const outDirSetting = config.get<string>("codegen.outputDirectory", "");
            const bsymDir = path.dirname(doc.uri.fsPath);
            let outDir: string;
            if (outDirSetting && outDirSetting.trim().length > 0) {
                // If the setting is a relative path, resolve it relative to the workspace.
                if (path.isAbsolute(outDirSetting)) {
                    outDir = outDirSetting;
                } else {
                    const ws = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? bsymDir;
                    outDir = path.join(ws, outDirSetting);
                }
            } else {
                outDir = bsymDir;
            }

            // Write the files.
            const headerPath = path.join(outDir, "babil.h");
            const sourcePath = path.join(outDir, "babil.cpp");
            try {
                fs.mkdirSync(outDir, { recursive: true });
                fs.writeFileSync(headerPath, result.header, "utf8");
                fs.writeFileSync(sourcePath, result.source, "utf8");
            } catch (e: any) {
                vscode.window.showErrorMessage(`BSYM: Failed to write output files: ${e?.message ?? String(e)}`);
                return;
            }

            const stats = result.stats;
            const msg = `Generated babil.h (${result.header.length} bytes) and babil.cpp (${result.source.length} bytes) — ${stats.functions} functions, ${stats.variables} variables, ${stats.scopes} scopes, ${stats.namedTypes} named types, ${stats.includes} includes.`;
            vscode.window.showInformationMessage(msg, "Open babil.h", "Open babil.cpp").then(async (choice) => {
                if (choice === "Open babil.h") {
                    await vscode.workspace.openTextDocument(vscode.Uri.file(headerPath));
                    await vscode.commands.executeCommand("vscode.open", vscode.Uri.file(headerPath));
                } else if (choice === "Open babil.cpp") {
                    await vscode.workspace.openTextDocument(vscode.Uri.file(sourcePath));
                    await vscode.commands.executeCommand("vscode.open", vscode.Uri.file(sourcePath));
                }
            });

            // Auto-open babil.h if configured.
            if (config.get<boolean>("codegen.openAfterGenerate", true)) {
                await vscode.commands.executeCommand("vscode.open", vscode.Uri.file(headerPath));
            }
        }),
    );

    // ---- Beautify (format document) command ----
    context.subscriptions.push(
        vscode.commands.registerCommand("bsym.beautify", async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor || editor.document.languageId !== BSYM_LANG) {
                vscode.window.showWarningMessage("BSYM: No .bsym file is currently open.");
                return;
            }
            const doc = editor.document;
            const { program } = documents.get(doc);
            const formatted = formatProgram(program.items, DEFAULT_FORMAT_OPTIONS);
            const fullRange = new vscode.Range(
                new vscode.Position(0, 0),
                new vscode.Position(doc.lineCount, 0),
            );
            await editor.edit(eb => eb.replace(fullRange, formatted));
        }),
    );

    // ---- Reorganize (merge + sort + format) command ----
    context.subscriptions.push(
        vscode.commands.registerCommand("bsym.reorganize", async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor || editor.document.languageId !== BSYM_LANG) {
                vscode.window.showWarningMessage("BSYM: No .bsym file is currently open.");
                return;
            }
            const doc = editor.document;
            const { program } = documents.get(doc);
            const result = reorganize(program.items);
            if (!result.ok) {
                vscode.window.showErrorMessage(`BSYM reorganize failed: ${result.error}`);
                return;
            }
            const formatted = formatProgram(result.items!, DEFAULT_FORMAT_OPTIONS);
            const fullRange = new vscode.Range(
                new vscode.Position(0, 0),
                new vscode.Position(doc.lineCount, 0),
            );
            await editor.edit(eb => eb.replace(fullRange, formatted));
            vscode.window.showInformationMessage("BSYM: Reorganized — globals at top, scopes sorted alphabetically, duplicates merged.");
        }),
    );

    // ---- Document formatting provider (Shift+Alt+F / Format Document) ----
    context.subscriptions.push(
        vscode.languages.registerDocumentFormattingEditProvider(BSYM_LANG, {
            provideDocumentFormattingEdits(document: vscode.TextDocument): vscode.TextEdit[] {
                const { program } = documents.get(document);
                const formatted = formatProgram(program.items, DEFAULT_FORMAT_OPTIONS);
                const fullRange = new vscode.Range(
                    new vscode.Position(0, 0),
                    new vscode.Position(document.lineCount, 0),
                );
                return [vscode.TextEdit.replace(fullRange, formatted)];
            },
        }),
    );

    // ---- Format on save ----
    context.subscriptions.push(
        vscode.workspace.onWillSaveTextDocument((e) => {
            if (e.document.languageId !== BSYM_LANG) return;
            const cfg = vscode.workspace.getConfiguration("bsym");
            if (!cfg.get<boolean>("format.onSave", false)) return;
            const { program } = documents.get(e.document);
            const formatted = formatProgram(program.items, DEFAULT_FORMAT_OPTIONS);
            const fullRange = new vscode.Range(
                new vscode.Position(0, 0),
                new vscode.Position(e.document.lineCount, 0),
            );
            e.waitUntil(Promise.resolve([vscode.TextEdit.replace(fullRange, formatted)]));
        }),
    );

    console.log("[bsym] BSYM extension activated");
}

export function deactivate(): void {
    if (documents) documents.clear();
    if (diagnosticCollection) diagnosticCollection.clear();
}
