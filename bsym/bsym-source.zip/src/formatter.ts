/**
 * Formatter — renders a parsed .bsym AST back to formatted .bsym source text.
 *
 * Format rules (user-selected defaults):
 *   • 4 spaces indentation
 *   • Opening brace on same line as decl
 *   • Align offsets within a struct/scope (pad to same width)
 *   • Space before colon in offsets and bit ranges: `0x0 : type name;`
 *   • Spaces around `=` in type aliases
 *   • Space before and after `->`
 *   • Array syntax: `T name[N]`
 *   • Comments preserved (preceding the decl they document)
 *   • Size/offset literals as hex
 *   • Empty structs/enums/bits/scopes collapsed to `{}`
 *   • `.n` preserved as `.n` (not BIT(n))
 *   • Bit fields: mask constants first (grouped), blank line, then bit entries (grouped)
 */

import {
    Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, StructDecl, ScopeDecl,
    TypeAlias, ITypeDecl, IncludeDecl, RawBlock, AnonStructDecl,
    TypeRef, EnumEntry, BitEntry, BitConstant,
} from "./ast";

export interface FormatOptions {
    indentString: string;
    alignOffsets: boolean;
}

export const DEFAULT_FORMAT_OPTIONS: FormatOptions = {
    indentString: "    ",
    alignOffsets: true,
};

/** Format a full program (list of top-level decls) to .bsym source text.
 *  Blank line rules:
 *    - include + its itypes: no blank between them; blank line before a new include
 *    - type-aliases: blank between each
 *    - functions: blank when first letter changes
 *    - variables: blank when first letter changes
 *    - type decls (structs/enums/bits/unions): blank between each
 *    - scopes: blank between each
 *    - raw-blocks: blank between each
 *    - different categories: always blank
 */
export function formatProgram(items: Decl[], options: FormatOptions = DEFAULT_FORMAT_OPTIONS): string {
    const lines: string[] = [];
    let prevCategory = -1;
    let prevLetter = "";
    let prevWasInclude = false;

    for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const cat = categoryOf(item);

        // Determine if we need a blank line before this item.
        if (prevCategory >= 0) {
            if (cat !== prevCategory) {
                // Different category — always blank line.
                lines.push("");
            } else if (cat === 0) {
                // Include+itype group: blank line before a new include (but not before itypes).
                if (item.kind === "include") {
                    lines.push("");
                }
            } else if (cat === 1 || cat === 2) {
                // Functions or variables: blank line when first letter changes.
                const letter = firstLetterOf((item as any).name);
                if (letter !== prevLetter) {
                    lines.push("");
                }
            } else if (isGroupedCategory(cat)) {
                // Grouped categories (type-alias): no blank line between.
            } else {
                // Type decls (structs/enums/bits/unions/scopes/raw-blocks): always blank between.
                lines.push("");
            }
        }

        // Track first letter for function/variable grouping.
        if (cat === 1 || cat === 2) {
            prevLetter = firstLetterOf((item as any).name);
        }

        formatDecl(item, lines, 0, options);
        prevCategory = cat;
        prevWasInclude = item.kind === "include";
    }

    while (lines.length > 0 && lines[lines.length - 1] === "") lines.pop();
    return lines.join("\n") + "\n";
}

/**
 * Category for top-level blank-line purposes:
 *   0 = include / itype (grouped by include statement)
 *   1 = function (grouped by first letter)
 *   2 = variable (grouped by first letter)
 *   3 = type decl (enum/bit/struct/union) — always blank between
 *   4 = scope — always blank between
 *   5 = type-alias (grouped — no blank between)
 *   6 = raw-block — always blank between
 */
function categoryOf(decl: Decl): number {
    switch (decl.kind) {
        case "include":
        case "itype":       return 0;
        case "function":    return 1;
        case "variable":    return 2;
        case "enum":
        case "bit":
        case "struct":      return 3;
        case "scope":       return 4;
        case "type-alias":  return 5;
        case "raw-block":   return 6;
        default:            return 99;
    }
}

/** Returns true if items in this category should be grouped (no blank line between). */
function isGroupedCategory(cat: number): boolean {
    return cat === 0 || cat === 5;  // include/itype and type-alias
}

function firstLetterOf(name: string): string {
    if (!name) return "";
    return name[0].toUpperCase();
}

function formatDecl(decl: Decl, lines: string[], indentLevel: number, options: FormatOptions) {
    const indent = options.indentString.repeat(indentLevel);

    // Emit preceding comment (docstring-style comment above the decl).
    // RawBlock doesn't have a comment field.
    if (decl.kind !== "raw-block" && decl.comment) {
        for (const c of decl.comment.split("\n")) {
            lines.push(indent + "// " + c);
        }
    }

    switch (decl.kind) {
        case "include":     formatInclude(decl, lines, indent); break;
        case "type-alias":  formatTypeAlias(decl, lines, indent); break;
        case "itype":       formatItype(decl, lines, indent); break;
        case "enum":        formatEnum(decl, lines, indentLevel, options); break;
        case "bit":         formatBit(decl, lines, indentLevel, options); break;
        case "struct":      formatStruct(decl, lines, indentLevel, options); break;
        case "scope":       formatScope(decl, lines, indentLevel, options); break;
        case "function":    formatFunction(decl, lines, indent); break;
        case "variable":    formatVariable(decl, lines, indent); break;
        case "raw-block":   formatRawBlock(decl, lines, indent); break;
        // Fields are handled inline by formatScope/formatStruct, not here.
    }
}

// ------------------- Individual decl formatters -------------------

function formatInclude(decl: IncludeDecl, lines: string[], indent: string) {
    lines.push(`${indent}include ${decl.filename};`);
}

function formatTypeAlias(decl: TypeAlias, lines: string[], indent: string) {
    lines.push(`${indent}type ${decl.name} = ${formatType(decl.target)};`);
}

function formatItype(decl: ITypeDecl, lines: string[], indent: string) {
    lines.push(`${indent}itype ${decl.name} = ${decl.actual};`);
}

function formatEnum(decl: EnumDecl, lines: string[], indentLevel: number, options: FormatOptions) {
    const indent = options.indentString.repeat(indentLevel);
    const innerIndent = options.indentString.repeat(indentLevel + 1);
    const underlying = decl.underlying ? ` ${formatType(decl.underlying)}` : "";
    if (decl.entries.length === 0) {
        lines.push(`${indent}enum ${decl.name}${underlying} {}`);
        return;
    }
    lines.push(`${indent}enum ${decl.name}${underlying} {`);
    for (const e of decl.entries) {
        lines.push(`${innerIndent}${e.name}: ${formatEnumValue(e)};`);
    }
    lines.push(`${indent}}`);
}

function formatBit(decl: BitDecl, lines: string[], indentLevel: number, options: FormatOptions) {
    const indent = options.indentString.repeat(indentLevel);
    const innerIndent = options.indentString.repeat(indentLevel + 1);
    const underlying = formatType(decl.underlying);
    if (decl.entries.length === 0 && decl.constants.length === 0) {
        lines.push(`${indent}bit ${decl.name} ${underlying} {}`);
        return;
    }
    lines.push(`${indent}bit ${decl.name} ${underlying} {`);

    // Compute max width of bit-range strings for alignment.
    const rangeStrings = decl.entries.map(e => formatBitRange(e.range));
    let maxRangeWidth = 0;
    for (const s of rangeStrings) {
        if (s.length > maxRangeWidth) maxRangeWidth = s.length;
    }

    // Mask constants first (if any), then bit entries, with blank line between.
    // Mask constants use compact colon (Name: value;), bit entries use spaced colon (range : Name;).
    if (decl.constants.length > 0) {
        for (const c of decl.constants) {
            lines.push(`${innerIndent}${c.name}: ${formatBitConstant(c)};`);
        }
        if (decl.entries.length > 0) {
            lines.push("");
        }
    }

    for (let i = 0; i < decl.entries.length; i++) {
        const e = decl.entries[i];
        const rangeStr = rangeStrings[i].padEnd(maxRangeWidth);
        const fieldType = e.fieldType ? formatType(e.fieldType) : "";
        const sep = fieldType ? `${fieldType} ` : "";
        lines.push(`${innerIndent}${rangeStr} : ${sep}${e.name};`);
    }
    lines.push(`${indent}}`);
}

function formatStruct(decl: StructDecl, lines: string[], indentLevel: number, options: FormatOptions) {
    const indent = options.indentString.repeat(indentLevel);
    const innerIndent = options.indentString.repeat(indentLevel + 1);
    const kw = decl.isUnion ? "union" : "struct";
    const size = decl.sizeRaw !== null ? `[${decl.sizeRaw}]` : (decl.size !== null ? `[${formatInt(decl.size)}]` : "");

    if (decl.isUnion) {
        // Union members have no offsets.
        if (decl.fields.length === 0) {
            lines.push(`${indent}${kw} ${decl.name}${size} {}`);
            return;
        }
        lines.push(`${indent}${kw} ${decl.name}${size} {`);
        for (const f of decl.fields) {
            if (f.comment) {
                for (const c of f.comment.split("\n")) {
                    lines.push(`${innerIndent}// ${c}`);
                }
            }
            const tstr = formatType(f.type);
            const arrStr = formatArrayDims(f.arraySizes, f.arraySizesRaw);
            lines.push(`${innerIndent}${tstr}${arrStr} ${f.name};`);
        }
        lines.push(`${indent}}`);
        return;
    }

    // Struct with offsets — use items (includes anon-structs) if available.
    const items = decl.items || decl.fields;
    if (items.length === 0) {
        lines.push(`${indent}${kw} ${decl.name}${size} {}`);
        return;
    }
    lines.push(`${indent}${kw} ${decl.name}${size} {`);
    // Compute max offset width for alignment (only for fields, not anon blocks).
    let maxOffsetWidth = 0;
    for (const item of items) {
        if (item.kind === "field") {
            const offsetStr = item.offsetRaw || formatInt(item.offset);
            if (offsetStr.length > maxOffsetWidth) maxOffsetWidth = offsetStr.length;
        } else if (item.kind === "anon-struct") {
            const offsetStr = item.offsetRaw || formatInt(item.offset);
            if (offsetStr.length > maxOffsetWidth) maxOffsetWidth = offsetStr.length;
        }
    }
    for (const item of items) {
        if (item.kind === "field") {
            const f = item;
            if (f.comment) {
                for (const c of f.comment.split("\n")) {
                    lines.push(`${innerIndent}// ${c}`);
                }
            }
            const offsetStr = options.alignOffsets
                ? (f.offsetRaw || formatInt(f.offset)).padEnd(maxOffsetWidth)
                : (f.offsetRaw || formatInt(f.offset));
            const tstr = formatType(f.type);
            const arrStr = formatArrayDims(f.arraySizes, f.arraySizesRaw);
            lines.push(`${innerIndent}${offsetStr} : ${tstr}${arrStr} ${f.name};`);
        } else if (item.kind === "anon-struct") {
            const anon = item;
            if (anon.comment) {
                for (const c of anon.comment.split("\n")) {
                    lines.push(`${innerIndent}// ${c}`);
                }
            }
            const offsetStr = options.alignOffsets
                ? (anon.offsetRaw || formatInt(anon.offset)).padEnd(maxOffsetWidth)
                : (anon.offsetRaw || formatInt(anon.offset));
            lines.push(`${innerIndent}${offsetStr} : {`);
            const anonIndent = options.indentString.repeat(indentLevel + 2);
            for (const af of anon.fields) {
                if (af.comment) {
                    for (const c of af.comment.split("\n")) {
                        lines.push(`${anonIndent}// ${c}`);
                    }
                }
                const tstr = formatType(af.type);
                const arrStr = formatArrayDims(af.arraySizes, af.arraySizesRaw);
                lines.push(`${anonIndent}${tstr}${arrStr} ${af.name};`);
            }
            lines.push(`${innerIndent}};`);
        }
    }
    lines.push(`${indent}}`);
}

function formatScope(decl: ScopeDecl, lines: string[], indentLevel: number, options: FormatOptions) {
    const indent = options.indentString.repeat(indentLevel);
    const size = decl.sizeRaw !== null ? `[${decl.sizeRaw}]` : (decl.size !== null ? `[${formatInt(decl.size)}]` : "");

    if (decl.items.length === 0) {
        lines.push(`${indent}${decl.name}${size} {}`);
        return;
    }
    lines.push(`${indent}${decl.name}${size} {`);

    // Group items by kind, in the user-specified order:
    // fields/anon-structs → types (enums/bits/unions/structs) → functions → variables → nested scopes → misc
    const groups: Decl[][] = [
        decl.items.filter(it => it.kind === "field" || it.kind === "anon-struct"),
        decl.items.filter(it => it.kind === "enum"),
        decl.items.filter(it => it.kind === "bit"),
        decl.items.filter(it => it.kind === "struct" && it.isUnion),
        decl.items.filter(it => it.kind === "struct" && !it.isUnion),
        decl.items.filter(it => it.kind === "function"),
        decl.items.filter(it => it.kind === "variable"),
        decl.items.filter(it => it.kind === "scope"),
        decl.items.filter(it => it.kind === "include" || it.kind === "itype" || it.kind === "type-alias" || it.kind === "raw-block"),
    ];

    // Compute max offset width among fields and anon-structs for alignment.
    let maxOffsetWidth = 0;
    for (const it of decl.items) {
        if (it.kind === "field" || it.kind === "anon-struct") {
            const offsetStr = it.offsetRaw || formatInt(it.offset);
            if (offsetStr.length > maxOffsetWidth) maxOffsetWidth = offsetStr.length;
        }
    }

    let firstGroup = true;
    for (const group of groups) {
        if (group.length === 0) continue;
        // Blank line between groups (but not before the first group).
        if (!firstGroup) {
            lines.push("");
        }
        firstGroup = false;
        // Within type-decl groups (enums/bits/unions/structs/scopes), add blank lines between items.
        const isTypeGroup = group[0].kind === "enum" || group[0].kind === "bit" ||
                            group[0].kind === "struct" || group[0].kind === "scope";
        for (let i = 0; i < group.length; i++) {
            if (isTypeGroup && i > 0) {
                lines.push("");
            }
            const item = group[i];
            if (item.kind === "field") {
                formatFieldAligned(item, lines, indentLevel + 1, options, maxOffsetWidth);
            } else if (item.kind === "anon-struct") {
                formatAnonStruct(item, lines, indentLevel + 1, options, maxOffsetWidth);
            } else {
                formatDecl(item, lines, indentLevel + 1, options);
            }
        }
    }
    lines.push(`${indent}}`);
}

/** Format a scope-level field with aligned offset. */
function formatFieldAligned(decl: FieldDecl, lines: string[], indentLevel: number, options: FormatOptions, maxOffsetWidth: number) {
    const indent = options.indentString.repeat(indentLevel);
    if (decl.comment) {
        for (const c of decl.comment.split("\n")) {
            lines.push(`${indent}// ${c}`);
        }
    }
    const offsetStr = options.alignOffsets
        ? (decl.offsetRaw || formatInt(decl.offset)).padEnd(maxOffsetWidth)
        : (decl.offsetRaw || formatInt(decl.offset));
    const tstr = formatType(decl.type);
    const arrStr = formatArrayDims(decl.arraySizes, decl.arraySizesRaw);
    lines.push(`${indent}${offsetStr} : ${tstr}${arrStr} ${decl.name};`);
}

/** Format an anonymous union/struct block: `offset : { members };` */
function formatAnonStruct(decl: AnonStructDecl, lines: string[], indentLevel: number, options: FormatOptions, maxOffsetWidth: number) {
    const indent = options.indentString.repeat(indentLevel);
    const innerIndent = options.indentString.repeat(indentLevel + 1);
    if (decl.comment) {
        for (const c of decl.comment.split("\n")) {
            lines.push(`${indent}// ${c}`);
        }
    }
    const offsetStr = options.alignOffsets
        ? (decl.offsetRaw || formatInt(decl.offset)).padEnd(maxOffsetWidth)
        : (decl.offsetRaw || formatInt(decl.offset));
    lines.push(`${indent}${offsetStr} : {`);
    for (const f of decl.fields) {
        if (f.comment) {
            for (const c of f.comment.split("\n")) {
                lines.push(`${innerIndent}// ${c}`);
            }
        }
        const tstr = formatType(f.type);
        const arrStr = formatArrayDims(f.arraySizes, f.arraySizesRaw);
        lines.push(`${innerIndent}${tstr}${arrStr} ${f.name};`);
    }
    lines.push(`${indent}};`);
}

function formatFunction(decl: FuncDecl, lines: string[], indent: string) {
    const ret = formatType(decl.returnType);
    const params: string[] = [];
    if (decl.hasThis) {
        params.push(decl.isConstThis ? "const this" : "this");
    }
    for (const p of decl.params) {
        const ts = formatType(p.type);
        params.push(p.name ? `${ts} ${p.name}` : ts);
    }
    if (decl.isVariadic) params.push("...");
    const paramsStr = params.join(", ");
    lines.push(`${indent}${ret} ${decl.name}(${paramsStr}); -> ${decl.symbol}`);
}

function formatVariable(decl: VarDecl, lines: string[], indent: string) {
    const tstr = formatType(decl.type);
    const arrStr = formatArrayDims(decl.arraySizes, decl.arraySizesRaw);
    lines.push(`${indent}${tstr}${arrStr} ${decl.name}; -> ${decl.symbol}`);
}

function formatRawBlock(decl: RawBlock, lines: string[], indent: string) {
    lines.push(`${indent}:start ${decl.filename}`);
    for (const line of decl.content.split("\n")) {
        lines.push(line);
    }
    lines.push(`${indent}:end ${decl.filename}`);
}

// ------------------- Type formatting -------------------

function formatType(t: TypeRef): string {
    let s = "";
    if (t.isConst) s += "const ";
    s += t.base;
    s += "*".repeat(t.pointerCount);
    if (t.isReference) s += "&";
    return s;
}

// ------------------- Value formatting -------------------

/** Format an integer as hex (the .bsym convention for offsets and sizes). */
function formatInt(value: number): string {
    if (value === 0) return "0x0";
    return `0x${value.toString(16)}`;
}

/** Format array dimensions as a suffix string (e.g. "[0xbb8]" or "[3][1000]").
 *  Uses raw text when available, falls back to formatInt.
 *  Returns "" if there are no dimensions. */
function formatArrayDims(sizes: number[], sizesRaw: string[]): string {
    if (sizes.length === 0) return "";
    let s = "";
    for (let i = 0; i < sizes.length; i++) {
        const dim = sizesRaw[i] || formatInt(sizes[i]);
        s += `[${dim}]`;
    }
    return s;
}

/** Format a bit range: `0` for single bit, `4-13` for range. */
function formatBitRange(range: { lo: number; hi: number }): string {
    if (range.lo === range.hi) return String(range.lo);
    return `${range.lo}-${range.hi}`;
}

/** Format an enum value, preserving the original .bsym source representation.
 *  .n stays as .n (not BIT(n) — that's the codegen form). */
function formatEnumValue(e: EnumEntry): string {
    if (e.isBitShorthand) return `.${e.bitN}`;
    if (e.isNull) return "NULL";
    if (e.isFloat) return e.rawText;
    if (e.rawText) return e.rawText;
    return formatInt(e.value);
}

/** Format a bit constant, preserving the original .bsym source representation. */
function formatBitConstant(c: BitConstant): string {
    if (c.isBitShorthand) return `.${c.bitN}`;
    if (c.isNull) return "NULL";
    if (c.isFloat) return c.rawText;
    if (c.rawText) return c.rawText;
    return formatInt(c.value);
}
