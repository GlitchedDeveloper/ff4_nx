/**
 * Reorganizer — restructures a parsed .bsym AST:
 *
 * Output order:
 *   1. imports (includes) — each include + its following itypes form a group
 *   2. types (type-aliases) — grouped
 *   3. Top-level Group A (sorted alphabetically within each kind, grouped by first letter):
 *      a. functions
 *      b. variables
 *      c. enums
 *      d. bitfields
 *      e. unions
 *      f. structs
 *   4. Scopes — sorted alphabetically, each with internal order:
 *      fields → types (enums/bits/unions/structs) → functions → variables → nested scopes
 *   5. Raw blocks (babil.h, babil.cpp) at the end
 *
 * Duplicate scopes (same name) are merged:
 *   - If both have fields and the fields differ → abort with error.
 *   - If one has fields and the other is functions-only → functions merged in.
 *   - Duplicate function/variable names within the merge are deduplicated.
 */

import {
    Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, StructDecl, ScopeDecl,
    TypeAlias, ITypeDecl, IncludeDecl, RawBlock, AnonStructDecl,
} from "./ast";

export interface ReorganizeResult {
    ok: boolean;
    items?: Decl[];
    error?: string;
}

/** Reorganize a program's top-level items. */
export function reorganize(items: Decl[]): ReorganizeResult {
    // Separate items by category.
    // Include+itype groups: an include + the itypes that follow it (until the next include)
    // form a group. We preserve this grouping.
    const includeGroups: Decl[][] = [];  // each sub-array is [include, itype, itype, ...]
    let currentGroup: Decl[] | null = null;
    const typeAliases: TypeAlias[] = [];
    const functions: FuncDecl[] = [];
    const variables: VarDecl[] = [];
    const enums: EnumDecl[] = [];
    const bits: BitDecl[] = [];
    const unions: StructDecl[] = [];
    const structs: StructDecl[] = [];
    const rawBlocks: RawBlock[] = [];
    const scopeMap = new Map<string, ScopeDecl[]>();

    for (const it of items) {
        switch (it.kind) {
            case "include":
                // Start a new include+itype group.
                currentGroup = [it];
                includeGroups.push(currentGroup);
                break;
            case "itype":
                // Add to the current include group, or start a standalone group if none.
                if (currentGroup) {
                    currentGroup.push(it);
                } else {
                    currentGroup = [it];
                    includeGroups.push(currentGroup);
                }
                break;
            case "type-alias": typeAliases.push(it); break;
            case "function":   functions.push(it); break;
            case "variable":   variables.push(it); break;
            case "enum":       enums.push(it); break;
            case "bit":        bits.push(it); break;
            case "struct":
                if (it.isUnion) unions.push(it);
                else structs.push(it);
                break;
            case "raw-block":  rawBlocks.push(it); break;
            case "scope": {
                const list = scopeMap.get(it.name) ?? [];
                list.push(it);
                scopeMap.set(it.name, list);
                break;
            }
        }
    }

    // Merge duplicate scopes.
    const mergedScopes: ScopeDecl[] = [];
    for (const [name, scopes] of scopeMap) {
        if (scopes.length === 1) {
            mergedScopes.push(scopes[0]);
        } else {
            let merged = scopes[0];
            for (let i = 1; i < scopes.length; i++) {
                const result = mergeScopes(merged, scopes[i]);
                if (!result.ok) {
                    return { ok: false, error: `Cannot merge duplicate scope '${name}': ${result.error}` };
                }
                merged = result.merged!;
            }
            mergedScopes.push(merged);
        }
    }

    // Recursively reorganize each scope's items.
    for (const scope of mergedScopes) {
        const result = reorganizeScopeItems(scope);
        if (!result.ok) {
            return { ok: false, error: result.error };
        }
    }

    // Sort scopes alphabetically by name.
    mergedScopes.sort((a, b) => a.name.localeCompare(b.name));

    // Sort functions and variables alphabetically by name.
    functions.sort((a, b) => a.name.localeCompare(b.name));
    variables.sort((a, b) => a.name.localeCompare(b.name));

    // Build the final ordered list.
    const result: Decl[] = [];
    for (const group of includeGroups) {
        for (const it of group) result.push(it);
    }
    for (const it of typeAliases) result.push(it);
    for (const it of functions) result.push(it);
    for (const it of variables) result.push(it);
    for (const it of enums) result.push(it);
    for (const it of bits) result.push(it);
    for (const it of unions) result.push(it);
    for (const it of structs) result.push(it);
    for (const it of mergedScopes) result.push(it);
    for (const it of rawBlocks) result.push(it);

    return { ok: true, items: result };
}

/** Merge two scopes with the same name. */
function mergeScopes(a: ScopeDecl, b: ScopeDecl): { ok: boolean; merged?: ScopeDecl; error?: string } {
    const aFields = a.items.filter(it => it.kind === "field") as FieldDecl[];
    const bFields = b.items.filter(it => it.kind === "field") as FieldDecl[];

    // If both have fields, they must be identical.
    if (aFields.length > 0 && bFields.length > 0) {
        if (aFields.length !== bFields.length) {
            return { ok: false, error: `different field counts (${aFields.length} vs ${bFields.length})` };
        }
        for (let i = 0; i < aFields.length; i++) {
            const af = aFields[i];
            const bf = bFields[i];
            if (af.offset !== bf.offset) {
                return { ok: false, error: `field offset mismatch at index ${i} (0x${af.offset.toString(16)} vs 0x${bf.offset.toString(16)})` };
            }
            if (af.name !== bf.name) {
                return { ok: false, error: `field name mismatch at index ${i} ('${af.name}' vs '${bf.name}')` };
            }
        }
    }

    // Check size compatibility.
    if (a.size !== null && b.size !== null && a.size !== b.size) {
        return { ok: false, error: `size mismatch (0x${a.size.toString(16)} vs 0x${b.size.toString(16)})` };
    }

    // Merge: fields from whichever has them, plus all non-field items from both.
    const mergedItems: Decl[] = [];

    // Fields from whichever has them (prefer a's if both have identical fields).
    const fieldSource = aFields.length > 0 ? aFields : bFields;
    for (const f of fieldSource) {
        mergedItems.push(f);
    }

    // Non-field items from both (functions, variables, nested types, nested scopes).
    // Track seen function/variable names to avoid duplicates.
    const seenFuncVar = new Set<string>();
    for (const it of a.items) {
        if (it.kind !== "field") {
            const name = (it as any).name;
            if (name && (it.kind === "function" || it.kind === "variable")) {
                if (seenFuncVar.has(name)) continue;
                seenFuncVar.add(name);
            }
            mergedItems.push(it);
        }
    }
    for (const it of b.items) {
        if (it.kind !== "field") {
            const name = (it as any).name;
            if (name && (it.kind === "function" || it.kind === "variable")) {
                if (seenFuncVar.has(name)) continue;
                seenFuncVar.add(name);
            }
            mergedItems.push(it);
        }
    }

    const merged: ScopeDecl = {
        kind: "scope",
        name: a.name,
        size: a.size ?? b.size,
        sizeRaw: a.sizeRaw ?? b.sizeRaw,
        items: mergedItems,
        comment: a.comment ?? b.comment,
    };

    return { ok: true, merged };
}

/** Recursively reorganize a scope's items.
 *  Internal order: fields → types (enums/bits/unions/structs) → functions → variables → nested scopes.
 *  Functions and variables sorted alphabetically. Nested scopes merged + sorted. */
function reorganizeScopeItems(scope: ScopeDecl): { ok: boolean; error?: string } {
    const fields: Decl[] = [];
    const enums: EnumDecl[] = [];
    const bits: BitDecl[] = [];
    const unions: StructDecl[] = [];
    const structs: StructDecl[] = [];
    const functions: FuncDecl[] = [];
    const variables: VarDecl[] = [];
    const rawBlocks: RawBlock[] = [];
    const scopeMap = new Map<string, ScopeDecl[]>();
    const includes: IncludeDecl[] = [];
    const itypes: ITypeDecl[] = [];
    const typeAliases: TypeAlias[] = [];

    for (const it of scope.items) {
        switch (it.kind) {
            case "field":
            case "anon-struct": fields.push(it); break;
            case "enum":       enums.push(it); break;
            case "bit":        bits.push(it); break;
            case "struct":
                if (it.isUnion) unions.push(it);
                else structs.push(it);
                break;
            case "function":   functions.push(it); break;
            case "variable":   variables.push(it); break;
            case "raw-block":  rawBlocks.push(it); break;
            case "include":    includes.push(it); break;
            case "itype":      itypes.push(it); break;
            case "type-alias": typeAliases.push(it); break;
            case "scope": {
                const list = scopeMap.get(it.name) ?? [];
                list.push(it);
                scopeMap.set(it.name, list);
                break;
            }
        }
    }

    // Merge nested duplicate scopes.
    const mergedScopes: ScopeDecl[] = [];
    for (const [name, scopes] of scopeMap) {
        if (scopes.length === 1) {
            mergedScopes.push(scopes[0]);
        } else {
            let merged = scopes[0];
            for (let i = 1; i < scopes.length; i++) {
                const result = mergeScopes(merged, scopes[i]);
                if (!result.ok) {
                    return { ok: false, error: `Cannot merge duplicate scope '${name}': ${result.error}` };
                }
                merged = result.merged!;
            }
            mergedScopes.push(merged);
        }
    }

    // Recursively reorganize nested scopes.
    for (const nested of mergedScopes) {
        const result = reorganizeScopeItems(nested);
        if (!result.ok) {
            return { ok: false, error: result.error };
        }
    }

    // Sort functions and variables alphabetically.
    functions.sort((a, b) => a.name.localeCompare(b.name));
    variables.sort((a, b) => a.name.localeCompare(b.name));

    // Sort nested scopes alphabetically.
    mergedScopes.sort((a, b) => a.name.localeCompare(b.name));

    // Build the reordered items list:
    // fields → enums → bits → unions → structs → functions → variables → nested scopes → misc
    const reordered: Decl[] = [];
    for (const it of fields) reordered.push(it);
    for (const it of enums) reordered.push(it);
    for (const it of bits) reordered.push(it);
    for (const it of unions) reordered.push(it);
    for (const it of structs) reordered.push(it);
    for (const it of functions) reordered.push(it);
    for (const it of variables) reordered.push(it);
    for (const it of mergedScopes) reordered.push(it);
    for (const it of includes) reordered.push(it);
    for (const it of itypes) reordered.push(it);
    for (const it of typeAliases) reordered.push(it);
    for (const it of rawBlocks) reordered.push(it);

    scope.items = reordered;
    return { ok: true };
}
