/**
 * Minimal Itanium C++ ABI demangler.
 *
 * Decodes GCC/Clang-style mangled symbols (e.g. `_ZN3sys13GameParameter9setSaveNoEh`)
 * into human-readable C++ signatures. Covers the subset of the Itanium ABI that
 * appears in .bsym files — nested names, length-prefixed identifiers, the common
 * builtin types, pointer/reference/const qualifiers, and variadic `z`.
 *
 * For a full reference see:
 *   https://itanium-cxx-abi.github.io/cxx-abi/abi.html#mangling
 *
 * This implementation is intentionally forgiving: on any parse error it returns
 * the original mangled string unchanged, so the hover still shows *something*.
 */

/** Result of a demangling attempt. */
export interface DemangleResult {
    /** Whether the input was recognized as a mangled symbol. */
    mangled: boolean;
    /** Best-effort demangled text (e.g. "sys::GameParameter::setSaveNo(unsigned char)"). */
    text: string;
    /** Qualified name part (e.g. "sys::GameParameter::setSaveNo"), or "" if not applicable. */
    qualifiedName: string;
    /** Parameter type list (e.g. ["unsigned char"]), or [] if not a function. */
    paramTypes: string[];
    /** True if the symbol encodes a const member function (the K after N). */
    isConstMethod: boolean;
}

/** Map of single-char builtin type encodings to their C++ names. */
const BUILTIN_TYPES: Record<string, string> = {
    "v": "void",
    "w": "wchar_t",
    "b": "bool",
    "c": "char",
    "a": "signed char",
    "h": "unsigned char",
    "s": "short",
    "t": "unsigned short",
    "i": "int",
    "j": "unsigned int",
    "l": "long",
    "m": "unsigned long",
    "x": "long long",
    "y": "unsigned long long",
    "n": "__int128",
    "o": "unsigned __int128",
    "f": "float",
    "d": "double",
    "e": "long double",
    "g": "__float128",
    "z": "...",  // ellipsis (variadic)
};

/** Vendor-extended types (uN...) — best-effort, return the source name. */
function isVendorExtended(s: string, pos: number): boolean {
    return s[pos] === "u";
}

class Demangler {
    private s: string;
    private pos = 0;
    private subs: string[] = [];

    constructor(mangled: string) {
        this.s = mangled;
    }

    private peek(): string {
        return this.s[this.pos] ?? "";
    }

    private take(): string {
        return this.s[this.pos++] ?? "";
    }

    private atEnd(): boolean {
        return this.pos >= this.s.length;
    }

    /** Read a length-prefixed identifier: <length><name>. Returns null on failure. */
    private readSourceName(): string | null {
        const start = this.pos;
        let digits = "";
        while (this.pos < this.s.length && /[0-9]/.test(this.s[this.pos])) {
            digits += this.s[this.pos++];
        }
        if (digits.length === 0) return null;
        const len = parseInt(digits, 10);
        if (isNaN(len) || len <= 0 || this.pos + len > this.s.length) {
            this.pos = start;
            return null;
        }
        const name = this.s.slice(this.pos, this.pos + len);
        this.pos += len;
        return name;
    }

    /** Parse a nested name: N [<CV>] <prefix> E. */
    private parseNestedName(): { parts: string[]; isConst: boolean } | null {
        const start = this.pos;
        if (this.take() !== "N") {
            this.pos = start;
            return null;
        }
        let isConst = false;
        // Optional CV-qualifiers: r (restrict), V (volatile), K (const)
        while (this.peek() === "r" || this.peek() === "V" || this.peek() === "K") {
            const c = this.take();
            if (c === "K") isConst = true;
        }
        const parts: string[] = [];

        // The <prefix> may begin with a <substitution> (S_ or S<n>_). This is common
        // for sibling types inside a namespace (e.g. NS_6WidgetE inside N2ui10CWidgetMng...E
        // resolves S_ to "ui" and produces "ui::Widget").
        if (this.peek() === "S") {
            const sub = this.parseSubstitution();
            if (sub === null) {
                this.pos = start;
                return null;
            }
            // Split the substituted prefix on :: to seed the parts list.
            for (const p of sub.split("::")) parts.push(p);
            // Note: the substitution result was already pushed when it was first parsed;
            // we don't push again here. But the *extended* prefix we build below does
            // add new substitutions.
        }

        while (this.peek() !== "E" && !this.atEnd()) {
            const before = this.pos;
            const name = this.readSourceName();
            if (name === null) {
                this.pos = start;
                return null;
            }
            parts.push(name);
            this.subs.push(parts.join("::"));
            if (this.pos === before) break;
        }
        if (this.take() !== "E") {
            this.pos = start;
            return null;
        }
        return { parts, isConst };
    }

    /** Parse a single type. Returns the C++ type string, or null on failure. */
    private parseType(): string | null {
        if (this.atEnd()) return null;
        const c = this.peek();

        // Pointer: P<type>
        if (c === "P") {
            this.take();
            const inner = this.parseType();
            if (inner === null) return null;
            // Avoid double space when inner already ends with *
            const result = inner.endsWith("*") ? inner + "*" : inner + "*";
            this.subs.push(result);
            return result;
        }

        // Reference: R<type>
        if (c === "R") {
            this.take();
            const inner = this.parseType();
            if (inner === null) return null;
            const result = inner + "&";
            this.subs.push(result);
            return result;
        }

        // Rvalue reference: O<type>
        if (c === "O") {
            this.take();
            const inner = this.parseType();
            if (inner === null) return null;
            const result = inner + "&&";
            this.subs.push(result);
            return result;
        }

        // Const: K<type>
        if (c === "K") {
            this.take();
            const inner = this.parseType();
            if (inner === null) return null;
            const result = "const " + inner;
            this.subs.push(result);
            return result;
        }

        // Volatile: V<type>
        if (c === "V") {
            this.take();
            const inner = this.parseType();
            if (inner === null) return null;
            const result = "volatile " + inner;
            this.subs.push(result);
            return result;
        }

        // Builtin types — per Itanium ABI, builtin types do NOT add a substitution.
        if (BUILTIN_TYPES[c] !== undefined) {
            this.take();
            return BUILTIN_TYPES[c];
        }

        // Nested name as a type
        if (c === "N") {
            const nested = this.parseNestedName();
            if (nested === null) return null;
            const result = nested.parts.join("::");
            this.subs.push(result);
            return result;
        }

        // Substitution: S_ (first), S0_ (second), S1_ (third), ...
        if (c === "S") {
            return this.parseSubstitution();
        }

        // Vendor-extended type: u<source-name>
        if (isVendorExtended(this.s, this.pos)) {
            this.take(); // 'u'
            const name = this.readSourceName();
            if (name === null) return null;
            this.subs.push(name);
            return name;
        }

        // Source name (unqualified type / class name)
        if (/[0-9]/.test(c)) {
            const name = this.readSourceName();
            if (name === null) return null;
            this.subs.push(name);
            return name;
        }

        return null;
    }

    /** Parse a substitution reference: S_, S0_, S1_, ..., S_, St, etc. */
    private parseSubstitution(): string | null {
        const start = this.pos;
        if (this.take() !== "S") {
            this.pos = start;
            return null;
        }
        // St → std::namespace
        if (this.peek() === "t") {
            this.take();
            return "std";
        }
        // S_ → first substitution; S<n>_ → (n+2)th
        let digits = "";
        while (this.peek() !== "_" && !this.atEnd()) {
            if (/[0-9A-Z]/.test(this.peek())) {
                digits += this.take();
            } else {
                this.pos = start;
                return null;
            }
        }
        if (this.take() !== "_") {
            this.pos = start;
            return null;
        }
        let idx: number;
        if (digits.length === 0) {
            idx = 0;
        } else {
            // base-36
            idx = parseInt(digits, 36) + 1;
        }
        if (idx < 0 || idx >= this.subs.length) {
            this.pos = start;
            return null;
        }
        return this.subs[idx];
    }

    /** Top-level demangle. */
    demangle(): DemangleResult {
        const original = this.s;
        // Must start with _Z (or _ZN / _ZK etc.)
        if (!this.s.startsWith("_Z")) {
            return {
                mangled: false,
                text: original,
                qualifiedName: original,
                paramTypes: [],
                isConstMethod: false,
            };
        }
        this.pos = 2;

        // Optional nesting: N [<cv>] <parts> E
        let qualifiedName = "";
        let isConstMethod = false;
        const beforeNamePos = this.pos;

        if (this.peek() === "N") {
            const nested = this.parseNestedName();
            if (nested === null) {
                return fallback(original);
            }
            qualifiedName = nested.parts.join("::");
            isConstMethod = nested.isConst;
        } else {
            // Unqualified name: a single <source-name>.
            // Per Itanium ABI, the function name itself is NOT a substitution candidate
            // (only <type>, <prefix>, and <template-prefix> non-terminals add substitutions).
            const name = this.readSourceName();
            if (name === null) {
                this.pos = beforeNamePos;
                return fallback(original);
            }
            qualifiedName = name;
        }

        // Bare name (no parameter encoding). Common for variables.
        if (this.atEnd()) {
            return {
                mangled: true,
                text: qualifiedName,
                qualifiedName,
                paramTypes: [],
                isConstMethod: false,
            };
        }

        // Parameters: a sequence of types until end-of-string.
        const params: string[] = [];
        while (!this.atEnd()) {
            const t = this.parseType();
            if (t === null) {
                return fallback(original);
            }
            // Skip void (means "no parameters" in C++ mangling)
            if (t === "void" && params.length === 0 && this.atEnd()) {
                break;
            }
            params.push(t);
        }

        const paramsStr = params.join(", ");
        const constMark = isConstMethod ? " const" : "";
        const text = `${qualifiedName}(${paramsStr})${constMark}`;

        return {
            mangled: true,
            text,
            qualifiedName,
            paramTypes: params,
            isConstMethod,
        };
    }
}

function fallback(original: string): DemangleResult {
    return {
        mangled: false,
        text: original,
        qualifiedName: original,
        paramTypes: [],
        isConstMethod: false,
    };
}

/**
 * Demangle a symbol string. Returns a DemangleResult; never throws.
 *
 * Examples:
 *   _ZN3sys13GameParameter9setSaveNoEh  →  sys::GameParameter::setSaveNo(unsigned char)
 *   _ZNK3sys13GameParameter13fieldSymbolIDEv → sys::GameParameter::fieldSymbolID() const
 *   _Z9OS_PrintfPKcz                    →  OS_Printf(const char*, ...)
 *   _Z6FX_Divii                          →  FX_Div(int, int)
 *   fontScale                            →  fontScale (not mangled)
 */
export function demangle(symbol: string): DemangleResult {
    if (!symbol) {
        return { mangled: false, text: "", qualifiedName: "", paramTypes: [], isConstMethod: false };
    }
    try {
        return new Demangler(symbol).demangle();
    } catch {
        return fallback(symbol);
    }
}
