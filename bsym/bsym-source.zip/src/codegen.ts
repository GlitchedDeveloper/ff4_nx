/**
 * Codegen helpers — render .bsym AST nodes as the C++ that babilsym.py would emit.
 * Used for hover previews ("what does codegen produce for this decl?").
 *
 * This is a simplified port of the Codegen class in babilsym.py — just enough
 * to render individual declarations for hover info. Full codegen (header/source
 * file generation) is left to the reference Python implementation.
 */

import {
    Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, StructDecl, ScopeDecl,
    TypeAlias, ITypeDecl, IncludeDecl, RawBlock,
    TypeRef, ParamDecl, PRIMITIVES, PRIMITIVE_SIZES,
} from "./ast";

/**
 * Scope-name registry: collects all top-level and nested scope qualified paths
 * so we can decide whether a type reference is a scope (and thus gets `::cls`
 * appended) or a plain type.
 */
export class TypeRegistry {
    /** Set of qualified scope names (e.g. "sys::GameParameter", "sys"). */
    scopeNames = new Set<string>();
    /** Map of type-alias name → target TypeRef. */
    aliases = new Map<string, TypeRef>();
    /** Map of itype name → actual type string. */
    itypes = new Map<string, string>();
    /** Set of plain named types (struct/enum/bit/union) — these don't get ::cls. */
    namedTypes = new Set<string>();
    /** Set of qualified named-type paths (e.g. "itm::WEAPON_SYSTEM", "world::VIBRATION_STATE"). */
    namedTypePaths = new Set<string>();
    /** Set of all type-alias qualified paths (for scoped alias lookups). */
    aliasPaths = new Set<string>();
    /** Map of scope name (last part) → size in bytes. Used for size calculation. */
    scopeSizes = new Map<string, number>();
    /** Map of named type name → size in bytes. */
    namedTypeSizes = new Map<string, number>();

    constructor(items: Decl[]) {
        this.collect(items, []);
    }

    private collect(items: Decl[], path: string[]) {
        for (const it of items) {
            switch (it.kind) {
                case "scope": {
                    const qpath = [...path, it.name];
                    this.scopeNames.add(qpath.join("::"));
                    // Compute the scope's cls size: if explicit size, use it;
                    // otherwise calculate from last field's offset + size.
                    const fields = it.items.filter(sub => sub.kind === "field") as FieldDecl[];
                    let size: number;
                    if (it.size !== null) {
                        size = it.size;
                    } else if (fields.length > 0) {
                        const last = fields[fields.length - 1];
                        size = last.offset + this.estimateTypeSize(last.type, last.arraySizes);
                    } else {
                        size = 1; // empty scope = 1 byte
                    }
                    this.scopeSizes.set(it.name, size);
                    this.collect(it.items, qpath);
                    break;
                }
                case "struct":
                    this.namedTypes.add(it.name);
                    this.namedTypePaths.add([...path, it.name].join("::"));
                    {
                        let size: number;
                        if (it.size !== null) {
                            size = it.size;
                        } else if (it.isUnion && it.fields.length > 0) {
                            // Union size = max of all member sizes.
                            size = 1;
                            for (const f of it.fields) {
                                const sz = this.estimateTypeSize(f.type, f.arraySizes);
                                if (sz > size) size = sz;
                            }
                        } else if (it.fields.length > 0) {
                            const last = it.fields[it.fields.length - 1];
                            size = last.offset + this.estimateTypeSize(last.type, last.arraySizes);
                        } else {
                            size = 1; // empty struct = 1 byte
                        }
                        this.namedTypeSizes.set(it.name, size);
                    }
                    break;
                case "enum":
                    this.namedTypes.add(it.name);
                    this.namedTypePaths.add([...path, it.name].join("::"));
                    {
                        const sz = it.underlying ? (PRIMITIVE_SIZES[it.underlying.base] ?? 4) : 4;
                        this.namedTypeSizes.set(it.name, sz);
                    }
                    break;
                case "bit":
                    this.namedTypes.add(it.name);
                    this.namedTypePaths.add([...path, it.name].join("::"));
                    {
                        const sz = PRIMITIVE_SIZES[it.underlying.base] ?? 4;
                        this.namedTypeSizes.set(it.name, sz);
                    }
                    break;
                case "type-alias":
                    this.aliases.set(it.name, it.target);
                    this.aliasPaths.add([...path, it.name].join("::"));
                    break;
                case "itype":
                    if (path.length === 0) this.itypes.set(it.name, it.actual);
                    break;
            }
        }
    }

    /** Estimate the size of a type (for scope/struct size calculation during collection). */
    private estimateTypeSize(t: TypeRef, arraySizes: number[]): number {
        let base: number;
        if (t.pointerCount > 0 || t.isReference) {
            base = 8;
        } else if (PRIMITIVE_SIZES[t.base] !== undefined) {
            base = PRIMITIVE_SIZES[t.base];
        } else {
            // For scoped names (e.g. "sys2d::Sprite"), extract the last part.
            const lookupName = t.base.includes("::") ? t.base.split("::").pop()! : t.base;
            if (this.scopeSizes.has(lookupName)) {
                base = this.scopeSizes.get(lookupName)!;
            } else if (this.namedTypeSizes.has(lookupName)) {
                base = this.namedTypeSizes.get(lookupName)!;
            } else if (this.aliases.has(lookupName)) {
                return this.estimateTypeSize(this.aliases.get(lookupName)!, arraySizes);
            } else if (this.itypes.has(lookupName)) {
                const actual = this.itypes.get(lookupName)!;
                const words = actual.split(/\s+/);
                base = 0;
                for (let i = words.length - 1; i >= 0; i--) {
                    if (PRIMITIVE_SIZES[words[i]] !== undefined) {
                        base = PRIMITIVE_SIZES[words[i]];
                        break;
                    }
                }
            } else {
                base = 0;
            }
        }
        for (const dim of arraySizes) base = base * dim;
        return base;
    }

    /** True if base is a known type (primitive, scope, named type, itype, alias, or scoped named type). */
    isKnownType(base: string): boolean {
        if (base === "this") return true;
        if (PRIMITIVES.has(base)) return true;
        if (this.aliases.has(base)) return true;
        if (this.itypes.has(base)) return true;
        if (this.namedTypes.has(base)) return true;
        if (this.isScopeName(base)) return true;
        // Check scoped named types (e.g. itm::WEAPON_SYSTEM, world::VIBRATION_STATE)
        if (base.includes("::")) {
            for (const qn of this.namedTypePaths) {
                if (qn === base || qn.endsWith("::" + base)) return true;
            }
            for (const qn of this.aliasPaths) {
                if (qn === base || qn.endsWith("::" + base)) return true;
            }
            // If the first part is a known scope, the type might be defined
            // in an included header — don't warn.
            const firstPart = base.split("::")[0];
            if (this.scopeNames.has(firstPart)) return true;
        }
        return false;
    }

    /** True if base refers to a scope (so codegen appends ::cls). */
    isScopeName(base: string): boolean {
        if (base === "this") return false;
        const parts = base.split("::");
        for (const qn of this.scopeNames) {
            const qParts = qn.split("::");
            if (qParts.length >= parts.length) {
                let match = true;
                for (let i = 0; i < parts.length; i++) {
                    if (qParts[qParts.length - parts.length + i] !== parts[i]) {
                        match = false;
                        break;
                    }
                }
                if (match) return true;
            }
        }
        return false;
    }
}

/** Render a TypeRef as C++ code (matching render_type in babilsym.py). */
export function renderType(t: TypeRef, registry: TypeRegistry): string {
    let s = "";
    if (t.isConst) s += "const ";
    if (t.base === "this") {
        s += "cls";
    } else if (registry.isScopeName(t.base)) {
        s += t.base + "::cls";
    } else {
        s += t.base;
    }
    s += "*".repeat(t.pointerCount);
    if (t.isReference) s += "&";
    return s;
}

/** Render a function's C++ signature, like `extern void (*setSaveNo)(cls* self, u8 saveNo)`. */
export function renderFunctionSignature(fn: FuncDecl, registry: TypeRegistry): string {
    const ret = renderType(fn.returnType, registry);
    const params: string[] = [];
    if (fn.hasThis) {
        params.push(fn.isConstThis ? "const cls* self" : "cls* self");
    }
    for (const p of fn.params) {
        const ts = renderType(p.type, registry);
        params.push(p.name ? `${ts} ${p.name}` : ts);
    }
    if (fn.isVariadic) params.push("...");
    const paramsStr = params.length ? params.join(", ") : "void";
    return `extern ${ret} (*${fn.name})(${paramsStr});`;
}

/** Render a variable's C++ declaration (codegen adds one pointer level). */
export function renderVariableDeclaration(v: VarDecl, registry: TypeRegistry): string {
    const tstr = renderType(v.type, registry) + "*";
    const arrStr = v.arraySize !== null ? `[${v.arraySize}]` : "";
    return `extern ${tstr} ${v.name}${arrStr};`;
}

/** Render an enum's C++ definition (compact form). */
export function renderEnumPreview(d: EnumDecl, registry: TypeRegistry): string {
    const under = d.underlying ? ` : ${renderType(d.underlying, registry)}` : "";
    const lines: string[] = [`enum class ${d.name}${under} {`];
    for (const e of d.entries) {
        lines.push(`    ${e.name} = ${e.rawText || e.value},`);
    }
    lines.push("};");
    return lines.join("\n");
}

/** Render a struct's C++ definition (compact form). */
export function renderStructPreview(d: StructDecl, registry: TypeRegistry): string {
    const kw = d.isUnion ? "union" : "struct";
    const lines: string[] = [`${kw} __attribute__((packed)) ${d.name} {`];
    for (const f of d.fields) {
        const tstr = renderType(f.type, registry);
        const arrStr = f.arraySize !== null ? `[${f.arraySize}]` : "";
        const fname = fieldName(f.name, f.offset);
        lines.push(`    ${tstr} ${fname}${arrStr}; // 0x${f.offset.toString(16)}`);
    }
    lines.push("};");
    if (d.size !== null) {
        lines.push(`static_assert(sizeof(${d.name}) == 0x${d.size.toString(16)});`);
    }
    return lines.join("\n");
}

/** Render a bitfield's C++ definition (struct + mask enum). */
export function renderBitPreview(d: BitDecl, registry: TypeRegistry): string {
    const u = d.underlying.base;
    const totalMap: Record<string, number> = {
        "u8": 8, "u16": 16, "u32": 32, "u64": 64,
        "s8": 8, "s16": 16, "s32": 32, "s64": 64,
    };
    const total = totalMap[u] ?? 32;
    const sorted = [...d.entries].sort((a, b) => a.range.lo - b.range.lo);
    const lines: string[] = [`struct __attribute__((packed)) ${d.name} {`];
    let cursor = 0;
    let padIdx = 0;
    for (const e of sorted) {
        if (e.range.lo > cursor) {
            const w = e.range.lo - cursor;
            lines.push(`    ${u} _pad${padIdx} : ${w};`);
            padIdx++;
            cursor = e.range.lo;
        }
        const ft = e.fieldType ? renderType(e.fieldType, registry) : u;
        lines.push(`    ${ft} ${bitFieldName(e.name)} : ${e.range.hi - e.range.lo + 1};`);
        cursor = e.range.hi + 1;
    }
    if (cursor < total) {
        lines.push(`    ${u} _pad${padIdx} : ${total - cursor};`);
    }
    lines.push("};");
    lines.push(`enum class ${d.name}Mask : ${u} {`);
    for (const c of d.constants) {
        lines.push(`    ${c.name} = ${c.rawText || c.value},`);
    }
    for (const e of sorted) {
        const w = e.range.hi - e.range.lo + 1;
        if (w === 1) {
            lines.push(`    ${e.name} = BIT(${e.range.lo}),`);
        } else {
            const mask = ((1 << w) - 1) << e.range.lo;
            lines.push(`    ${e.name} = 0x${mask.toString(16)},`);
        }
    }
    lines.push("};");
    return lines.join("\n");
}

/** Apply codegen field-name transform: `unk` → `m_0xOFFSET`, `_x`/`m_x` → unchanged, else `m_<name>`. */
export function fieldName(name: string, offset: number): string {
    if (name === "unk") return `m_0x${offset.toString(16)}`;
    // `\` prefix means "don't add m_" — strip it and use the name as-is.
    if (name.startsWith("\\")) return name.slice(1);
    return `m_${name}`;
}

/** Same as fieldName but for bitfield entries. loBit is used for unk → m_N. */
export function bitFieldName(name: string, loBit: number = 0): string {
    if (name === "unk") return `m_${loBit}`;
    // `\` prefix means "don't add m_" — strip it and use the name as-is.
    if (name.startsWith("\\")) return name.slice(1);
    return `m_${name}`;
}

/** Compute the size (in bytes) of a TypeRef, given a registry of named types.
 *  Supports multi-level arrays via arraySizes (e.g. [3, 1000] for u8[3][1000]). */
export function typeSize(t: TypeRef, arraySizes: number[] | null, registry: TypeRegistry): number {
    let base: number;
    if (t.pointerCount > 0 || t.isReference) {
        base = 8;
    } else if (PRIMITIVE_SIZES[t.base] !== undefined) {
        base = PRIMITIVE_SIZES[t.base];
    } else {
        // For scoped names (e.g. "sys2d::Sprite"), extract the last part for lookup.
        const lookupName = t.base.includes("::") ? t.base.split("::").pop()! : t.base;
        if (registry.scopeSizes.has(lookupName)) {
            base = registry.scopeSizes.get(lookupName)!;
        } else if (registry.namedTypeSizes.has(lookupName)) {
            base = registry.namedTypeSizes.get(lookupName)!;
        } else if (registry.itypes.has(lookupName)) {
            // Find a primitive word in the actual type
            const actual = registry.itypes.get(lookupName)!;
            const words = actual.split(/\s+/);
            base = 0;
            for (let i = words.length - 1; i >= 0; i--) {
                if (PRIMITIVE_SIZES[words[i]] !== undefined) {
                    base = PRIMITIVE_SIZES[words[i]];
                    break;
                }
            }
        } else if (registry.aliases.has(lookupName)) {
            return typeSize(registry.aliases.get(lookupName)!, arraySizes, registry);
        } else {
            base = 0; // Unknown — let codegen's static_assert catch it.
        }
    }
    if (arraySizes) {
        for (const dim of arraySizes) base = base * dim;
    }
    return base;
}
