# Changelog

All notable changes to the BSYM extension will be documented here.

## [0.1.0] — 2026-07-19

### Added
- Initial release.
- TextMate grammar for `.bsym` with C++-baseline coloring and embedded C++ highlighting inside `:start babil.h` / `:end babil.h` raw blocks.
- Lexer + recursive-descent parser ported from `babilsym.py`, with line/column tracking for every AST node.
- Hover provider showing declaration info, codegen preview, and demangled C++ symbol names.
- Itanium C++ ABI demangler supporting nested names, CV-qualifiers, pointer/reference/const qualifiers, builtin types, variadic `z`, and substitution references.
- Diagnostics provider with syntax errors and lightweight semantic checks (overlapping field offsets, duplicate names, unknown types, bit ranges with `lo > hi`).
- Document symbol provider for the VSCode outline view.
- Semantic tokens provider for theme-independent coloring.
- Configurable settings: `bsym.diagnostics.enabled`, `bsym.diagnostics.maxProblems`, `bsym.hover.showDemangledSymbol`, `bsym.hover.showCodegen`, `bsym.semanticTokens.enabled`.
