/**
 * Recursive-descent parser for .bsym — port of the Parser class in babilsym.py.
 * Produces a typed AST and collects diagnostics for syntax errors.
 */

import {
    Token, lex, LexError,
} from "./lexer";
import {
    Decl, FieldDecl, FuncDecl, VarDecl, EnumDecl, BitDecl, StructDecl, ScopeDecl,
    TypeAlias, ITypeDecl, IncludeDecl, RawBlock, AnonStructDecl,
    TypeRef, ParamDecl, EnumEntry, BitRange, BitEntry, BitConstant,
    Program, ParseError, PRIMITIVES,
} from "./ast";

function makeRangeFromTokens(start: Token, end: Token) {
    return {
        start: { line: start.line - 1, column: start.col - 1, offset: start.startOffset },
        end:   { line: end.line - 1,   column: end.col - 1 + (end.endOffset - end.startOffset), offset: end.endOffset },
    };
}

function makeRangeFromToken(t: Token) {
    return makeRangeFromTokens(t, t);
}

function rangeFromOffsets(startOff: number, endOff: number, lineLookup: number[]) {
    // lineLookup[i] = offset of the first char on line i (0-indexed lines)
    // Find start line/col
    let sLine = 0;
    for (let i = 0; i < lineLookup.length; i++) {
        if (i + 1 < lineLookup.length && lineLookup[i + 1] <= startOff) continue;
        sLine = i;
        break;
    }
    let sCol = startOff - lineLookup[sLine];
    let eLine = 0;
    for (let i = 0; i < lineLookup.length; i++) {
        if (i + 1 < lineLookup.length && lineLookup[i + 1] <= endOff) continue;
        eLine = i;
        break;
    }
    let eCol = endOff - lineLookup[eLine];
    return {
        start: { line: sLine, column: sCol, offset: startOff },
        end:   { line: eLine, column: eCol,   offset: endOff },
    };
}

export class ParseErrorCollector {
    errors: ParseError[] = [];

    add(message: string, token: Token, severity: "error" | "warning" = "error") {
        this.errors.push({
            message,
            range: makeRangeFromToken(token),
            severity,
        });
    }

    addAtOffset(message: string, startOff: number, endOff: number, lineLookup: number[], severity: "error" | "warning" = "error") {
        this.errors.push({
            message,
            range: rangeFromOffsets(startOff, endOff, lineLookup),
            severity,
        });
    }
}

export class Parser {
    private tokens: Token[];
    private pos = 0;
    private errors: ParseErrorCollector;
    private lineLookup: number[];
    sourceText: string;

    constructor(tokens: Token[], sourceText: string, errors: ParseErrorCollector, lineLookup: number[]) {
        this.tokens = tokens;
        this.sourceText = sourceText;
        this.errors = errors;
        this.lineLookup = lineLookup;
    }

    /** Skip comment tokens, returning the collected comment text joined with \n. */
    private consumeComments(): string[] {
        const comments: string[] = [];
        while (this.pos < this.tokens.length && this.tokens[this.pos].kind === "COMMENT") {
            comments.push(this.tokens[this.pos].value as string);
            this.pos++;
        }
        return comments;
    }

    /** Peek a non-comment token, skipping COMMENT tokens. offset = how many non-comment tokens ahead. */
    private peek(offset = 0): Token {
        let idx = this.pos;
        let skipped = 0;
        while (idx < this.tokens.length) {
            if (this.tokens[idx].kind === "COMMENT") {
                idx++;
                continue;
            }
            if (skipped === offset) return this.tokens[idx];
            skipped++;
            idx++;
        }
        return this.tokens[this.tokens.length - 1];
    }

    /** Advance past COMMENT tokens and return the next non-comment token (without advancing past it for EOF). */
    private next(): Token {
        while (this.pos < this.tokens.length && this.tokens[this.pos].kind === "COMMENT") {
            this.pos++;
        }
        const t = this.tokens[this.pos];
        if (this.pos < this.tokens.length - 1) this.pos++;
        return t;
    }

    private expect(kind: string): Token {
        const t = this.peek();
        if (t.kind !== kind) {
            this.errors.add(
                `Expected '${kind}', got '${t.kind}'${t.value !== null && t.value !== undefined ? ` (${JSON.stringify(t.value)})` : ""}`,
                t,
            );
        }
        return this.next();
    }

    private at(kind: string): boolean {
        return this.peek().kind === kind;
    }

    // ------------------- Top level -------------------

    parseProgram(): Decl[] {
        const items: Decl[] = [];
        let safetyCounter = 0;
        while (!this.at("EOF")) {
            // Bounded loop guard to prevent infinite loops on pathological input.
            safetyCounter++;
            if (safetyCounter > 1_000_000) break;

            const comments = this.consumeComments();
            const before = this.pos;
            const decl = this.parseTopLevel();
            if (decl && comments.length) {
                (decl as any).comment = comments.join("\n");
            }
            if (decl) items.push(decl);
            if (this.pos === before) {
                // No progress — bail out to avoid infinite loop.
                this.next();
            }
        }
        return items;
    }

    private parseTopLevel(): Decl | null {
        const t = this.peek();

        if (t.kind === "RAW_BLOCK") {
            this.next();
            const v = t.value as { filename: string; content: string };
            return {
                kind: "raw-block",
                filename: v.filename,
                content: v.content,
                range: makeRangeFromToken(t),
            } as RawBlock;
        }
        if (t.kind === "include") return this.parseInclude();
        if (t.kind === "type") return this.parseTypeAlias();
        if (t.kind === "itype") return this.parseItype();
        if (t.kind === "enum") return this.parseEnum();
        if (t.kind === "bit") return this.parseBit();
        if (t.kind === "struct") return this.parseStruct();
        if (t.kind === "union") return this.parseUnion();
        if (t.kind === "IDENT") {
            const t1 = this.peek(1);
            if (t1.kind === "{") return this.parseScope();
            if (t1.kind === "[" && this.peek(2).kind === "INT" && this.peek(3).kind === "]" && this.peek(4).kind === "{") {
                return this.parseScope();
            }
            return this.parseIdentItem();
        }

        this.errors.add(
            `Unexpected token '${t.kind}'${t.value !== null && t.value !== undefined ? ` (${JSON.stringify(t.value)})` : ""}`,
            t,
        );
        this.next();
        return null;
    }

    // ------------------- Includes -------------------

    private parseInclude(): IncludeDecl {
        const startTok = this.expect("include");
        let filename: string;
        if (this.at("<")) {
            this.next();
            const parts: string[] = [];
            while (!this.at(">") && !this.at("EOF")) {
                const t = this.next();
                parts.push(String(t.value));
            }
            this.expect(">");
            filename = "<" + parts.join("") + ">";
        } else {
            const first = this.expect("IDENT");
            const parts: string[] = [first.value];
            while (this.at(".") || this.at("/")) {
                const sep = this.next().value;
                parts.push(sep);
                const ident = this.expect("IDENT");
                parts.push(ident.value);
            }
            filename = parts.join("");
        }
        const endTok = this.expect(";");
        return {
            kind: "include",
            filename,
            comment: null,
            range: makeRangeFromTokens(startTok, endTok),
        };
    }

    // ------------------- Type aliases / itypes -------------------

    private parseTypeAlias(): TypeAlias {
        const startTok = this.expect("type");
        const nameTok = this.expect("IDENT");
        this.expect("=");
        const target = this.parseType();
        const endTok = this.expect(";");
        return {
            kind: "type-alias",
            name: nameTok.value,
            target,
            comment: null,
            range: makeRangeFromTokens(startTok, endTok),
            nameRange: makeRangeFromToken(nameTok),
        };
    }

    private parseItype(): ITypeDecl {
        const startTok = this.expect("itype");
        const nameTok = this.expect("IDENT");
        // Optional `=` separator: `itype GLint = u32;` (new syntax)
        // or bare: `itype GLint u32;` (old syntax, still supported)
        if (this.at("=")) {
            this.next();
        }
        const parts: string[] = [this.expect("IDENT").value];
        while (!this.at(";") && !this.at("EOF")) {
            const t = this.next();
            parts.push(String(t.value));
        }
        const endTok = this.expect(";");
        return {
            kind: "itype",
            name: nameTok.value,
            actual: parts.join(" "),
            comment: null,
            range: makeRangeFromTokens(startTok, endTok),
            nameRange: makeRangeFromToken(nameTok),
        };
    }

    // ------------------- Types -------------------

    private parseType(): TypeRef {
        let isConst = false;
        if (this.at("const")) {
            this.next();
            isConst = true;
        }

        let base: string;
        let baseTok: Token;
        let lastBaseTok: Token;
        if (this.at("this")) {
            baseTok = this.next();
            lastBaseTok = baseTok;
            base = "this";
        } else {
            baseTok = this.expect("IDENT");
            lastBaseTok = baseTok;
            const parts: string[] = [baseTok.value];
            while (this.at("::")) {
                this.next();
                const p = this.expect("IDENT");
                parts.push(p.value);
                lastBaseTok = p;
            }
            base = parts.join("::");
        }

        let pointerCount = 0;
        while (this.at("*")) {
            this.next();
            pointerCount++;
        }

        let isReference = false;
        if (this.at("&")) {
            this.next();
            isReference = true;
        }

        return {
            base,
            isConst,
            pointerCount,
            isReference,
            range: makeRangeFromTokens(baseTok, lastBaseTok),
        };
    }

    // ------------------- Enums -------------------

    private parseEnum(): EnumDecl {
        const startTok = this.expect("enum");
        const nameTok = this.expect("IDENT");
        let underlying: TypeRef | null = null;
        if (!this.at("{")) {
            underlying = this.parseType();
        }
        const openBrace = this.expect("{");
        const entries: EnumEntry[] = [];
        while (!this.at("}") && !this.at("EOF")) {
            const entNameTok = this.expect("IDENT");
            this.expect(":");
            let entry: EnumEntry;
            if (this.at("BIT_SHORTHAND")) {
                const nTok = this.next();
                const n = nTok.value as number;
                entry = {
                    name: entNameTok.value,
                    value: 1 << n,
                    rawText: `BIT(${n})`,
                    isBitShorthand: true,
                    bitN: n,
                    isNull: false,
                    isFloat: false,
                    nameRange: makeRangeFromToken(entNameTok),
                    valueRange: makeRangeFromToken(nTok),
                };
            } else if (this.at("NULL")) {
                const nullTok = this.next();
                entry = {
                    name: entNameTok.value,
                    value: 0,
                    rawText: "nullptr",
                    isBitShorthand: false,
                    bitN: 0,
                    isNull: true,
                    isFloat: false,
                    nameRange: makeRangeFromToken(entNameTok),
                    valueRange: makeRangeFromToken(nullTok),
                };
            } else if (this.at("FLOAT")) {
                const fTok = this.next();
                const raw = fTok.value as string;
                entry = {
                    name: entNameTok.value,
                    value: 0,
                    rawText: raw,
                    isBitShorthand: false,
                    bitN: 0,
                    isNull: false,
                    isFloat: true,
                    nameRange: makeRangeFromToken(entNameTok),
                    valueRange: makeRangeFromToken(fTok),
                };
            } else if (this.at("INT")) {
                const val = this.consumeInt();
                entry = {
                    name: entNameTok.value,
                    value: val.value,
                    rawText: val.raw,
                    isBitShorthand: false,
                    bitN: 0,
                    isNull: false,
                    isFloat: false,
                    nameRange: makeRangeFromToken(entNameTok),
                    valueRange: val.range,
                };
            } else {
                this.errors.add(
                    "Expected enum value (INT, .n, NULL, or float)",
                    this.peek(),
                );
                this.next();
                entry = {
                    name: entNameTok.value,
                    value: 0,
                    rawText: "",
                    isBitShorthand: false,
                    bitN: 0,
                    isNull: false,
                    isFloat: false,
                    nameRange: makeRangeFromToken(entNameTok),
                };
            }
            entries.push(entry);
            this.expect(";");
        }
        const closeBrace = this.expect("}");
        return {
            kind: "enum",
            name: nameTok.value,
            underlying,
            entries,
            comment: null,
            range: makeRangeFromTokens(startTok, closeBrace),
            nameRange: makeRangeFromToken(nameTok),
            bodyRange: makeRangeFromTokens(openBrace, closeBrace),
        };
    }

    // ------------------- Bits -------------------

    private parseBit(): BitDecl {
        const startTok = this.expect("bit");
        const nameTok = this.expect("IDENT");
        const underlying = this.parseType();
        const openBrace = this.expect("{");
        const entries: BitEntry[] = [];
        const constants: BitConstant[] = [];
        while (!this.at("}") && !this.at("EOF")) {
            if (this.at("INT")) {
                const loTok = this.peek();
                const lo = this.consumeIntValue();
                let hi = lo;
                let hiTok = loTok;
                if (this.at("-")) {
                    this.next();
                    hiTok = this.peek();
                    hi = this.consumeIntValue();
                }
                if (lo > hi) {
                    this.errors.add(
                        `Bit range lo > hi (${lo} > ${hi})`,
                        hiTok,
                    );
                }
                this.expect(":");
                // Optional type: if two IDENTs follow, first is type
                let fieldType: TypeRef | null = null;
                if (this.at("IDENT") && this.peek(1).kind === "IDENT") {
                    fieldType = this.parseType();
                }
                const fieldNameTok = this.expect("IDENT");
                this.expect(";");
                entries.push({
                    range: { lo, hi },
                    name: fieldNameTok.value,
                    fieldType,
                    nameRange: makeRangeFromToken(fieldNameTok),
                    rangeRange: makeRangeFromTokens(loTok, hiTok),
                });
            } else if (this.at("IDENT")) {
                const constNameTok = this.next();
                this.expect(":");
                let constant: BitConstant;
                if (this.at("BIT_SHORTHAND")) {
                    const nTok = this.next();
                    const n = nTok.value as number;
                    constant = {
                        name: constNameTok.value,
                        value: 1 << n,
                        rawText: `BIT(${n})`,
                        isBitShorthand: true,
                        bitN: n,
                        isNull: false,
                        isFloat: false,
                        nameRange: makeRangeFromToken(constNameTok),
                        valueRange: makeRangeFromToken(nTok),
                    };
                } else if (this.at("NULL")) {
                    const nullTok = this.next();
                    constant = {
                        name: constNameTok.value,
                        value: 0,
                        rawText: "nullptr",
                        isBitShorthand: false,
                        bitN: 0,
                        isNull: true,
                        isFloat: false,
                        nameRange: makeRangeFromToken(constNameTok),
                        valueRange: makeRangeFromToken(nullTok),
                    };
                } else if (this.at("FLOAT")) {
                    const fTok = this.next();
                    const raw = fTok.value as string;
                    constant = {
                        name: constNameTok.value,
                        value: 0,
                        rawText: raw,
                        isBitShorthand: false,
                        bitN: 0,
                        isNull: false,
                        isFloat: true,
                        nameRange: makeRangeFromToken(constNameTok),
                        valueRange: makeRangeFromToken(fTok),
                    };
                } else if (this.at("INT")) {
                    const val = this.consumeInt();
                    constant = {
                        name: constNameTok.value,
                        value: val.value,
                        rawText: val.raw,
                        isBitShorthand: false,
                        bitN: 0,
                        isNull: false,
                        isFloat: false,
                        nameRange: makeRangeFromToken(constNameTok),
                        valueRange: val.range,
                    };
                } else {
                    this.errors.add(
                        "Expected bit constant value (INT, .n, NULL, or float)",
                        this.peek(),
                    );
                    this.next();
                    constant = {
                        name: constNameTok.value,
                        value: 0,
                        rawText: "",
                        isBitShorthand: false,
                        bitN: 0,
                        isNull: false,
                        isFloat: false,
                        nameRange: makeRangeFromToken(constNameTok),
                    };
                }
                constants.push(constant);
                this.expect(";");
            } else {
                this.errors.add(
                    "Expected bit entry (INT range or IDENT named constant)",
                    this.peek(),
                );
                this.next();
            }
        }
        const closeBrace = this.expect("}");
        return {
            kind: "bit",
            name: nameTok.value,
            underlying,
            entries,
            constants,
            comment: null,
            range: makeRangeFromTokens(startTok, closeBrace),
            nameRange: makeRangeFromToken(nameTok),
            bodyRange: makeRangeFromTokens(openBrace, closeBrace),
        };
    }

    // ------------------- Structs -------------------

    private consumeInt(): { value: number; raw: string; range: any } {
        const t = this.expect("INT");
        if (typeof t.value === "object" && t.value !== null) {
            return {
                value: t.value.value,
                raw: t.value.raw,
                range: makeRangeFromToken(t),
            };
        }
        return { value: Number(t.value), raw: String(t.value), range: makeRangeFromToken(t) };
    }

    private consumeIntValue(): number {
        return this.consumeInt().value;
    }

    private parseIntExpr(): { value: number; range: any; raw: string } {
        const first = this.consumeInt();
        let result = first.value;
        let lastTok = first.range;
        let raw = first.raw;
        while (this.at("*") || this.at("+")) {
            const opTok = this.next();
            const rhs = this.consumeInt();
            if (opTok.kind === "*") {
                result = result * rhs.value;
                raw = raw + "*" + rhs.raw;
            } else {
                result = result + rhs.value;
                raw = raw + "+" + rhs.raw;
            }
            lastTok = rhs.range;
        }
        return { value: result, range: { start: first.range.start, end: lastTok.end }, raw };
    }

    /** Parse zero or more array dimensions: [N][M][K] → [N, M, K] */
    private parseArrayDims(): { values: number[]; raws: string[] } {
        const values: number[] = [];
        const raws: string[] = [];
        while (this.at("[")) {
            this.next();
            const sz = this.parseIntExpr();
            values.push(sz.value);
            raws.push(sz.raw);
            this.expect("]");
        }
        return { values, raws };
    }

    private parseFieldAtOffset(): Decl {
        const offExpr = this.parseIntExpr();
        const offset = offExpr.value;
        const offsetRaw = offExpr.raw;
        this.expect(":");

        // Check for anonymous union/struct: `offset : { ... };` or `offset : struct { ... };` or `offset : union { ... };`
        if (this.at("{")) {
            // Anonymous union.
            return this._parseAnonStruct(offExpr, offset, offsetRaw, true);
        }
        if ((this.at("struct") || this.at("union")) && this.peek(1).kind === "{") {
            const kw = this.next().kind;  // consume struct/union
            return this._parseAnonStruct(offExpr, offset, offsetRaw, kw === "union");
        }

        // Normal field.
        const ftype = this.parseType();
        // Array dims can appear before OR after the name (both forms supported).
        let dimsBefore = { values: [] as number[], raws: [] as string[] };
        if (this.at("[")) {
            dimsBefore = this.parseArrayDims();
        }
        const nameTok = this.expect("IDENT");
        let dimsAfter = { values: [] as number[], raws: [] as string[] };
        if (this.at("[")) {
            dimsAfter = this.parseArrayDims();
        }
        // Combine: dims before name first, then dims after name.
        const arraySizes = [...dimsBefore.values, ...dimsAfter.values];
        const arraySizesRaw = [...dimsBefore.raws, ...dimsAfter.raws];
        const arraySize = arraySizes.length > 0 ? arraySizes[0] : null;
        const arraySizeRaw = arraySizesRaw.length > 0 ? arraySizesRaw[0] : null;
        const endTok = this.expect(";");
        return {
            kind: "field",
            offset,
            offsetRaw,
            type: ftype,
            name: nameTok.value,
            arraySize,
            arraySizeRaw,
            arraySizes,
            arraySizesRaw,
            comment: null,
            range: makeRangeFromTokens(offExpr.range.startToken || this.peek(), endTok),
            nameRange: makeRangeFromToken(nameTok),
        } as FieldDecl;
    }

    /** Parse an anonymous union or struct: `{ members };`
     *  Members are parsed WITHOUT offsets (like union members): `type name;` or `type[N] name;` */
    private _parseAnonStruct(offExpr: any, offset: number, offsetRaw: string, isUnion: boolean): AnonStructDecl {
        const openBrace = this.expect("{");
        const fields: FieldDecl[] = [];
        while (!this.at("}") && !this.at("EOF")) {
            const comments = this.consumeComments();
            // Parse like a union member: type [N] name;
            const ftype = this.parseType();
            let dimsBefore = { values: [] as number[], raws: [] as string[] };
            if (this.at("[")) {
                dimsBefore = this.parseArrayDims();
            }
            const nameTok = this.expect("IDENT");
            let dimsAfter = { values: [] as number[], raws: [] as string[] };
            if (this.at("[")) {
                dimsAfter = this.parseArrayDims();
            }
            const arraySizes = [...dimsBefore.values, ...dimsAfter.values];
            const arraySizesRaw = [...dimsBefore.raws, ...dimsAfter.raws];
            const arraySize = arraySizes.length > 0 ? arraySizes[0] : null;
            const arraySizeRaw = arraySizesRaw.length > 0 ? arraySizesRaw[0] : null;
            const endTok = this.expect(";");
            const f: FieldDecl = {
                kind: "field",
                offset: 0,
                offsetRaw: "0",
                type: ftype,
                name: nameTok.value,
                arraySize,
                arraySizeRaw,
                arraySizes,
                arraySizesRaw,
                comment: null,
                range: makeRangeFromTokens(openBrace, endTok),
                nameRange: makeRangeFromToken(nameTok),
            };
            if (comments.length) f.comment = comments.join("\n");
            fields.push(f);
        }
        const closeBrace = this.expect("}");
        const endTok = this.expect(";");
        return {
            kind: "anon-struct",
            offset,
            offsetRaw,
            isUnion,
            fields,
            comment: null,
            range: makeRangeFromTokens(offExpr.range.startToken || this.peek(), endTok),
        } as AnonStructDecl;
    }

    private parseStruct(): StructDecl {
        const startTok = this.expect("struct");
        const nameTok = this.expect("IDENT");
        let size: number | null = null;
        let sizeRaw: string | null = null;
        if (this.at("[")) {
            this.next();
            const sz = this.parseIntExpr();
            size = sz.value;
            sizeRaw = sz.raw;
            this.expect("]");
        }
        const openBrace = this.expect("{");
        const fields: FieldDecl[] = [];
        const items: Decl[] = [];
        while (!this.at("}") && !this.at("EOF")) {
            const comments = this.consumeComments();
            const f = this.parseFieldAtOffset();
            if (f.kind === "field") {
                if (comments.length) f.comment = comments.join("\n");
                fields.push(f);
                items.push(f);
            } else {
                // anon-struct
                if (comments.length) (f as any).comment = comments.join("\n");
                items.push(f);
            }
        }
        const closeBrace = this.expect("}");
        return {
            kind: "struct",
            name: nameTok.value,
            size,
            sizeRaw,
            fields,
            items,
            comment: null,
            isUnion: false,
            range: makeRangeFromTokens(startTok, closeBrace),
            nameRange: makeRangeFromToken(nameTok),
            bodyRange: makeRangeFromTokens(openBrace, closeBrace),
        };
    }

    private parseUnion(): StructDecl {
        const startTok = this.expect("union");
        const nameTok = this.expect("IDENT");
        let size: number | null = null;
        let sizeRaw: string | null = null;
        if (this.at("[")) {
            this.next();
            const sz = this.parseIntExpr();
            size = sz.value;
            sizeRaw = sz.raw;
            this.expect("]");
        }
        const openBrace = this.expect("{");
        const fields: FieldDecl[] = [];
        while (!this.at("}") && !this.at("EOF")) {
            const comments = this.consumeComments();
            const ftype = this.parseType();
            let dimsBefore = { values: [] as number[], raws: [] as string[] };
            if (this.at("[")) {
                dimsBefore = this.parseArrayDims();
            }
            const nameTok = this.expect("IDENT");
            let dimsAfter = { values: [] as number[], raws: [] as string[] };
            if (this.at("[")) {
                dimsAfter = this.parseArrayDims();
            }
            const arraySizes = [...dimsBefore.values, ...dimsAfter.values];
            const arraySizesRaw = [...dimsBefore.raws, ...dimsAfter.raws];
            const arraySize = arraySizes.length > 0 ? arraySizes[0] : null;
            const arraySizeRaw = arraySizesRaw.length > 0 ? arraySizesRaw[0] : null;
            const endTok = this.expect(";");
            const f: FieldDecl = {
                kind: "field",
                offset: 0,
                offsetRaw: "0",
                type: ftype,
                name: nameTok.value,
                arraySize,
                arraySizeRaw,
                arraySizes,
                arraySizesRaw,
                comment: null,
                range: makeRangeFromTokens(startTok, endTok),
                nameRange: makeRangeFromToken(nameTok),
            };
            if (comments.length) f.comment = comments.join("\n");
            fields.push(f);
        }
        const closeBrace = this.expect("}");
        return {
            kind: "struct",
            name: nameTok.value,
            size,
            sizeRaw,
            fields,
            comment: null,
            isUnion: true,
            range: makeRangeFromTokens(startTok, closeBrace),
            nameRange: makeRangeFromToken(nameTok),
            bodyRange: makeRangeFromTokens(openBrace, closeBrace),
        };
    }

    // ------------------- Scopes -------------------

    private parseScope(): ScopeDecl {
        const nameTok = this.expect("IDENT");
        let size: number | null = null;
        let sizeRaw: string | null = null;
        if (this.at("[")) {
            this.next();
            const sz = this.parseIntExpr();
            size = sz.value;
            sizeRaw = sz.raw;
            this.expect("]");
        }
        const openBrace = this.expect("{");
        const items: Decl[] = [];
        while (!this.at("}") && !this.at("EOF")) {
            const comments = this.consumeComments();
            const before = this.pos;
            const decl = this.parseScopeItem();
            if (decl && comments.length) {
                (decl as any).comment = comments.join("\n");
            }
            if (decl) items.push(decl);
            if (this.pos === before) {
                this.next();
            }
        }
        const closeBrace = this.expect("}");
        return {
            kind: "scope",
            name: nameTok.value,
            size,
            sizeRaw,
            items,
            comment: null,
            range: makeRangeFromTokens(nameTok, closeBrace),
            nameRange: makeRangeFromToken(nameTok),
            bodyRange: makeRangeFromTokens(openBrace, closeBrace),
        };
    }

    private parseScopeItem(): Decl | null {
        const t = this.peek();

        if (t.kind === "type") return this.parseTypeAlias();
        if (t.kind === "itype") return this.parseItype();
        if (t.kind === "enum") return this.parseEnum();
        if (t.kind === "bit") return this.parseBit();
        if (t.kind === "struct") return this.parseStruct();
        if (t.kind === "union") return this.parseUnion();
        if (t.kind === "IDENT") {
            const t1 = this.peek(1);
            if (t1.kind === "{") return this.parseScope();
            if (t1.kind === "[" && this.peek(2).kind === "INT" && this.peek(3).kind === "]" && this.peek(4).kind === "{") {
                return this.parseScope();
            }
            return this.parseIdentItem();
        }
        if (t.kind === "this") return this.parseIdentItem();
        if (t.kind === "INT") {
            const comments = this.consumeComments();
            const f = this.parseFieldAtOffset();
            if (comments.length && (f.kind === "field" || f.kind === "anon-struct")) {
                f.comment = comments.join("\n");
            }
            return f;
        }

        this.errors.add(
            `Unexpected token in scope: '${t.kind}'${t.value !== null && t.value !== undefined ? ` (${JSON.stringify(t.value)})` : ""}`,
            t,
        );
        this.next();
        return null;
    }

    private parseIdentItem(): Decl | null {
        const t0 = this.peek(0);
        const t1 = this.peek(1);

        if (t1.kind === "{") return this.parseScope();
        if (t1.kind === "[" && this.peek(2).kind === "INT" && this.peek(3).kind === "]" && this.peek(4).kind === "{") {
            return this.parseScope();
        }

        const returnType = this.parseType();
        let dimsBefore = { values: [] as number[], raws: [] as string[] };
        if (this.at("[")) {
            dimsBefore = this.parseArrayDims();
        }
        const nameTok = this.expect("IDENT");

        if (this.at("(")) {
            return this.parseFunctionAfterName(returnType, nameTok);
        }

        let dimsAfter = { values: [] as number[], raws: [] as string[] };
        if (this.at("[")) {
            dimsAfter = this.parseArrayDims();
        }
        const arraySizes = [...dimsBefore.values, ...dimsAfter.values];
        const arraySizesRaw = [...dimsBefore.raws, ...dimsAfter.raws];
        const arraySize = arraySizes.length > 0 ? arraySizes[0] : null;
        const arraySizeRaw = arraySizesRaw.length > 0 ? arraySizesRaw[0] : null;
        const semiTok = this.expect(";");
        const arrowTok = this.expect("->");
        const sym = this.parseSymbol();
        return {
            kind: "variable",
            type: returnType,
            name: nameTok.value,
            arraySize,
            arraySizeRaw,
            arraySizes,
            arraySizesRaw,
            symbol: sym.symbol,
            comment: null,
            range: makeRangeFromTokens(t0, sym.token),
            nameRange: makeRangeFromToken(nameTok),
            symbolRange: makeRangeFromToken(sym.token),
        } as VarDecl;
    }

    private parseFunctionAfterName(returnType: TypeRef, nameTok: Token): FuncDecl {
        const startTok = this.peek();
        this.expect("(");
        const params: ParamDecl[] = [];
        let hasThis = false;
        let isConstThis = false;
        let isVariadic = false;

        if (!this.at(")")) {
            if (this.at("this")) {
                this.next();
                hasThis = true;
                if (!this.at(")")) this.expect(",");
            } else if (this.at("const") && this.peek(1).kind === "this") {
                this.next();
                this.next();
                hasThis = true;
                isConstThis = true;
                if (!this.at(")")) this.expect(",");
            }

            while (!this.at(")") && !this.at("EOF")) {
                if (this.at("...")) {
                    this.next();
                    isVariadic = true;
                    break;
                }
                const ptype = this.parseType();
                let pname: string | null = null;
                let pnameTok: Token | null = null;
                const t = this.peek();
                if (t.kind === "IDENT") {
                    pnameTok = this.next();
                    pname = pnameTok.value;
                } else if (["type","itype","enum","bit","struct","union","const","this","NULL"].includes(t.kind)) {
                    pnameTok = this.next();
                    pname = pnameTok.value;
                }
                params.push({
                    type: ptype,
                    name: pname,
                    isThis: false,
                    isConstThis: false,
                    isVariadic: false,
                    nameRange: pnameTok ? makeRangeFromToken(pnameTok) : undefined,
                });
                if (this.at(",")) {
                    this.next();
                } else {
                    break;
                }
            }
        }

        this.expect(")");
        this.expect(";");
        const arrowTok = this.expect("->");
        const sym = this.parseSymbol();
        return {
            kind: "function",
            returnType,
            name: nameTok.value,
            params,
            hasThis,
            isConstThis,
            isVariadic,
            symbol: sym.symbol,
            comment: null,
            range: makeRangeFromTokens(startTok, sym.token),
            nameRange: makeRangeFromToken(nameTok),
            symbolRange: makeRangeFromToken(sym.token),
        };
    }

    private parseSymbol(): { symbol: string; token: Token } {
        const t = this.peek();
        if (t.kind === "IDENT") {
            this.next();
            return { symbol: t.value, token: t };
        }
        this.errors.add(
            `Expected symbol after '->', got '${t.kind}'${t.value !== null && t.value !== undefined ? ` (${JSON.stringify(t.value)})` : ""}`,
            t,
        );
        this.next();
        return { symbol: "", token: t };
    }
}

/** Build a lookup array of line-start offsets, indexed by 0-based line number. */
export function buildLineLookup(text: string): number[] {
    const lookup: number[] = [0];
    for (let i = 0; i < text.length; i++) {
        if (text[i] === "\n") lookup.push(i + 1);
    }
    return lookup;
}

/** Parse source text, returning a Program with items and accumulated errors. */
export function parse(text: string): Program {
    const errors = new ParseErrorCollector();
    const lineLookup = buildLineLookup(text);
    let tokens: Token[] = [];
    try {
        tokens = lex(text);
    } catch (e) {
        if (e instanceof LexError) {
            const range = rangeFromOffsets(
                e.range.startOffset,
                e.range.endOffset,
                lineLookup,
            );
            errors.errors.push({
                message: e.message,
                range,
                severity: "error",
            });
            return { items: [], errors: errors.errors };
        }
        throw e;
    }
    const parser = new Parser(tokens, text, errors, lineLookup);
    const items = parser.parseProgram();
    return { items, errors: errors.errors };
}

/** Re-export for downstream consumers. ParseErrorCollector is already exported above. */
export { makeRangeFromToken, rangeFromOffsets };
